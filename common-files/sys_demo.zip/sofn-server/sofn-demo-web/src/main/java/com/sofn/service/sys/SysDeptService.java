package com.sofn.service.sys;

import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.provider.sys.SysDeptProvider;
import com.sofn.model.generator.SysDept;
import org.springframework.stereotype.Service;

/**
 * @author sofn
 * @version 2016年5月20日 下午3:16:07
 */
@Service
public class SysDeptService extends BaseService<SysDeptProvider, SysDept> {
	@DubboReference
	public void setProvider(SysDeptProvider provider) {
		this.provider = provider;
	}
}
