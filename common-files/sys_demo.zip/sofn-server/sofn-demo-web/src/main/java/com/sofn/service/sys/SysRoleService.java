package com.sofn.service.sys;

import java.util.List;
import java.util.Map;

import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.sys.SysRoleBean;
import com.sofn.provider.sys.SysRoleProvider;
import com.sofn.model.generator.SysRole;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;

/**
 * @author sofn
 * @version 2016年5月31日 上午11:09:29
 */
@Service
public class SysRoleService extends BaseService<SysRoleProvider, SysRole> {
	@DubboReference
	public void setProvider(SysRoleProvider provider) {
		this.provider = provider;
	}

	public PageInfo<?> queryBean(Map<String, Object> params) {
		return provider.queryBean(params);
	}

	public List<?> getRoleByUserId(String userId){
		// 调用消息提供者的方法
		return provider.getRoleByUserId(userId);
	}
}