package com.sofn.service.sys;

import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.provider.sys.SysCacheProvider;
import org.springframework.stereotype.Service;

@Service
public class SysCacheService {
    @DubboReference
	private SysCacheProvider sysCacheProvider;

	public void flushCache() {
		sysCacheProvider.flush();
	}
}
