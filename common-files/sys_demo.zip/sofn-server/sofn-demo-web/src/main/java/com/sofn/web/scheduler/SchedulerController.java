//package com.sofn.web.scheduler;
//
//import java.util.Map;
//
//import javax.servlet.http.HttpServletRequest;
//
//import com.sofn.model.generator.TaskGroup;
//import com.sofn.service.scheduler.SchedulerService;
//import org.apache.shiro.authz.annotation.RequiresPermissions;
//import com.sofn.core.base.BaseController;
//import com.sofn.core.util.Request2ModelUtil;
//import com.sofn.core.util.WebUtil;
//import com.sofn.model.generator.TaskScheduler;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.ui.ModelMap;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestMethod;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.github.pagehelper.PageInfo;
//
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//
///**
// * 调度管理
// *
// * @author sofn
// * @version 2016年6月1日 下午3:14:24
// */
//@RestController
//@Api(value = "调度声明管理", description = "调度声明管理")
//@RequestMapping(value = "/task", method = RequestMethod.POST)
//public class SchedulerController extends BaseController {
//	@Autowired
//	private SchedulerService schedulerService;
//
//	@RequestMapping("/read/groups")
//	@ApiOperation(value = "任务组列表")
//	@RequiresPermissions("task.group.read")
//	public Object getGroup(HttpServletRequest request, ModelMap modelMap) {
//		Map<String, Object> params = WebUtil.getParameterMap(request);
//		PageInfo<?> list = schedulerService.queryGroup(params);
//		return setSuccessModelMap(modelMap, list);
//	}
//
//	// 详细信息
//	@ApiOperation(value = "任务组详情")
//	@RequiresPermissions("task.group.read")
//	@RequestMapping(value = "/read/group")
//	public Object detail(ModelMap modelMap,
//			@RequestParam(value = "id", required = false) String id) {
//		TaskGroup record = schedulerService.queryGroupById(id);
//		return setSuccessModelMap(modelMap, record);
//	}
//
//	// 新增任务组
//	@ApiOperation(value = "添加任务组")
//	@RequiresPermissions("task.group.add")
//	@RequestMapping(value = "/add/group", method = RequestMethod.POST)
//	public Object add(HttpServletRequest request, ModelMap modelMap) {
//		TaskGroup record = Request2ModelUtil.covert(TaskGroup.class, request);
//		schedulerService.addGroup(record);
//		return setSuccessModelMap(modelMap);
//	}
//
//	// 修改任务组
//	@ApiOperation(value = "修改任务组")
//	@RequiresPermissions("task.group.update")
//	@RequestMapping(value = "/update/group", method = RequestMethod.POST)
//	public Object update(HttpServletRequest request, ModelMap modelMap) {
//		TaskGroup record = Request2ModelUtil.covert(TaskGroup.class, request);
//		schedulerService.updateGroup(record);
//		return setSuccessModelMap(modelMap);
//	}
//
//	@ApiOperation(value = "任务列表")
//	@RequestMapping("/read/schedulers")
//	@RequiresPermissions("task.scheduler.read")
//	public Object getScheduler(HttpServletRequest request, ModelMap modelMap) {
//		Map<String, Object> params = WebUtil.getParameterMap(request);
//		PageInfo<?> list = schedulerService.queryScheduler(params);
//		return setSuccessModelMap(modelMap, list);
//	}
//
//	// 详细信息
//	@ApiOperation(value = "任务详情")
//	@RequiresPermissions("task.scheduler.read")
//	@RequestMapping(value = "/read/scheduler")
//	public Object detailScheduler(ModelMap modelMap,
//			@RequestParam(value = "id", required = false) String id) {
//		TaskScheduler record = schedulerService.querySchedulerById(id);
//		return setSuccessModelMap(modelMap, record);
//	}
//
//	// 新增任务
//	@ApiOperation(value = "添加任务")
//	@RequiresPermissions("task.scheduler.add")
//	@RequestMapping(value = "/add/scheduler", method = RequestMethod.POST)
//	public Object addScheduler(HttpServletRequest request, ModelMap modelMap) {
//		TaskScheduler record = Request2ModelUtil.covert(TaskScheduler.class, request);
//		schedulerService.addScheduler(record);
//		return setSuccessModelMap(modelMap);
//	}
//
//	// 修改任务
//	@ApiOperation(value = "修改任务")
//	@RequiresPermissions("task.scheduler.update")
//	@RequestMapping(value = "/update/scheduler", method = RequestMethod.POST)
//	public Object updateScheduler(HttpServletRequest request, ModelMap modelMap) {
//		TaskScheduler record = Request2ModelUtil.covert(TaskScheduler.class, request);
//		schedulerService.updateScheduler(record);
//		return setSuccessModelMap(modelMap);
//	}
//}
