package com.sofn.core.shiro;

import com.github.pagehelper.PageInfo;
import com.sofn.core.config.Global;
import com.sofn.core.config.Resources;
import com.sofn.core.exception.LoginException;
import com.sofn.model.generator.SysRole;
import com.sofn.model.sys.SysRoleBean;
import com.sofn.service.sys.*;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.sofn.core.util.JwtHelper;
import com.sofn.core.util.StringUtils;
import com.sofn.core.util.WebUtil;
import com.sofn.model.generator.SysSession;
import com.sofn.model.generator.SysUser;
import io.jsonwebtoken.Claims;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.AuthenticationException;
import org.apache.shiro.authc.AuthenticationInfo;
import org.apache.shiro.authc.AuthenticationToken;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.PrincipalCollection;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * Created by Code.Ai on 16/8/10.
 * Description:
 */
public class StatelessRealm extends AuthorizingRealm {
    private final Logger logger = LogManager.getLogger(StatelessRealm.class);
    @Autowired
    private SysUserService      sysUserService;
    @Autowired
    private SysSessionService   sysSessionService;
    @Autowired
    private SysAuthorizeService sysAuthorizeService;
    @Autowired
    private RedisService        redisService;
    @Autowired
    private SysRoleService      sysRoleService;


    @Override
    public boolean supports(AuthenticationToken token) {
        // 仅支持StatelessToken类型的Token
        return token instanceof StatelessToken;
    }

    //授权
    @Override
    protected AuthorizationInfo doGetAuthorizationInfo(PrincipalCollection principals) {
        // 根据uniqueToken查找角色，请根据需求实现
//        String uniqueToken = (String) principals.getPrimaryPrincipal();
//        logger.error("uniqueToken = {}", uniqueToken);
//        // 解析 token
//        Claims claims = JwtHelper.parseJWT(uniqueToken, Global.getConfig("sofn.api.base64Secret"));
//        // 从token获取userId
//        String userId = (String) claims.get("userId");
//        //通过customerId查询角色
////        List<?>                 roles             = sysRoleService.getRoleByUserId(userId);
//        SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
//        //将所有角色放入权限验证器中
////        if (roles != null && roles.size() != 0) {
////            for (Object role : roles) {
////                authorizationInfo.addRole(((SysRoleBean) role).getRoleName());
////            }
////        }
//        authorizationInfo.addRole("admin");
//        return authorizationInfo;


        SimpleAuthorizationInfo info    = new SimpleAuthorizationInfo();
        String                  userId  = "1";
        SysUser                 sysUser = sysUserService.queryById(userId);
        if (sysUser.getUserType() != 1) {
            userId = null;
        }
        List<String> list = sysAuthorizeService.queryPermissionByUserId(userId);
        for (String permission : list) {
            if (org.apache.commons.lang3.StringUtils.isNotBlank(permission)) {
                // 添加基于Permission的权限信息
                info.addStringPermission(permission);
            }
        }
        // 添加用户权限
        info.addStringPermission("user");
        return info;
    }

    //登录
    @Override
    protected AuthenticationInfo doGetAuthenticationInfo(AuthenticationToken token) throws AuthenticationException {
//        if (uniqueToken.equals("app")) {
//            return new SimpleAuthenticationInfo(uniqueToken, "app_token", getName());
//        } else {
//            return new SimpleAuthenticationInfo(uniqueToken, "pc_token", getName());
//        }
        StatelessToken statelessToken = (StatelessToken) token;
        String         uniqueToken    = statelessToken.getUniqueToken();
        logger.error("token = " + uniqueToken);
        if(uniqueToken == null){
            throw new LoginException(Resources.getMessage("LOGIN_FAIL"));
        }
        // 解析 token
        Claims claims = JwtHelper.parseJWT(uniqueToken, Global.getConfig("sofn.api.base64Secret"));
        if (claims != null) {
            logger.error("userId = {}", claims.get("userId"));
            logger.error("userName = {}", claims.get("userName"));
            logger.error("role = {}", claims.get("role"));
            String account = (String) claims.get("userName");
            String userId = (String) claims.get("userId");
            String role    = (String) claims.get("role");
            String userName = (String) token.getPrincipal();
            logger.error("token.getPrincipal() = {}", token.getPrincipal());
            String password = (String) token.getCredentials();
            logger.error("token.getCredentials() = {}", token.getCredentials());
            // 如果 redis 没有此 token 登录失败
            return new SimpleAuthenticationInfo(uniqueToken,
                    redisService.getAccessToken(account + userId), getName());
        }
        throw new LoginException(Resources.getMessage("LOGIN_FAIL"));
    }


    /**
     * 保存session
     */
    private void saveSession(String account) {
        // 踢出用户
        sysSessionService.deleteByAccount(account);
        SysSession record = new SysSession();
        record.setAccount(account);
        Subject currentUser = SecurityUtils.getSubject();
        Session session     = currentUser.getSession();
        record.setSessionId(session.getId().toString());
        String host = (String) session.getAttribute("HOST");
        record.setIp(org.apache.commons.lang3.StringUtils.isBlank(host) ? session.getHost() : host);
        record.setStartTime(session.getStartTimestamp());
        sysSessionService.update(record);
    }
}
