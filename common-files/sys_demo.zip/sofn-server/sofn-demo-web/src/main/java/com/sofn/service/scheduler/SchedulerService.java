//package com.sofn.service.scheduler;
//
//import java.util.Map;
//
//import com.sofn.model.generator.TaskFireLog;
//import com.sofn.model.generator.TaskGroup;
//import com.sofn.core.support.Assert;
//import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
//import com.sofn.model.generator.TaskScheduler;
//import com.sofn.model.scheduler.TaskScheduled;
//import com.sofn.model.scheduler.TaskSchedulerBean;
//import com.sofn.provider.scheduler.SchedulerProvider;
//import org.springframework.stereotype.Service;
//
//import com.github.pagehelper.PageInfo;
//
///**
// * @author sofn
// * @version 2016年5月20日 下午3:16:20
// */
//@Service
//public class SchedulerService {
//    @DubboReference // 依赖调度服务
//	private SchedulerProvider schedulerProvider;
//
//	public PageInfo<TaskScheduled> getAllTaskDetail() {
//		PageInfo<TaskScheduled> pageInfo = new PageInfo<TaskScheduled>();
//		pageInfo.setList(schedulerProvider.getAllTaskDetail());
//		pageInfo.setPages(1);
//		pageInfo.setSize(pageInfo.getList().size());
//		return pageInfo;
//	}
//
//	public boolean execTask(String taskGroup, String taskName) {
//		Assert.notNull(taskGroup, "TASKGROUP");
//		Assert.notNull(taskName, "TASKNAME");
//		return schedulerProvider.execTask(taskGroup, taskName);
//	}
//
//	public boolean openTask(String taskGroup, String taskName) {
//		Assert.notNull(taskGroup, "TASKGROUP");
//		Assert.notNull(taskName, "TASKNAME");
//		return schedulerProvider.openCloseTask(taskGroup, taskName, "start");
//	}
//
//	public boolean closeTask(String taskGroup, String taskName) {
//		Assert.notNull(taskGroup, "TASKGROUP");
//		Assert.notNull(taskName, "TASKNAME");
//		return schedulerProvider.openCloseTask(taskGroup, taskName, "stop");
//	}
//
//	public PageInfo<TaskGroup> queryGroup(Map<String, Object> params) {
//		return schedulerProvider.queryGroup(params);
//	}
//
//	public PageInfo<TaskSchedulerBean> queryScheduler(Map<String, Object> params) {
//		return schedulerProvider.queryScheduler(params);
//	}
//
//	public PageInfo<TaskFireLog> queryLog(Map<String, Object> params) {
//		return schedulerProvider.queryLog(params);
//	}
//
//	/**
//	 * @param id
//	 * @return
//	 */
//	public TaskGroup queryGroupById(String id) {
//		Assert.notNull(id, "ID");
//		return schedulerProvider.getGroupById(id);
//	}
//
//	/**
//	 * @param record
//	 */
//	public void addGroup(TaskGroup record) {
//		schedulerProvider.updateGroup(record);
//	}
//
//	/**
//	 * @param record
//	 */
//	public void updateGroup(TaskGroup record) {
//		Assert.isNotBlank(record.getId(), "ID");
//		schedulerProvider.updateGroup(record);
//	}
//
//	/**
//	 * @param id
//	 * @return
//	 */
//	public TaskScheduler querySchedulerById(String id) {
//		Assert.isNotBlank(id, "ID");
//		return schedulerProvider.getSchedulerById(id);
//	}
//
//	/**
//	 * @param record
//	 */
//	public void addScheduler(TaskScheduler record) {
//		schedulerProvider.updateScheduler(record);
//	}
//
//	/**
//	 * @param record
//	 */
//	public void updateScheduler(TaskScheduler record) {
//		Assert.notNull(record.getId(), "ID");
//		schedulerProvider.updateScheduler(record);
//	}
//}
