package com.sofn.web.sys;

import javax.servlet.http.HttpServletRequest;

import com.github.pagehelper.PageInfo;
import com.sofn.core.config.Global;
import com.sofn.core.shiro.AccessToken;
import com.sofn.core.util.JwtHelper;
import com.sofn.service.sys.RedisService;
import com.sofn.core.config.Resources;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.support.login.LoginHelper;
import com.sofn.core.util.StringUtils;
import com.sofn.core.util.WebUtil;
import io.jsonwebtoken.Claims;
import org.apache.shiro.SecurityUtils;
import com.sofn.core.base.BaseController;
import com.sofn.core.exception.LoginException;
import com.sofn.core.support.Assert;
import com.sofn.core.support.HttpCode;
import com.sofn.core.util.Request2ModelUtil;
import com.sofn.model.generator.SysUser;
import com.sofn.service.sys.SysUserService;
import org.apache.shiro.authc.SimpleAuthenticationInfo;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.session.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

/**
 * 用户登录
 * 
 * @author sofn
 * @version 2016年5月20日 下午3:11:21
 */
@RestController
@Api(value = "登录接口", description = "登录接口")
public class LoginController extends BaseController {
	@Autowired
	private SysUserService sysUserService;
	@Autowired
	private RedisService redisService;
	/**
	 * 登录操作
	 * @param modelMap
	 * @param account
	 * @param password
     * @return
     */

	// swagger 接口注解
	@ApiOperation(value = "用户登录")
	@PostMapping("/login_token")   /*等效于 @RequestMapping(value = "/login",method = RequestMethod.POST) */
	public Object login_token(ModelMap modelMap,
			/*@ApiParam为swagger使用的参数注解*/
			@ApiParam(required = true, value = "登录帐号")
			@RequestParam(value = "account", required = false) String account,
			// 添加测试 请求头
			@ApiParam(required = true, value = "登录密码")
			@RequestParam(value = "password", required = false) String password) {
		// 参数检查
		logger.error("modelmap",modelMap);
		Assert.notNull(account, "ACCOUNT");
		Assert.notNull(password, "PASSWORD");
		logger.error(getUserByName("admin"));
		//登录逻辑
		String encryptPassword = sysUserService.encryptPassword(password);
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("countSql", 0);
		params.put("enable", 1);
		params.put("account", account);
		PageInfo<SysUser> pageInfo = sysUserService.query(params);
		AccessToken accessTokenEntity = new AccessToken();
		String accessToken = "";
		if (pageInfo.getSize() == 1) {
			SysUser user = pageInfo.getList().get(0);
			if (user.getPassword().equals(encryptPassword)) {
				WebUtil.saveCurrentUser(user.getId());
				//拼装accessToken
				 accessToken = JwtHelper.createJWT(account,
						 user.getId(),
						"admin",
						Global.getConfig("sofn.api.clientId"),
						Global.getConfig("sofn.api.name"),
						Long.parseLong(Global.getConfig("sofn.api.expiresSecond")) * 1000,
						Global.getConfig("sofn.api.base64Secret"), new Date());
				// 存入 redis
				modelMap.addAttribute("token",redisService.putPcToken(account + user.getId(), accessToken));
				return setSuccessModelMap(modelMap);
			}
			else{
				throw new LoginException(Resources.getMessage("LOGIN_FAIL"));
			}
		}else{
			throw new LoginException(Resources.getMessage("LOGIN_FAIL"));
		}
	}

	// 登录
	@ApiOperation(value = "用户登录")
	@PostMapping("/login")
	public Object login(ModelMap modelMap,
						@ApiParam(required = true, value = "登录帐号") @RequestParam(value = "account", required = false) String account,
						@ApiParam(required = true, value = "登录密码") @RequestParam(value = "password", required = false) String password) {
		Assert.notNull(account, "ACCOUNT");
		Assert.notNull(password, "PASSWORD");
		getUserByName("aaa");
		updateUserPut("aaa");
		if (LoginHelper.login(account, sysUserService.encryptPassword(password))) {
			return setSuccessModelMap(modelMap);
		}
		throw new LoginException(Resources.getMessage("LOGIN_FAIL"));
	}


	@Cacheable(value="default")
	public String getUserByName(String userName) {
		System.out.println("两次调用第一次会执行，第二次不会执行！");
		return "test2";
	}

	@CachePut(value="common",key="1000")
	public String updateUserPut(String userName) {
		return "test2";
	}

	/**
	 * 用户退出 删除 token
	 * @param modelMap
	 * @param token
     * @return
     */
	@ApiOperation(value = "用户登出")
	@PostMapping("/logout")
	public Object logout(ModelMap modelMap,
						 @ApiParam(required = true, value = "token")
						 @RequestHeader(value = "token", defaultValue = "") String  token) {
//		SecurityUtils.getSubject().logout();
		logger.error("token = {}",token);
		// 解析 token
		Claims claims = JwtHelper.parseJWT(token, Global.getConfig("sofn.api.base64Secret"));
		if(claims != null){
			logger.error("account = {}, userId = {}",(String) claims.get("userName"), (String) claims.get("userId"));
			redisService.deletePcToken((String) claims.get("userName") + claims.get("userId"));
		}
		return setSuccessModelMap(modelMap);
	}

	// 注册
	@ApiOperation(value = "用户注册")
	@PostMapping("/regin")
	public Object regin(HttpServletRequest request, ModelMap modelMap,
			@RequestParam(value = "account", required = false) String account,
			@RequestParam(value = "password", required = false) String password) {
		SysUser sysUser = Request2ModelUtil.covert(SysUser.class, request);
		Assert.notNull(sysUser.getAccount(), "ACCOUNT");
		Assert.notNull(sysUser.getPassword(), "PASSWORD");
		sysUser.setPassword(sysUserService.encryptPassword(sysUser.getPassword()));
		sysUserService.add(sysUser);
		if (LoginHelper.login(account, password)) {
			return setSuccessModelMap(modelMap);
		}
		throw new IllegalArgumentException(Resources.getMessage("LOGIN_FAIL"));
	}

	// 没有登录
	@ApiOperation(value = "没有登录")
	@GetMapping("/unauthorized")
	public Object unauthorized(ModelMap modelMap) {
		SecurityUtils.getSubject().logout();
		return setModelMap(modelMap, HttpCode.UNAUTHORIZED);
	}

	// 没有权限
	@ApiOperation(value = "没有权限")
	@GetMapping("/forbidden")
	public Object forbidden(ModelMap modelMap) {
		return setModelMap(modelMap, HttpCode.FORBIDDEN);
	}
}
