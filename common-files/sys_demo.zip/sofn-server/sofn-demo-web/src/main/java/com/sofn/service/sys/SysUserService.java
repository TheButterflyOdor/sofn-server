package com.sofn.service.sys;

import java.util.Map;

import com.sofn.core.base.BaseService;
import com.sofn.core.support.Assert;
import com.sofn.core.support.login.LoginHelper;
import com.sofn.core.support.login.ThirdPartyUser;
import com.sofn.model.generator.SysUser;
import com.sofn.provider.sys.SysUserProvider;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.authz.UnauthorizedException;
import com.sofn.core.util.WebUtil;
import com.sofn.model.sys.SysUserBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageInfo;
import com.github.pagehelper.StringUtil;

/**
 * @author sofn
 * @version 2016年5月20日 下午3:47:21
 */
@Service
public class SysUserService extends BaseService<SysUserProvider, SysUser> {
    @Autowired
    public void setProvider(SysUserProvider provider) {
        this.provider = provider;
    }

    /** 修改用户信息 */
    @CachePut("updateUserInfo")
    public void updateUserInfo(SysUser sysUser) {
        Assert.isNotBlank(sysUser.getId(), "USER_ID");
        Assert.isNotBlank(sysUser.getAccount(), "ACCOUNT");
        Assert.length(sysUser.getAccount(), 3, 15, "ACCOUNT");
        SysUser user = this.queryById(sysUser.getId());
        Assert.notNull(user, "USER", sysUser.getId());
        if (StringUtils.isBlank(sysUser.getPassword())) {
            sysUser.setPassword(user.getPassword());
        }
        if (StringUtil.isEmpty(sysUser.getAvatar())) {
            sysUser.setAvatar(user.getAvatar());
        }
        sysUser.setUpdateBy(WebUtil.getCurrentUser());
        provider.update(sysUser);
    }

    public PageInfo<SysUserBean> queryBeans(Map<String, Object> params) {
        return provider.queryBeans(params);
    }

    public void updatePassword(String id, String password) {
        Assert.isNotBlank(id, "USER_ID");
        Assert.isNotBlank(password, "PASSWORD");
        SysUser sysUser = provider.queryById(id);
        Assert.notNull(sysUser, "USER", id);
        String userId = WebUtil.getCurrentUser();
        if (!id.equals(userId)) {
            SysUser user = provider.queryById(userId);
            if (user.getUserType() == 1) {
                throw new UnauthorizedException();
            }
        }
        sysUser.setPassword(encryptPassword(password));
        sysUser.setUpdateBy(WebUtil.getCurrentUser());
        provider.update(sysUser);
    }

    public String encryptPassword(String password) {
        return provider.encryptPassword(password);
    }

    public void thirdPartyLogin(ThirdPartyUser thirdUser) {
        SysUser sysUser = null;
        // 查询是否已经绑定过
        String userId = provider.queryUserIdByThirdParty(thirdUser.getOpenid(), thirdUser.getProvider());
        if (userId == null) {
            sysUser = insertThirdPartyUser(thirdUser);
        } else {
            sysUser = queryById(userId);
        }
        LoginHelper.login(sysUser.getAccount(), sysUser.getPassword());
    }

    public SysUser insertThirdPartyUser(ThirdPartyUser thirdUser) {
        return provider.insertThirdPartyUser(thirdUser);
    }
}
