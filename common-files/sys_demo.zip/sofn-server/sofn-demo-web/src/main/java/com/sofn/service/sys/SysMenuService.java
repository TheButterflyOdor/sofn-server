package com.sofn.service.sys;

import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.core.base.BaseService;
import com.sofn.model.generator.SysMenu;
import com.sofn.provider.sys.SysMenuProvider;
import org.springframework.stereotype.Service;

/**
 * @author sofn
 * @version 2016年5月20日 下午3:16:07
 */
@Service
public class SysMenuService extends BaseService<SysMenuProvider, SysMenu> {
	@DubboReference
	public void setProvider(SysMenuProvider provider) {
		this.provider = provider;
	}
}
