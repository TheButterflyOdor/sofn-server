package com.sofn.core;

//@ComponentScan
//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(locations = { "classpath:Spring-test.xml" })
//public class EmailTest {
//	@Test
//	public void sendEmail() {
//		EmailUtil.sendMail("sofn@126.com", "先生，恭喜您", "您好：<br/><div style='text-indent:2em'>很高兴认识您！</div>"
//				+ "<div style='text-indent:2em'>有任务疑问请和我联系！</div>");
//	}
//}
