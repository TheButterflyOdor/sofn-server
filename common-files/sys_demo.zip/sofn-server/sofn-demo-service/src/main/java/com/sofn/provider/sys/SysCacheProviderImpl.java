package com.sofn.provider.sys;

import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.core.util.RedisUtil;

@DubboService(interfaceClass = SysCacheProvider.class)
public class SysCacheProviderImpl implements SysCacheProvider {

	// 清缓存
	public void flush() {
		RedisUtil.delAll("*:sysDics:*");
		RedisUtil.delAll("*:sysDicMap:*");
		RedisUtil.delAll("*:getAuthorize:*");
		RedisUtil.delAll("*:sysPermission:*");
	}
}