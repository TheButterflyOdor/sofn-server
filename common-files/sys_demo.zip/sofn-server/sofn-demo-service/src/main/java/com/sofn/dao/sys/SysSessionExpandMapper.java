package com.sofn.dao.sys;

import java.util.List;

import com.sofn.core.base.BaseExpandMapper;

public interface SysSessionExpandMapper extends BaseExpandMapper {

	void deleteBySessionId(String sessionId);

	String queryBySessionId(String sessionId);

	List<String> querySessionIdByAccount(String account);

}
