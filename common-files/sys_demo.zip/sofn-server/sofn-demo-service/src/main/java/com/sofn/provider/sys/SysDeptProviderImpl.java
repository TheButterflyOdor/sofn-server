package com.sofn.provider.sys;

import java.util.Map;

import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.sys.SysDeptExpandMapper;
import com.sofn.model.generator.SysDept;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;

import com.github.pagehelper.PageInfo;

/**
 * @author sofn
 * @version 2016年5月20日 下午3:19:19
 */
@CacheConfig(cacheNames = "sysDept")
@DubboService(interfaceClass = SysDeptProvider.class)
public class SysDeptProviderImpl extends BaseProviderImpl<SysDept> implements SysDeptProvider {
	@Autowired
	private SysDeptExpandMapper syDeptExpandMapper;

	public PageInfo<SysDept> query(Map<String, Object> params) {
		this.startPage(params);
		return getPage(syDeptExpandMapper.query(params));
	}
}
