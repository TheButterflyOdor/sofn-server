package com.sofn.provider.sys;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.sofn.model.generator.SysSession;
import org.apache.commons.lang3.StringUtils;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.generator.SysSessionMapper;
import com.sofn.dao.sys.SysSessionExpandMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.CachePut;

import com.github.pagehelper.PageInfo;

/**
 * @author sofn
 * @version 2016年5月20日 下午3:19:19
 */
@CacheConfig(cacheNames = "sysSession")
@DubboService(interfaceClass = SysSessionProvider.class)
public class SysSessionProviderImpl extends BaseProviderImpl<SysSession> implements SysSessionProvider {
    @Autowired
    private SysSessionMapper sessionMapper;
    @Autowired
    private SysSessionExpandMapper sessionExpandMapper;

    @CachePut   // 此确保方法被执行，同时方法的返回值也被记录到缓存中。主要用于更新缓存
    public SysSession update(SysSession record) {
        if (record.getId() == null) {
            record.setUpdateBy(record.getAccount());
            record.setUpdateTime(new Date());
            String id = sessionExpandMapper.queryBySessionId(record.getSessionId());
            if (StringUtils.isNotBlank(id)) {
                record.setId(id);
                sessionMapper.updateByPrimaryKey(record);
            } else {
                record.setId(createId("SysSession"));
                record.setCreateBy(record.getAccount());
                record.setCreateTime(new Date());
                sessionMapper.insert(record);
            }
        } else {
            sessionMapper.updateByPrimaryKey(record);
        }
        return record;
    }

    @CacheEvict
    public void delete(final String id) {
        sessionMapper.deleteByPrimaryKey(id);
    }

    // 系统触发,由系统自动管理缓存
    public void deleteBySessionId(final String sessionId) {
        sessionExpandMapper.deleteBySessionId(sessionId);
    }

    public PageInfo<SysSession> query(Map<String, Object> params) {
        this.startPage(params);
        return getPage(sessionExpandMapper.query(params));
    }

    public List<String> querySessionIdByAccount(String account) {
        return sessionExpandMapper.querySessionIdByAccount(account);
    }
}
