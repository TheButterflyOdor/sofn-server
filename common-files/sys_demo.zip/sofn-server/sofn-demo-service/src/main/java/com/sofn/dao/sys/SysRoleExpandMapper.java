package com.sofn.dao.sys;

import java.util.List;

import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.generator.SysRole;
import com.sofn.model.sys.SysRoleBean;
import org.apache.ibatis.annotations.Param;

public interface SysRoleExpandMapper extends BaseExpandMapper {

	List<String> queryPermission(@Param("roleId") String id);

	List<SysRoleBean> getRoleByUserId(@Param("userId") String userId);
}
