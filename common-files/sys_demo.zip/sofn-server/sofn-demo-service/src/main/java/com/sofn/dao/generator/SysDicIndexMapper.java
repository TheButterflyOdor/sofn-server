package com.sofn.dao.generator;

import com.sofn.core.base.BaseMapper;
import com.sofn.model.generator.SysDicIndex;

/**
 * 由MyBatis Generator工具自动生成，请不要手动修改
 */
public interface SysDicIndexMapper extends BaseMapper<SysDicIndex> {
}