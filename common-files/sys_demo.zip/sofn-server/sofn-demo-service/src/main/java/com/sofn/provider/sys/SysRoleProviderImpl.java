package com.sofn.provider.sys;

import java.util.List;
import java.util.Map;

import com.sofn.dao.sys.SysRoleExpandMapper;
import com.sofn.model.sys.SysRoleBean;
import org.apache.commons.lang3.StringUtils;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.model.generator.SysRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;

import com.github.pagehelper.PageInfo;

/**
 * @author sofn
 * @version 2016年5月31日 上午11:01:33
 */
@CacheConfig(cacheNames = "sysRole")
@DubboService(interfaceClass = SysRoleProvider.class)
public class SysRoleProviderImpl extends BaseProviderImpl<SysRole> implements SysRoleProvider {
	@Autowired
	private SysRoleExpandMapper sysRoleExpandMapper;

	public PageInfo<SysRole> query(Map<String, Object> params) {
		startPage(params);
		return getPage(sysRoleExpandMapper.query(params));
	}

	public PageInfo<SysRoleBean> queryBean(Map<String, Object> params) {
		startPage(params);
		PageInfo<SysRoleBean> pageInfo = getPage(sysRoleExpandMapper.query(params), SysRoleBean.class);
		// 权限信息
		for (SysRoleBean bean : pageInfo.getList()) {
			List<String> permissions = sysRoleExpandMapper.queryPermission(bean.getId());
			for (String permission : permissions) {
				if (StringUtils.isBlank(bean.getPermission())) {
					bean.setPermission(permission);
				} else {
					bean.setPermission(bean.getPermission() + ";" + permission);
				}
			}
		}
		return pageInfo;
	}

	@Override
	public List<SysRoleBean> getRoleByUserId(String userId) {
		// 具体实现
		return sysRoleExpandMapper.getRoleByUserId(userId);
	}
}
