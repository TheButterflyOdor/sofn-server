package com.sofn.provider.sys;

import java.util.Map;

import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.model.generator.SysEvent;
import org.springframework.cache.annotation.CacheConfig;

import com.github.pagehelper.PageInfo;

@CacheConfig(cacheNames = "sysEvent")
@DubboService(interfaceClass = SysEventProvider.class)
public class SysEventProviderImpl extends BaseProviderImpl<SysEvent> implements SysEventProvider {
	
	public PageInfo<SysEvent> query(Map<String, Object> params) {
		return null;
	}
}
