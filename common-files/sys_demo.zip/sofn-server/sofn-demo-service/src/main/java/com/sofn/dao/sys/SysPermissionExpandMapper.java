package com.sofn.dao.sys;

import com.sofn.core.base.BaseExpandMapper;
import org.apache.ibatis.annotations.Param;

public interface SysPermissionExpandMapper extends BaseExpandMapper {

	Integer getPermissionByUserId(@Param("userId") Integer userId, @Param("url") String url);
}
