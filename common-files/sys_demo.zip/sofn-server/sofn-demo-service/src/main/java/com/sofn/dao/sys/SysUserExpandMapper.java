/**
 * 
 */
package com.sofn.dao.sys;

import org.apache.ibatis.annotations.Param;
import com.sofn.core.base.BaseExpandMapper;

/**
 * @author sofn
 */
public interface SysUserExpandMapper extends BaseExpandMapper {

    String queryUserIdByThirdParty(@Param("provider") String provider, @Param("openId") String openId);
}
