package com.sofn.dao.generator;

import com.sofn.core.base.BaseMapper;
import com.sofn.model.generator.SysDic;

/**
 * 由MyBatis Generator工具自动生成，请不要手动修改
 */
public interface SysDicMapper extends BaseMapper<SysDic> {
}