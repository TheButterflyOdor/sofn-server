package com.sofn.dao.sys;

import com.sofn.core.base.BaseExpandMapper;

public interface SysDeptExpandMapper extends BaseExpandMapper {

}