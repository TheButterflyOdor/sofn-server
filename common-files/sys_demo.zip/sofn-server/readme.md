## 项目简介

- 是Java语言的分布式系统架构。 使用Spring整合开源框架。
- 使用Maven对项目进行模块化管理，提高项目的易开发性、扩展性。
- 系统包括四个模块：代码生成模块、系统管理模块、调度管理模块、Web展示模块。
- 代码生成模块：运行maven命令生成Mybatis文件和实体类到指定的模块。
- 系统管理模块：包括用户管理、权限管理、数据字典、系统参数管理等等。
- 调度管理模块：注册管理定时器，使用多种方式调用不同模块的任务实现。
- 每个模块都是独立的系统，可以无限的扩展模块，模块之间使用Dubbo或MQ进行通信。
- 每个模块服务多系统部署，注册到同一个Zookeeper集群服务注册中心，实现集群部署。

## 主要功能
 1. 数据库：Druid数据库连接池，监控数据库访问性能，统计SQL的执行性能。 数据库密码加密。
 2. 持久层：mybatis持久化，aop切换数据库实现读写分离，PageHelper分页。Transtraction注解事务。
 3. MVC： 基于spring mvc注解,Rest风格Controller。Exception统一管理。
 4. 调度：Spring+quartz, 可以查询、修改周期、暂停、删除、新增、立即执行，查询执行记录等。
 5. 基于session的国际化提示信息，职责链模式的本地语言拦截器,Shiro登录、URL权限管理。会话管理，强制结束会话。
 6. 缓存和Session：注解redis缓存数据，Spring-session和redis实现分布式session同步，重启服务会话不丢失。
 7. 多系统交互：Dubbo,ActiveMQ多系统交互，ftp/sftp/fastdafs发送文件到独立服务器，使文件服务分离。
 8. 前后端分离：没有权限的文件只用nginx代理即可。
 9. 日志：log4j2打印日志，业务日志和调试日志分开打印。同时基于时间和文件大小分割日志文件。
 10. QQ、微信、新浪微博第三方登录。
 11. 项目构建：maven构建项目，mybatis generator生成mybatis映射文件和Model。
 12. 工具类：excel导入导出，汉字转拼音，身份证号码验证，数字转大写人民币，FTP/SFTP/fastDFS上传下载，发送邮件，redis缓存，加密等等。

## 技术选型
    ● 核心框架：Spring Framework 4.3.0 + Dubbox 2.8.4
    ● 安全框架：Apache Shiro 1.2
    ● 任务调度：Spring + Quartz
    ● 持久层框架：MyBatis 3.4
    ● 数据库连接池：Alibaba Druid 1.0
    ● 缓存框架：Redis
    ● 会话管理：Spring-Session 1.2
    ● 日志管理：SLF4J、Log4j2
    ● 前端框架：Angular JS + Bootstrap + jQuery

## 启动说明
    * 项目依赖activemq、Redis和ZooKeeper服务。

## 更新说明
1. 统一配置文件管理


## 2016年09月12日  下午 9:53:46
1. 使用往状态token
2. 创建2个子系统 demo1 和 demo2 都自带登录页 shiro负责权限验证和url拦截
3. 创建一个sso子系统 负责创建 token (将生成token的方法放入到sso中,登录成功后返回token,再将token存入redis,还要返回权限列表)
4. 前端负责跳转(后台之返回验证信息)
5. 在 nginx 分发之前校验参数中是否有token 如果没有 则跳转到登录页 (排除不需要token的页面)
6. support打包问题

