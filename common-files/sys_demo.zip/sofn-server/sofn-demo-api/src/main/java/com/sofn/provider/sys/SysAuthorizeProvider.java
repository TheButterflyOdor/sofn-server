package com.sofn.provider.sys;

import java.util.List;

import com.sofn.model.generator.SysRoleMenu;
import com.sofn.model.generator.SysUserMenu;
import com.sofn.model.generator.SysUserRole;
import com.sofn.model.sys.SysMenuBean;

public interface SysAuthorizeProvider {

	public void updateUserMenu(List<SysUserMenu> sysUserMenus);

	public void updateUserRole(List<SysUserRole> sysUserRoles);

	public void updateRoleMenu(List<SysRoleMenu> sysRoleMenus);

	public List<SysMenuBean> queryAuthorizeByUserId(String userId);

	public List<String> queryPermissionByUserId(String userId);
}
