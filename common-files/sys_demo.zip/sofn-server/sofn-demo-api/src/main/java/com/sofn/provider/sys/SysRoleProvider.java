package com.sofn.provider.sys;

import java.util.List;
import java.util.Map;

import com.sofn.core.base.BaseProvider;
import com.sofn.model.sys.SysRoleBean;
import com.sofn.model.generator.SysRole;

import com.github.pagehelper.PageInfo;

public interface SysRoleProvider extends BaseProvider<SysRole> {
	PageInfo<SysRoleBean> queryBean(Map<String, Object> params);
	List<SysRoleBean> getRoleByUserId(String userId);
}
