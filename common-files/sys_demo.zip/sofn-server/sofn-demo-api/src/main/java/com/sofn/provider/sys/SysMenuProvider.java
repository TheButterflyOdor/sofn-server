package com.sofn.provider.sys;

import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.SysMenu;

public interface SysMenuProvider extends BaseProvider<SysMenu> {

}
