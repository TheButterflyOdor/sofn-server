package com.sofn.model.sys;

import com.sofn.model.generator.SysRole;

@SuppressWarnings("serial")
public class SysRoleBean extends SysRole {
	private String permission;

	public String getPermission() {
		return permission;
	}

	public void setPermission(String permission) {
		this.permission = permission;
	}
}
