package com.sofn.provider.sys;

import com.sofn.model.generator.SysEvent;
import com.sofn.core.base.BaseProvider;

public interface SysEventProvider extends BaseProvider<SysEvent>{

}
