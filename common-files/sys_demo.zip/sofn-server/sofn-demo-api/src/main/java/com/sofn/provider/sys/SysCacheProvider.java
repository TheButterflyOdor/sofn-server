package com.sofn.provider.sys;

/**
 * @author sofn
 * @version 2016年6月27日 下午3:16:11
 */
public interface SysCacheProvider {
	/** 清除缓存 */
	public void flush();
}