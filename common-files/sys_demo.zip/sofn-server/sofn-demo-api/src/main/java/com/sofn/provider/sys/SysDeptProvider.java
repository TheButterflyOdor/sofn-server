package com.sofn.provider.sys;

import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.SysDept;

public interface SysDeptProvider extends BaseProvider<SysDept> {

}
