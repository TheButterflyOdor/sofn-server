package com.sofn.core.constant;

public class ApiConstants {
	public static final String CODE = "code";
	public final static String TYPE_PC = "pc";
	public final static String TYPE_APP = "app";
	// 默认pc端token后缀
	public static final String PCTOKEN = "pc-token";
	public static final String APPTOKEN = "app-token";
	// app 端默认失效时间为永久
	public static final int APP_TOKEN_TIMEOUT = 0;
	// PC 端失效时间为30分钟。
	public static final int PC_IDCODE_TIMEOUT = 30*60;
}
