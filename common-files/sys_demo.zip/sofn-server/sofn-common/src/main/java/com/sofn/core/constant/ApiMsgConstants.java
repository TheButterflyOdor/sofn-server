package com.sofn.core.constant;

/**
 * 关于api的返回错误信息
 */
public class ApiMsgConstants {
    public static final String TOKEN_ILLEGAL = "用户未登录";
    public static final int TOKEN_ILLEGAL_CODE = 401;
}
