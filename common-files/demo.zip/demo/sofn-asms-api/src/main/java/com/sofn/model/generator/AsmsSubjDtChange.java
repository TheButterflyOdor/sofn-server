package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;
import java.util.Date;

@SuppressWarnings("serial")
public class AsmsSubjDtChange extends BaseModel {
    private String dtName;

    private String dtCode;

    private String dtLevel;

    private String dtAddress;

    private String dtAreaId;

    private String dtLeader;

    private String dtLeaderPhone;

    private String dtFile;

    private String applyUserId;

    private Date applyTime;

    private String applyDtId;

    private String applyReason;

    private String auditUserId;

    private String auditSvId;

    private Date auditTime;

    private String auditSuggestion;

    private String auditState;

    public String getDtName() {
        return dtName;
    }

    public void setDtName(String dtName) {
        this.dtName = dtName == null ? null : dtName.trim();
    }

    public String getDtCode() {
        return dtCode;
    }

    public void setDtCode(String dtCode) {
        this.dtCode = dtCode == null ? null : dtCode.trim();
    }

    public String getDtLevel() {
        return dtLevel;
    }

    public void setDtLevel(String dtLevel) {
        this.dtLevel = dtLevel == null ? null : dtLevel.trim();
    }

    public String getDtAddress() {
        return dtAddress;
    }

    public void setDtAddress(String dtAddress) {
        this.dtAddress = dtAddress == null ? null : dtAddress.trim();
    }

    public String getDtAreaId() {
        return dtAreaId;
    }

    public void setDtAreaId(String dtAreaId) {
        this.dtAreaId = dtAreaId == null ? null : dtAreaId.trim();
    }

    public String getDtLeader() {
        return dtLeader;
    }

    public void setDtLeader(String dtLeader) {
        this.dtLeader = dtLeader == null ? null : dtLeader.trim();
    }

    public String getDtLeaderPhone() {
        return dtLeaderPhone;
    }

    public void setDtLeaderPhone(String dtLeaderPhone) {
        this.dtLeaderPhone = dtLeaderPhone == null ? null : dtLeaderPhone.trim();
    }

    public String getDtFile() {
        return dtFile;
    }

    public void setDtFile(String dtFile) {
        this.dtFile = dtFile == null ? null : dtFile.trim();
    }

    public String getApplyUserId() {
        return applyUserId;
    }

    public void setApplyUserId(String applyUserId) {
        this.applyUserId = applyUserId == null ? null : applyUserId.trim();
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getApplyDtId() {
        return applyDtId;
    }

    public void setApplyDtId(String applyDtId) {
        this.applyDtId = applyDtId == null ? null : applyDtId.trim();
    }

    public String getApplyReason() {
        return applyReason;
    }

    public void setApplyReason(String applyReason) {
        this.applyReason = applyReason == null ? null : applyReason.trim();
    }

    public String getAuditUserId() {
        return auditUserId;
    }

    public void setAuditUserId(String auditUserId) {
        this.auditUserId = auditUserId == null ? null : auditUserId.trim();
    }

    public String getAuditSvId() {
        return auditSvId;
    }

    public void setAuditSvId(String auditSvId) {
        this.auditSvId = auditSvId == null ? null : auditSvId.trim();
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditSuggestion() {
        return auditSuggestion;
    }

    public void setAuditSuggestion(String auditSuggestion) {
        this.auditSuggestion = auditSuggestion == null ? null : auditSuggestion.trim();
    }

    public String getAuditState() {
        return auditState;
    }

    public void setAuditState(String auditState) {
        this.auditState = auditState == null ? null : auditState.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", dtName=").append(dtName);
        sb.append(", dtCode=").append(dtCode);
        sb.append(", dtLevel=").append(dtLevel);
        sb.append(", dtAddress=").append(dtAddress);
        sb.append(", dtAreaId=").append(dtAreaId);
        sb.append(", dtLeader=").append(dtLeader);
        sb.append(", dtLeaderPhone=").append(dtLeaderPhone);
        sb.append(", dtFile=").append(dtFile);
        sb.append(", applyUserId=").append(applyUserId);
        sb.append(", applyTime=").append(applyTime);
        sb.append(", applyDtId=").append(applyDtId);
        sb.append(", applyReason=").append(applyReason);
        sb.append(", auditUserId=").append(auditUserId);
        sb.append(", auditSvId=").append(auditSvId);
        sb.append(", auditTime=").append(auditTime);
        sb.append(", auditSuggestion=").append(auditSuggestion);
        sb.append(", auditState=").append(auditState);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsSubjDtChange other = (AsmsSubjDtChange) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getDtName() == null ? other.getDtName() == null : this.getDtName().equals(other.getDtName()))
            && (this.getDtCode() == null ? other.getDtCode() == null : this.getDtCode().equals(other.getDtCode()))
            && (this.getDtLevel() == null ? other.getDtLevel() == null : this.getDtLevel().equals(other.getDtLevel()))
            && (this.getDtAddress() == null ? other.getDtAddress() == null : this.getDtAddress().equals(other.getDtAddress()))
            && (this.getDtAreaId() == null ? other.getDtAreaId() == null : this.getDtAreaId().equals(other.getDtAreaId()))
            && (this.getDtLeader() == null ? other.getDtLeader() == null : this.getDtLeader().equals(other.getDtLeader()))
            && (this.getDtLeaderPhone() == null ? other.getDtLeaderPhone() == null : this.getDtLeaderPhone().equals(other.getDtLeaderPhone()))
            && (this.getDtFile() == null ? other.getDtFile() == null : this.getDtFile().equals(other.getDtFile()))
            && (this.getApplyUserId() == null ? other.getApplyUserId() == null : this.getApplyUserId().equals(other.getApplyUserId()))
            && (this.getApplyTime() == null ? other.getApplyTime() == null : this.getApplyTime().equals(other.getApplyTime()))
            && (this.getApplyDtId() == null ? other.getApplyDtId() == null : this.getApplyDtId().equals(other.getApplyDtId()))
            && (this.getApplyReason() == null ? other.getApplyReason() == null : this.getApplyReason().equals(other.getApplyReason()))
            && (this.getAuditUserId() == null ? other.getAuditUserId() == null : this.getAuditUserId().equals(other.getAuditUserId()))
            && (this.getAuditSvId() == null ? other.getAuditSvId() == null : this.getAuditSvId().equals(other.getAuditSvId()))
            && (this.getAuditTime() == null ? other.getAuditTime() == null : this.getAuditTime().equals(other.getAuditTime()))
            && (this.getAuditSuggestion() == null ? other.getAuditSuggestion() == null : this.getAuditSuggestion().equals(other.getAuditSuggestion()))
            && (this.getAuditState() == null ? other.getAuditState() == null : this.getAuditState().equals(other.getAuditState()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getDtName() == null) ? 0 : getDtName().hashCode());
        result = prime * result + ((getDtCode() == null) ? 0 : getDtCode().hashCode());
        result = prime * result + ((getDtLevel() == null) ? 0 : getDtLevel().hashCode());
        result = prime * result + ((getDtAddress() == null) ? 0 : getDtAddress().hashCode());
        result = prime * result + ((getDtAreaId() == null) ? 0 : getDtAreaId().hashCode());
        result = prime * result + ((getDtLeader() == null) ? 0 : getDtLeader().hashCode());
        result = prime * result + ((getDtLeaderPhone() == null) ? 0 : getDtLeaderPhone().hashCode());
        result = prime * result + ((getDtFile() == null) ? 0 : getDtFile().hashCode());
        result = prime * result + ((getApplyUserId() == null) ? 0 : getApplyUserId().hashCode());
        result = prime * result + ((getApplyTime() == null) ? 0 : getApplyTime().hashCode());
        result = prime * result + ((getApplyDtId() == null) ? 0 : getApplyDtId().hashCode());
        result = prime * result + ((getApplyReason() == null) ? 0 : getApplyReason().hashCode());
        result = prime * result + ((getAuditUserId() == null) ? 0 : getAuditUserId().hashCode());
        result = prime * result + ((getAuditSvId() == null) ? 0 : getAuditSvId().hashCode());
        result = prime * result + ((getAuditTime() == null) ? 0 : getAuditTime().hashCode());
        result = prime * result + ((getAuditSuggestion() == null) ? 0 : getAuditSuggestion().hashCode());
        result = prime * result + ((getAuditState() == null) ? 0 : getAuditState().hashCode());
        return result;
    }
}