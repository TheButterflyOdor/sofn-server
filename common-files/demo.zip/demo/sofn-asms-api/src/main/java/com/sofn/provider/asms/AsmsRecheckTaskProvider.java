/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsRecheckObject;
import com.sofn.model.generator.AsmsRecheckTask;

import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
public interface AsmsRecheckTaskProvider extends BaseProvider<AsmsRecheckTask> {

    public PageInfo<List<Map<String, Object>>> list(Map<String, Object> params);

    //插入关联表信息
    public void addGlInfo(AsmsRecheckObject o);

    //删除关联表信息
    public void delGlInfoByTaskId(String taskId);

    //根据id获取关联对象
    public List<Map<String,Object>> getObjById(String id);
}
