package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AlesSubjElCancel;
import com.sofn.model.generator.AlesSubjElChange;
import com.sofn.model.generator.AlesSubjElRevoke;
import com.sofn.model.generator.AlesSubjEnforceLaw;

import java.util.Map;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:34
 */
public interface AsmsSubjEnforceLawProvider extends BaseProvider<AlesSubjEnforceLaw>{

    public int addSubjEnforceLaw(AlesSubjEnforceLaw subjEnforceLaw);

    public AlesSubjEnforceLaw findSubjEnforceLawById(String id);

    public PageInfo getSubjEnforceLawList(Map<String, Object> map);

    public int addSubjElRevoke(AlesSubjElRevoke subjElRevoke);

    public PageInfo getSubjElChangeList(Map<String, Object> map);

    public AlesSubjElChange findSubjElChangeById(String id);

    public void auditSubjElChange(AlesSubjEnforceLaw subjEnforceLaw, AlesSubjElChange subjElChange);

    public PageInfo getSubjElCancelList(Map<String, Object> map);

    public AlesSubjElCancel findSubjElCancelById(String id);

    public void auditSubjElCancel(AlesSubjEnforceLaw subjEnforceLaw, AlesSubjElCancel subjElCancel);

    public PageInfo getSubjElRevokeList(Map<String, Object> map);

    public AlesSubjElRevoke findSubjElRevokeById(String id);

    public void auditSubjElRevoke(AlesSubjEnforceLaw subjEnforceLaw, AlesSubjElRevoke subjElRevoke);
}
