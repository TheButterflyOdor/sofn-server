package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsSubjSupervise;
import com.sofn.model.generator.AsmsSubjSvCancel;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.model.generator.AsmsSubjSvRevoke;

import java.util.Map;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:34
 */
public interface AsmsSubjSuperviseProvider extends BaseProvider<AsmsSubjSupervise>{

    public int addSubjSupervise(AsmsSubjSupervise subjSupervise);

    public AsmsSubjSupervise findSubjSuperviseById(String id);

    public PageInfo getSubjSuperviseList(Map<String,Object> map);

    public int addSubjSvRevoke(AsmsSubjSvRevoke subjSvRevoke);

    public PageInfo getSubjSvChangeList(Map<String,Object> map);

    public AsmsSubjSvChange findSubjSvChangeById(String id);

    public void auditSubjSvChange(AsmsSubjSupervise subjSupervise,AsmsSubjSvChange subjSvChange);

    public PageInfo getSubjSvCancelList(Map<String,Object> map);

    public AsmsSubjSvCancel findSubjSvCancelById(String id);

    public void auditSubjSvCancel(AsmsSubjSupervise subjSupervise,AsmsSubjSvCancel subjSvCancel);

    public PageInfo getSubjSvRevokeList(Map<String,Object> map);

    public AsmsSubjSvRevoke findSubjSvRevokeById(String id);

    public void auditSubjSvRevoke(AsmsSubjSupervise subjSupervise,AsmsSubjSvRevoke subjSvRevoke);
}
