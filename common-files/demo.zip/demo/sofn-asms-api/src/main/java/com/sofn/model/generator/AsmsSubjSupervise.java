package com.sofn.model.generator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sofn.core.base.BaseModel;

@SuppressWarnings("serial")
public class AsmsSubjSupervise extends BaseModel {
    private String svName;

    private String svCode;

    private String svType;

    private String svLevel;

    private String svAreaId;

    private String svAddress;

    private String svLeader;

    private String svLeaderPhone;

    private String svContact;

    private String svContactPhone;

    private String svContactQQ;

    private String svContactEmail;

    private String svPostcode;

    public String getSvName() {
        return svName;
    }

    public void setSvName(String svName) {
        this.svName = svName == null ? null : svName.trim();
    }

    public String getSvCode() {
        return svCode;
    }

    public void setSvCode(String svCode) {
        this.svCode = svCode == null ? null : svCode.trim();
    }

    public String getSvType() {
        return svType;
    }

    public void setSvType(String svType) {
        this.svType = svType == null ? null : svType.trim();
    }

    public String getSvLevel() {
        return svLevel;
    }

    public void setSvLevel(String svLevel) {
        this.svLevel = svLevel == null ? null : svLevel.trim();
    }

    public String getSvAreaId() {
        return svAreaId;
    }

    public void setSvAreaId(String svAreaId) {
        this.svAreaId = svAreaId == null ? null : svAreaId.trim();
    }

    public String getSvAddress() {
        return svAddress;
    }

    public void setSvAddress(String svAddress) {
        this.svAddress = svAddress == null ? null : svAddress.trim();
    }

    public String getSvLeader() {
        return svLeader;
    }

    public void setSvLeader(String svLeader) {
        this.svLeader = svLeader == null ? null : svLeader.trim();
    }

    public String getSvLeaderPhone() {
        return svLeaderPhone;
    }

    public void setSvLeaderPhone(String svLeaderPhone) {
        this.svLeaderPhone = svLeaderPhone == null ? null : svLeaderPhone.trim();
    }

    public String getSvContact() {
        return svContact;
    }

    public void setSvContact(String svContact) {
        this.svContact = svContact == null ? null : svContact.trim();
    }

    public String getSvContactPhone() {
        return svContactPhone;
    }

    public void setSvContactPhone(String svContactPhone) {
        this.svContactPhone = svContactPhone == null ? null : svContactPhone.trim();
    }

    public String getSvContactQQ() {
        return svContactQQ;
    }

    public void setSvContactQQ(String svContactQQ) {
        this.svContactQQ = svContactQQ == null ? null : svContactQQ.trim();
    }

    public String getSvContactEmail() {
        return svContactEmail;
    }

    public void setSvContactEmail(String svContactEmail) {
        this.svContactEmail = svContactEmail == null ? null : svContactEmail.trim();
    }

    public String getSvPostcode() {
        return svPostcode;
    }

    public void setSvPostcode(String svPostcode) {
        this.svPostcode = svPostcode == null ? null : svPostcode.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", svName=").append(svName);
        sb.append(", svCode=").append(svCode);
        sb.append(", svType=").append(svType);
        sb.append(", svLevel=").append(svLevel);
        sb.append(", svAreaId=").append(svAreaId);
        sb.append(", svAddress=").append(svAddress);
        sb.append(", svLeader=").append(svLeader);
        sb.append(", svLeaderPhone=").append(svLeaderPhone);
        sb.append(", svContact=").append(svContact);
        sb.append(", svContactPhone=").append(svContactPhone);
        sb.append(", svContactQQ=").append(svContactQQ);
        sb.append(", svContactEmail=").append(svContactEmail);
        sb.append(", svPostcode=").append(svPostcode);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsSubjSupervise other = (AsmsSubjSupervise) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSvName() == null ? other.getSvName() == null : this.getSvName().equals(other.getSvName()))
            && (this.getSvCode() == null ? other.getSvCode() == null : this.getSvCode().equals(other.getSvCode()))
            && (this.getSvType() == null ? other.getSvType() == null : this.getSvType().equals(other.getSvType()))
            && (this.getSvLevel() == null ? other.getSvLevel() == null : this.getSvLevel().equals(other.getSvLevel()))
            && (this.getSvAreaId() == null ? other.getSvAreaId() == null : this.getSvAreaId().equals(other.getSvAreaId()))
            && (this.getSvAddress() == null ? other.getSvAddress() == null : this.getSvAddress().equals(other.getSvAddress()))
            && (this.getSvLeader() == null ? other.getSvLeader() == null : this.getSvLeader().equals(other.getSvLeader()))
            && (this.getSvLeaderPhone() == null ? other.getSvLeaderPhone() == null : this.getSvLeaderPhone().equals(other.getSvLeaderPhone()))
            && (this.getSvContact() == null ? other.getSvContact() == null : this.getSvContact().equals(other.getSvContact()))
            && (this.getSvContactPhone() == null ? other.getSvContactPhone() == null : this.getSvContactPhone().equals(other.getSvContactPhone()))
            && (this.getSvContactQQ() == null ? other.getSvContactQQ() == null : this.getSvContactQQ().equals(other.getSvContactQQ()))
            && (this.getSvContactEmail() == null ? other.getSvContactEmail() == null : this.getSvContactEmail().equals(other.getSvContactEmail()))
            && (this.getSvPostcode() == null ? other.getSvPostcode() == null : this.getSvPostcode().equals(other.getSvPostcode()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getEnable() == null ? other.getEnable() == null : this.getEnable().equals(other.getEnable()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSvName() == null) ? 0 : getSvName().hashCode());
        result = prime * result + ((getSvCode() == null) ? 0 : getSvCode().hashCode());
        result = prime * result + ((getSvType() == null) ? 0 : getSvType().hashCode());
        result = prime * result + ((getSvLevel() == null) ? 0 : getSvLevel().hashCode());
        result = prime * result + ((getSvAreaId() == null) ? 0 : getSvAreaId().hashCode());
        result = prime * result + ((getSvAddress() == null) ? 0 : getSvAddress().hashCode());
        result = prime * result + ((getSvLeader() == null) ? 0 : getSvLeader().hashCode());
        result = prime * result + ((getSvLeaderPhone() == null) ? 0 : getSvLeaderPhone().hashCode());
        result = prime * result + ((getSvContact() == null) ? 0 : getSvContact().hashCode());
        result = prime * result + ((getSvContactPhone() == null) ? 0 : getSvContactPhone().hashCode());
        result = prime * result + ((getSvContactQQ() == null) ? 0 : getSvContactQQ().hashCode());
        result = prime * result + ((getSvContactEmail() == null) ? 0 : getSvContactEmail().hashCode());
        result = prime * result + ((getSvPostcode() == null) ? 0 : getSvPostcode().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getEnable() == null) ? 0 : getEnable().hashCode());
        return result;
    }
}