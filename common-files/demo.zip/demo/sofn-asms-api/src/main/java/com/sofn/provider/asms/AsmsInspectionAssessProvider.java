/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.asms.SuperviseCheckDto;
import com.sofn.model.generator.AsmsInspectionAssess;

import java.util.List;
import java.util.Map;

/**
 * 
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
public interface AsmsInspectionAssessProvider extends BaseProvider<AsmsInspectionAssess> {

     List<AsmsInspectionAssess> getXcUserIds(AsmsInspectionAssess taskUser);

     void  delOldDate (AsmsInspectionAssess taskUser);

     PageInfo<AsmsInspectionAssess> getPageList (Map<String, Object> params);
	 
	 PageInfo<List<Map<String, Object>>> getPages (Map<String, Object> params);

     List<SuperviseCheckDto> getSuperviseTaskInfos();

    public PageInfo getBaseInspectionAllList(Map<String,Object> map);

}
