package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsEmergencyTask;

import java.util.Map;

/**
 * Created by zhangdong on 2016/9/27 11:21.
 */
public interface SuperviseEmergencyProvider extends BaseProvider<AsmsEmergencyTask> {

    public int addAsmsEmergencyTask(AsmsEmergencyTask asmsEmergencyTask);

    public int updateAsmsEmergencyTask(AsmsEmergencyTask asmsEmergencyTask);

    public PageInfo getSuperviseEmergencyList(Map<String, Object> map);

    public AsmsEmergencyTask findAsmsEmergencyTaskById(String id);
}
