/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsCheckBearUnit;
import com.sofn.model.generator.AsmsCheckTask;
import com.sofn.model.generator.AsmsMonitorObject;

import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
public interface AsmsCheckTaskProvider extends BaseProvider<AsmsCheckTask> {

    public PageInfo<List<Map<String, Object>>> list(Map<String, Object> params);

    //插入关联表信息(抽查对象)
    public void addGlInfo(AsmsMonitorObject o);

    //删除关联表信息(抽查对象)
    public void delGlInfoByTaskId(String taskId);

    //插入关联表信息(牵头单位)
    public void addBjGlInfo(AsmsCheckBearUnit o);

    //删除关联表信息(牵头单位)
    public void delBjGlInfoByTaskId(String taskId);

    //根据id获取关联对象
    public List<Map<String,Object>> getObjById(String id);
}
