package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;

import java.util.Date;

@SuppressWarnings("serial")
public class TScltxxcjComplaint extends BaseModel {
    private String entityIdcode;

    private String userIdcode;

    private String beEntityIdcode;

    private String beUserIdcode;

    private String accEntityIdcode;

    private String accUserIdcode;

    private Date complaintTime;

    private String complaintTitle;

    private String content;

    private String type;

    private String status;

    private String acceptance;

    private String areaId;

    private Date accTime;

    private String attachmentName;

    private String complaintEntName;

    private String delFlag;

    public String getEntityIdcode() {
        return entityIdcode;
    }

    public void setEntityIdcode(String entityIdcode) {
        this.entityIdcode = entityIdcode == null ? null : entityIdcode.trim();
    }

    public String getUserIdcode() {
        return userIdcode;
    }

    public void setUserIdcode(String userIdcode) {
        this.userIdcode = userIdcode == null ? null : userIdcode.trim();
    }

    public String getBeEntityIdcode() {
        return beEntityIdcode;
    }

    public void setBeEntityIdcode(String beEntityIdcode) {
        this.beEntityIdcode = beEntityIdcode == null ? null : beEntityIdcode.trim();
    }

    public String getBeUserIdcode() {
        return beUserIdcode;
    }

    public void setBeUserIdcode(String beUserIdcode) {
        this.beUserIdcode = beUserIdcode == null ? null : beUserIdcode.trim();
    }

    public String getAccEntityIdcode() {
        return accEntityIdcode;
    }

    public void setAccEntityIdcode(String accEntityIdcode) {
        this.accEntityIdcode = accEntityIdcode == null ? null : accEntityIdcode.trim();
    }

    public String getAccUserIdcode() {
        return accUserIdcode;
    }

    public void setAccUserIdcode(String accUserIdcode) {
        this.accUserIdcode = accUserIdcode == null ? null : accUserIdcode.trim();
    }

    public Date getComplaintTime() {
        return complaintTime;
    }

    public void setComplaintTime(Date complaintTime) {
        this.complaintTime = complaintTime;
    }

    public String getComplaintTitle() {
        return complaintTitle;
    }

    public void setComplaintTitle(String complaintTitle) {
        this.complaintTitle = complaintTitle == null ? null : complaintTitle.trim();
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content == null ? null : content.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status == null ? null : status.trim();
    }

    public String getAcceptance() {
        return acceptance;
    }

    public void setAcceptance(String acceptance) {
        this.acceptance = acceptance == null ? null : acceptance.trim();
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId == null ? null : areaId.trim();
    }

    public Date getAccTime() {
        return accTime;
    }

    public void setAccTime(Date accTime) {
        this.accTime = accTime;
    }

    public String getAttachmentName() {
        return attachmentName;
    }

    public void setAttachmentName(String attachmentName) {
        this.attachmentName = attachmentName == null ? null : attachmentName.trim();
    }

    public String getComplaintEntName() {
        return complaintEntName;
    }

    public void setComplaintEntName(String complaintEntName) {
        this.complaintEntName = complaintEntName == null ? null : complaintEntName.trim();
    }

    public String getDelFlag() {
        return delFlag;
    }

    public void setDelFlag(String delFlag) {
        this.delFlag = delFlag == null ? null : delFlag.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", entityIdcode=").append(entityIdcode);
        sb.append(", userIdcode=").append(userIdcode);
        sb.append(", beEntityIdcode=").append(beEntityIdcode);
        sb.append(", beUserIdcode=").append(beUserIdcode);
        sb.append(", accEntityIdcode=").append(accEntityIdcode);
        sb.append(", accUserIdcode=").append(accUserIdcode);
        sb.append(", complaintTime=").append(complaintTime);
        sb.append(", complaintTitle=").append(complaintTitle);
        sb.append(", content=").append(content);
        sb.append(", type=").append(type);
        sb.append(", status=").append(status);
        sb.append(", acceptance=").append(acceptance);
        sb.append(", areaId=").append(areaId);
        sb.append(", accTime=").append(accTime);
        sb.append(", attachmentName=").append(attachmentName);
        sb.append(", complaintEntName=").append(complaintEntName);
        sb.append(", delFlag=").append(delFlag);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        TScltxxcjComplaint other = (TScltxxcjComplaint) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getEntityIdcode() == null ? other.getEntityIdcode() == null : this.getEntityIdcode().equals(other.getEntityIdcode()))
            && (this.getUserIdcode() == null ? other.getUserIdcode() == null : this.getUserIdcode().equals(other.getUserIdcode()))
            && (this.getBeEntityIdcode() == null ? other.getBeEntityIdcode() == null : this.getBeEntityIdcode().equals(other.getBeEntityIdcode()))
            && (this.getBeUserIdcode() == null ? other.getBeUserIdcode() == null : this.getBeUserIdcode().equals(other.getBeUserIdcode()))
            && (this.getAccEntityIdcode() == null ? other.getAccEntityIdcode() == null : this.getAccEntityIdcode().equals(other.getAccEntityIdcode()))
            && (this.getAccUserIdcode() == null ? other.getAccUserIdcode() == null : this.getAccUserIdcode().equals(other.getAccUserIdcode()))
            && (this.getComplaintTime() == null ? other.getComplaintTime() == null : this.getComplaintTime().equals(other.getComplaintTime()))
            && (this.getComplaintTitle() == null ? other.getComplaintTitle() == null : this.getComplaintTitle().equals(other.getComplaintTitle()))
            && (this.getContent() == null ? other.getContent() == null : this.getContent().equals(other.getContent()))
            && (this.getType() == null ? other.getType() == null : this.getType().equals(other.getType()))
            && (this.getStatus() == null ? other.getStatus() == null : this.getStatus().equals(other.getStatus()))
            && (this.getAcceptance() == null ? other.getAcceptance() == null : this.getAcceptance().equals(other.getAcceptance()))
            && (this.getAreaId() == null ? other.getAreaId() == null : this.getAreaId().equals(other.getAreaId()))
            && (this.getAccTime() == null ? other.getAccTime() == null : this.getAccTime().equals(other.getAccTime()))
            && (this.getAttachmentName() == null ? other.getAttachmentName() == null : this.getAttachmentName().equals(other.getAttachmentName()))
            && (this.getComplaintEntName() == null ? other.getComplaintEntName() == null : this.getComplaintEntName().equals(other.getComplaintEntName()))
            && (this.getDelFlag() == null ? other.getDelFlag() == null : this.getDelFlag().equals(other.getDelFlag()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getEntityIdcode() == null) ? 0 : getEntityIdcode().hashCode());
        result = prime * result + ((getUserIdcode() == null) ? 0 : getUserIdcode().hashCode());
        result = prime * result + ((getBeEntityIdcode() == null) ? 0 : getBeEntityIdcode().hashCode());
        result = prime * result + ((getBeUserIdcode() == null) ? 0 : getBeUserIdcode().hashCode());
        result = prime * result + ((getAccEntityIdcode() == null) ? 0 : getAccEntityIdcode().hashCode());
        result = prime * result + ((getAccUserIdcode() == null) ? 0 : getAccUserIdcode().hashCode());
        result = prime * result + ((getComplaintTime() == null) ? 0 : getComplaintTime().hashCode());
        result = prime * result + ((getComplaintTitle() == null) ? 0 : getComplaintTitle().hashCode());
        result = prime * result + ((getContent() == null) ? 0 : getContent().hashCode());
        result = prime * result + ((getType() == null) ? 0 : getType().hashCode());
        result = prime * result + ((getStatus() == null) ? 0 : getStatus().hashCode());
        result = prime * result + ((getAcceptance() == null) ? 0 : getAcceptance().hashCode());
        result = prime * result + ((getAreaId() == null) ? 0 : getAreaId().hashCode());
        result = prime * result + ((getAccTime() == null) ? 0 : getAccTime().hashCode());
        result = prime * result + ((getAttachmentName() == null) ? 0 : getAttachmentName().hashCode());
        result = prime * result + ((getComplaintEntName() == null) ? 0 : getComplaintEntName().hashCode());
        result = prime * result + ((getDelFlag() == null) ? 0 : getDelFlag().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}