package com.sofn.provider.asms;

import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.core.base.BaseProvider;
/**
 * Created by Administrator on 2016/10/12.
 */
public interface AsmsSubjSvChangeProvider extends BaseProvider<AsmsSubjSvChange> {
    //添加备案变更申请
    public int addSubjSvChange(AsmsSubjSvChange subjSvChange);
}
