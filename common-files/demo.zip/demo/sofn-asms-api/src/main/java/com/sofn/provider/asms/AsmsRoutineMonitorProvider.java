/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsRoutineMonitor;

import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
public interface AsmsRoutineMonitorProvider extends BaseProvider<AsmsRoutineMonitor> {

    public PageInfo<List<Map<String, Object>>> list(Map<String, Object> params);

    //插入关联表信息
    public void addGlInfo(String taskId,String jgId);

    //删除关联表信息
    public void delGlInfoByTaskId(String taskId);
}
