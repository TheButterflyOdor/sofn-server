package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;

import java.util.Date;

@SuppressWarnings("serial")
public class AsmsRecheckTask extends BaseModel {
    private String recheckTaskName;

    private String recheckTaskYear;

    private Date recheckTaskBegin;

    private Date recheckTaskEnd;

    private String state;

    public String getRecheckTaskName() {
        return recheckTaskName;
    }

    public void setRecheckTaskName(String recheckTaskName) {
        this.recheckTaskName = recheckTaskName == null ? null : recheckTaskName.trim();
    }

    public String getRecheckTaskYear() {
        return recheckTaskYear;
    }

    public void setRecheckTaskYear(String recheckTaskYear) {
        this.recheckTaskYear = recheckTaskYear == null ? null : recheckTaskYear.trim();
    }

    public Date getRecheckTaskBegin() {
        return recheckTaskBegin;
    }

    public void setRecheckTaskBegin(Date recheckTaskBegin) {
        this.recheckTaskBegin = recheckTaskBegin;
    }

    public Date getRecheckTaskEnd() {
        return recheckTaskEnd;
    }

    public void setRecheckTaskEnd(Date recheckTaskEnd) {
        this.recheckTaskEnd = recheckTaskEnd;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state == null ? null : state.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", recheckTaskName=").append(recheckTaskName);
        sb.append(", recheckTaskYear=").append(recheckTaskYear);
        sb.append(", recheckTaskBegin=").append(recheckTaskBegin);
        sb.append(", recheckTaskEnd=").append(recheckTaskEnd);
        sb.append(", state=").append(state);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsRecheckTask other = (AsmsRecheckTask) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getRecheckTaskName() == null ? other.getRecheckTaskName() == null : this.getRecheckTaskName().equals(other.getRecheckTaskName()))
            && (this.getRecheckTaskYear() == null ? other.getRecheckTaskYear() == null : this.getRecheckTaskYear().equals(other.getRecheckTaskYear()))
            && (this.getRecheckTaskBegin() == null ? other.getRecheckTaskBegin() == null : this.getRecheckTaskBegin().equals(other.getRecheckTaskBegin()))
            && (this.getRecheckTaskEnd() == null ? other.getRecheckTaskEnd() == null : this.getRecheckTaskEnd().equals(other.getRecheckTaskEnd()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getEnable() == null ? other.getEnable() == null : this.getEnable().equals(other.getEnable()))
            && (this.getState() == null ? other.getState() == null : this.getState().equals(other.getState()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getRecheckTaskName() == null) ? 0 : getRecheckTaskName().hashCode());
        result = prime * result + ((getRecheckTaskYear() == null) ? 0 : getRecheckTaskYear().hashCode());
        result = prime * result + ((getRecheckTaskBegin() == null) ? 0 : getRecheckTaskBegin().hashCode());
        result = prime * result + ((getRecheckTaskEnd() == null) ? 0 : getRecheckTaskEnd().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getEnable() == null) ? 0 : getEnable().hashCode());
        result = prime * result + ((getState() == null) ? 0 : getState().hashCode());
        return result;
    }
}