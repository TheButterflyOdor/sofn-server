package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;
import java.util.Date;

@SuppressWarnings("serial")
public class AsmsSubjSvChange extends BaseModel {
    private String svName;

    private String svCode;

    private String svLevel;

    private String svAddress;

    private String svAreaId;

    private String svLeader;

    private String svLeaderPhone;

    private String svFile;

    private String applyUserId;

    private Date applyTime;

    private String applySvId;

    private String applyReason;

    private String auditUserId;

    private String auditSvId;

    private Date auditTime;

    private String auditSuggestion;

    private String auditState;

    public String getSvName() {
        return svName;
    }

    public void setSvName(String svName) {
        this.svName = svName == null ? null : svName.trim();
    }

    public String getSvCode() {
        return svCode;
    }

    public void setSvCode(String svCode) {
        this.svCode = svCode == null ? null : svCode.trim();
    }

    public String getSvLevel() {
        return svLevel;
    }

    public void setSvLevel(String svLevel) {
        this.svLevel = svLevel == null ? null : svLevel.trim();
    }

    public String getSvAddress() {
        return svAddress;
    }

    public void setSvAddress(String svAddress) {
        this.svAddress = svAddress == null ? null : svAddress.trim();
    }

    public String getSvAreaId() {
        return svAreaId;
    }

    public void setSvAreaId(String svAreaId) {
        this.svAreaId = svAreaId == null ? null : svAreaId.trim();
    }

    public String getSvLeader() {
        return svLeader;
    }

    public void setSvLeader(String svLeader) {
        this.svLeader = svLeader == null ? null : svLeader.trim();
    }

    public String getSvLeaderPhone() {
        return svLeaderPhone;
    }

    public void setSvLeaderPhone(String svLeaderPhone) {
        this.svLeaderPhone = svLeaderPhone == null ? null : svLeaderPhone.trim();
    }

    public String getSvFile() {
        return svFile;
    }

    public void setSvFile(String svFile) {
        this.svFile = svFile == null ? null : svFile.trim();
    }

    public String getApplyUserId() {
        return applyUserId;
    }

    public void setApplyUserId(String applyUserId) {
        this.applyUserId = applyUserId == null ? null : applyUserId.trim();
    }

    public Date getApplyTime() {
        return applyTime;
    }

    public void setApplyTime(Date applyTime) {
        this.applyTime = applyTime;
    }

    public String getApplySvId() {
        return applySvId;
    }

    public void setApplySvId(String applySvId) {
        this.applySvId = applySvId == null ? null : applySvId.trim();
    }

    public String getApplyReason() {
        return applyReason;
    }

    public void setApplyReason(String applyReason) {
        this.applyReason = applyReason == null ? null : applyReason.trim();
    }

    public String getAuditUserId() {
        return auditUserId;
    }

    public void setAuditUserId(String auditUserId) {
        this.auditUserId = auditUserId == null ? null : auditUserId.trim();
    }

    public String getAuditSvId() {
        return auditSvId;
    }

    public void setAuditSvId(String auditSvId) {
        this.auditSvId = auditSvId == null ? null : auditSvId.trim();
    }

    public Date getAuditTime() {
        return auditTime;
    }

    public void setAuditTime(Date auditTime) {
        this.auditTime = auditTime;
    }

    public String getAuditSuggestion() {
        return auditSuggestion;
    }

    public void setAuditSuggestion(String auditSuggestion) {
        this.auditSuggestion = auditSuggestion == null ? null : auditSuggestion.trim();
    }

    public String getAuditState() {
        return auditState;
    }

    public void setAuditState(String auditState) {
        this.auditState = auditState == null ? null : auditState.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", svName=").append(svName);
        sb.append(", svCode=").append(svCode);
        sb.append(", svLevel=").append(svLevel);
        sb.append(", svAddress=").append(svAddress);
        sb.append(", svAreaId=").append(svAreaId);
        sb.append(", svLeader=").append(svLeader);
        sb.append(", svLeaderPhone=").append(svLeaderPhone);
        sb.append(", svFile=").append(svFile);
        sb.append(", applyUserId=").append(applyUserId);
        sb.append(", applyTime=").append(applyTime);
        sb.append(", applySvId=").append(applySvId);
        sb.append(", applyReason=").append(applyReason);
        sb.append(", auditUserId=").append(auditUserId);
        sb.append(", auditSvId=").append(auditSvId);
        sb.append(", auditTime=").append(auditTime);
        sb.append(", auditSuggestion=").append(auditSuggestion);
        sb.append(", auditState=").append(auditState);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsSubjSvChange other = (AsmsSubjSvChange) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSvName() == null ? other.getSvName() == null : this.getSvName().equals(other.getSvName()))
            && (this.getSvCode() == null ? other.getSvCode() == null : this.getSvCode().equals(other.getSvCode()))
            && (this.getSvLevel() == null ? other.getSvLevel() == null : this.getSvLevel().equals(other.getSvLevel()))
            && (this.getSvAddress() == null ? other.getSvAddress() == null : this.getSvAddress().equals(other.getSvAddress()))
            && (this.getSvAreaId() == null ? other.getSvAreaId() == null : this.getSvAreaId().equals(other.getSvAreaId()))
            && (this.getSvLeader() == null ? other.getSvLeader() == null : this.getSvLeader().equals(other.getSvLeader()))
            && (this.getSvLeaderPhone() == null ? other.getSvLeaderPhone() == null : this.getSvLeaderPhone().equals(other.getSvLeaderPhone()))
            && (this.getSvFile() == null ? other.getSvFile() == null : this.getSvFile().equals(other.getSvFile()))
            && (this.getApplyUserId() == null ? other.getApplyUserId() == null : this.getApplyUserId().equals(other.getApplyUserId()))
            && (this.getApplyTime() == null ? other.getApplyTime() == null : this.getApplyTime().equals(other.getApplyTime()))
            && (this.getApplySvId() == null ? other.getApplySvId() == null : this.getApplySvId().equals(other.getApplySvId()))
            && (this.getApplyReason() == null ? other.getApplyReason() == null : this.getApplyReason().equals(other.getApplyReason()))
            && (this.getAuditUserId() == null ? other.getAuditUserId() == null : this.getAuditUserId().equals(other.getAuditUserId()))
            && (this.getAuditSvId() == null ? other.getAuditSvId() == null : this.getAuditSvId().equals(other.getAuditSvId()))
            && (this.getAuditTime() == null ? other.getAuditTime() == null : this.getAuditTime().equals(other.getAuditTime()))
            && (this.getAuditSuggestion() == null ? other.getAuditSuggestion() == null : this.getAuditSuggestion().equals(other.getAuditSuggestion()))
            && (this.getAuditState() == null ? other.getAuditState() == null : this.getAuditState().equals(other.getAuditState()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSvName() == null) ? 0 : getSvName().hashCode());
        result = prime * result + ((getSvCode() == null) ? 0 : getSvCode().hashCode());
        result = prime * result + ((getSvLevel() == null) ? 0 : getSvLevel().hashCode());
        result = prime * result + ((getSvAddress() == null) ? 0 : getSvAddress().hashCode());
        result = prime * result + ((getSvAreaId() == null) ? 0 : getSvAreaId().hashCode());
        result = prime * result + ((getSvLeader() == null) ? 0 : getSvLeader().hashCode());
        result = prime * result + ((getSvLeaderPhone() == null) ? 0 : getSvLeaderPhone().hashCode());
        result = prime * result + ((getSvFile() == null) ? 0 : getSvFile().hashCode());
        result = prime * result + ((getApplyUserId() == null) ? 0 : getApplyUserId().hashCode());
        result = prime * result + ((getApplyTime() == null) ? 0 : getApplyTime().hashCode());
        result = prime * result + ((getApplySvId() == null) ? 0 : getApplySvId().hashCode());
        result = prime * result + ((getApplyReason() == null) ? 0 : getApplyReason().hashCode());
        result = prime * result + ((getAuditUserId() == null) ? 0 : getAuditUserId().hashCode());
        result = prime * result + ((getAuditSvId() == null) ? 0 : getAuditSvId().hashCode());
        result = prime * result + ((getAuditTime() == null) ? 0 : getAuditTime().hashCode());
        result = prime * result + ((getAuditSuggestion() == null) ? 0 : getAuditSuggestion().hashCode());
        result = prime * result + ((getAuditState() == null) ? 0 : getAuditState().hashCode());
        return result;
    }
}