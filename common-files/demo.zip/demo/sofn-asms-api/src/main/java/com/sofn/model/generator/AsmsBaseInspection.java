package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;
import java.util.Date;

@SuppressWarnings("serial")
public class AsmsBaseInspection extends BaseModel {
    private String enterpriseId;

    private String inspectionType;

    private String inspectionResult;

    private String inspectionView;

    private String inspectionImages;

    private Date inspectionTime;

    private String inspectionSvId;

    private String inspectionUserName;

    private String elCheckState;

    private String headSign;

    private String headSignFile;

    public String getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(String enterpriseId) {
        this.enterpriseId = enterpriseId == null ? null : enterpriseId.trim();
    }

    public String getInspectionType() {
        return inspectionType;
    }

    public void setInspectionType(String inspectionType) {
        this.inspectionType = inspectionType == null ? null : inspectionType.trim();
    }

    public String getInspectionResult() {
        return inspectionResult;
    }

    public void setInspectionResult(String inspectionResult) {
        this.inspectionResult = inspectionResult == null ? null : inspectionResult.trim();
    }

    public String getInspectionView() {
        return inspectionView;
    }

    public void setInspectionView(String inspectionView) {
        this.inspectionView = inspectionView == null ? null : inspectionView.trim();
    }

    public String getInspectionImages() {
        return inspectionImages;
    }

    public void setInspectionImages(String inspectionImages) {
        this.inspectionImages = inspectionImages == null ? null : inspectionImages.trim();
    }

    public Date getInspectionTime() {
        return inspectionTime;
    }

    public void setInspectionTime(Date inspectionTime) {
        this.inspectionTime = inspectionTime;
    }

    public String getInspectionSvId() {
        return inspectionSvId;
    }

    public void setInspectionSvId(String inspectionSvId) {
        this.inspectionSvId = inspectionSvId == null ? null : inspectionSvId.trim();
    }

    public String getInspectionUserName() {
        return inspectionUserName;
    }

    public void setInspectionUserName(String inspectionUserName) {
        this.inspectionUserName = inspectionUserName == null ? null : inspectionUserName.trim();
    }

    public String getElCheckState() {
        return elCheckState;
    }

    public void setElCheckState(String elCheckState) {
        this.elCheckState = elCheckState == null ? null : elCheckState.trim();
    }

    public String getHeadSign() {
        return headSign;
    }

    public void setHeadSign(String headSign) {
        this.headSign = headSign == null ? null : headSign.trim();
    }

    public String getHeadSignFile() {
        return headSignFile;
    }

    public void setHeadSignFile(String headSignFile) {
        this.headSignFile = headSignFile == null ? null : headSignFile.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", enterpriseId=").append(enterpriseId);
        sb.append(", inspectionType=").append(inspectionType);
        sb.append(", inspectionResult=").append(inspectionResult);
        sb.append(", inspectionView=").append(inspectionView);
        sb.append(", inspectionImages=").append(inspectionImages);
        sb.append(", inspectionTime=").append(inspectionTime);
        sb.append(", inspectionSvId=").append(inspectionSvId);
        sb.append(", inspectionUserName=").append(inspectionUserName);
        sb.append(", elCheckState=").append(elCheckState);
        sb.append(", headSign=").append(headSign);
        sb.append(", headSignFile=").append(headSignFile);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsBaseInspection other = (AsmsBaseInspection) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getEnterpriseId() == null ? other.getEnterpriseId() == null : this.getEnterpriseId().equals(other.getEnterpriseId()))
            && (this.getInspectionType() == null ? other.getInspectionType() == null : this.getInspectionType().equals(other.getInspectionType()))
            && (this.getInspectionResult() == null ? other.getInspectionResult() == null : this.getInspectionResult().equals(other.getInspectionResult()))
            && (this.getInspectionView() == null ? other.getInspectionView() == null : this.getInspectionView().equals(other.getInspectionView()))
            && (this.getInspectionImages() == null ? other.getInspectionImages() == null : this.getInspectionImages().equals(other.getInspectionImages()))
            && (this.getInspectionTime() == null ? other.getInspectionTime() == null : this.getInspectionTime().equals(other.getInspectionTime()))
            && (this.getInspectionSvId() == null ? other.getInspectionSvId() == null : this.getInspectionSvId().equals(other.getInspectionSvId()))
            && (this.getInspectionUserName() == null ? other.getInspectionUserName() == null : this.getInspectionUserName().equals(other.getInspectionUserName()))
            && (this.getElCheckState() == null ? other.getElCheckState() == null : this.getElCheckState().equals(other.getElCheckState()))
            && (this.getHeadSign() == null ? other.getHeadSign() == null : this.getHeadSign().equals(other.getHeadSign()))
            && (this.getHeadSignFile() == null ? other.getHeadSignFile() == null : this.getHeadSignFile().equals(other.getHeadSignFile()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getEnable() == null ? other.getEnable() == null : this.getEnable().equals(other.getEnable()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getEnterpriseId() == null) ? 0 : getEnterpriseId().hashCode());
        result = prime * result + ((getInspectionType() == null) ? 0 : getInspectionType().hashCode());
        result = prime * result + ((getInspectionResult() == null) ? 0 : getInspectionResult().hashCode());
        result = prime * result + ((getInspectionView() == null) ? 0 : getInspectionView().hashCode());
        result = prime * result + ((getInspectionImages() == null) ? 0 : getInspectionImages().hashCode());
        result = prime * result + ((getInspectionTime() == null) ? 0 : getInspectionTime().hashCode());
        result = prime * result + ((getInspectionSvId() == null) ? 0 : getInspectionSvId().hashCode());
        result = prime * result + ((getInspectionUserName() == null) ? 0 : getInspectionUserName().hashCode());
        result = prime * result + ((getElCheckState() == null) ? 0 : getElCheckState().hashCode());
        result = prime * result + ((getHeadSign() == null) ? 0 : getHeadSign().hashCode());
        result = prime * result + ((getHeadSignFile() == null) ? 0 : getHeadSignFile().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getEnable() == null) ? 0 : getEnable().hashCode());
        return result;
    }
}