package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;

@SuppressWarnings("serial")
public class AsmsInspectionTask extends BaseModel {
    private String taskType;

    private String taskDateType;

    private String taskDate;

    private String inspectionAreaId;

    private Long inspectionCount;

    public String getTaskType() {
        return taskType;
    }

    public void setTaskType(String taskType) {
        this.taskType = taskType == null ? null : taskType.trim();
    }

    public String getTaskDateType() {
        return taskDateType;
    }

    public void setTaskDateType(String taskDateType) {
        this.taskDateType = taskDateType == null ? null : taskDateType.trim();
    }

    public String getTaskDate() {
        return taskDate;
    }

    public void setTaskDate(String taskDate) {
        this.taskDate = taskDate == null ? null : taskDate.trim();
    }

    public String getInspectionAreaId() {
        return inspectionAreaId;
    }

    public void setInspectionAreaId(String inspectionAreaId) {
        this.inspectionAreaId = inspectionAreaId == null ? null : inspectionAreaId.trim();
    }

    public Long getInspectionCount() {
        return inspectionCount;
    }

    public void setInspectionCount(Long inspectionCount) {
        this.inspectionCount = inspectionCount;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", taskType=").append(taskType);
        sb.append(", taskDateType=").append(taskDateType);
        sb.append(", taskDate=").append(taskDate);
        sb.append(", inspectionAreaId=").append(inspectionAreaId);
        sb.append(", inspectionCount=").append(inspectionCount);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsInspectionTask other = (AsmsInspectionTask) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getTaskType() == null ? other.getTaskType() == null : this.getTaskType().equals(other.getTaskType()))
            && (this.getTaskDateType() == null ? other.getTaskDateType() == null : this.getTaskDateType().equals(other.getTaskDateType()))
            && (this.getTaskDate() == null ? other.getTaskDate() == null : this.getTaskDate().equals(other.getTaskDate()))
            && (this.getInspectionAreaId() == null ? other.getInspectionAreaId() == null : this.getInspectionAreaId().equals(other.getInspectionAreaId()))
            && (this.getInspectionCount() == null ? other.getInspectionCount() == null : this.getInspectionCount().equals(other.getInspectionCount()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getEnable() == null ? other.getEnable() == null : this.getEnable().equals(other.getEnable()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getTaskType() == null) ? 0 : getTaskType().hashCode());
        result = prime * result + ((getTaskDateType() == null) ? 0 : getTaskDateType().hashCode());
        result = prime * result + ((getTaskDate() == null) ? 0 : getTaskDate().hashCode());
        result = prime * result + ((getInspectionAreaId() == null) ? 0 : getInspectionAreaId().hashCode());
        result = prime * result + ((getInspectionCount() == null) ? 0 : getInspectionCount().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getEnable() == null) ? 0 : getEnable().hashCode());
        return result;
    }
}