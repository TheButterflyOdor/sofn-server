package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;

import java.util.Date;

@SuppressWarnings("serial")
public class AsmsMonitorObject extends BaseModel {
    private String superviseCheckTaskId;

    private String productType;

    private String productName;

    private Date taskBeginTime;

    private Date taskEndTime;

    private String sampleUnitId;

    private String detectionUnitId;

    private String detectionStandard;

    private String judgeStandard;

    private String monitorNum;

    public String getSuperviseCheckTaskId() {
        return superviseCheckTaskId;
    }

    public void setSuperviseCheckTaskId(String superviseCheckTaskId) {
        this.superviseCheckTaskId = superviseCheckTaskId == null ? null : superviseCheckTaskId.trim();
    }

    public String getProductType() {
        return productType;
    }

    public void setProductType(String productType) {
        this.productType = productType == null ? null : productType.trim();
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName == null ? null : productName.trim();
    }

    public Date getTaskBeginTime() {
        return taskBeginTime;
    }

    public void setTaskBeginTime(Date taskBeginTime) {
        this.taskBeginTime = taskBeginTime;
    }

    public Date getTaskEndTime() {
        return taskEndTime;
    }

    public void setTaskEndTime(Date taskEndTime) {
        this.taskEndTime = taskEndTime;
    }

    public String getSampleUnitId() {
        return sampleUnitId;
    }

    public void setSampleUnitId(String sampleUnitId) {
        this.sampleUnitId = sampleUnitId == null ? null : sampleUnitId.trim();
    }

    public String getDetectionUnitId() {
        return detectionUnitId;
    }

    public void setDetectionUnitId(String detectionUnitId) {
        this.detectionUnitId = detectionUnitId == null ? null : detectionUnitId.trim();
    }

    public String getDetectionStandard() {
        return detectionStandard;
    }

    public void setDetectionStandard(String detectionStandard) {
        this.detectionStandard = detectionStandard == null ? null : detectionStandard.trim();
    }

    public String getJudgeStandard() {
        return judgeStandard;
    }

    public void setJudgeStandard(String judgeStandard) {
        this.judgeStandard = judgeStandard == null ? null : judgeStandard.trim();
    }

    public String getMonitorNum() {
        return monitorNum;
    }

    public void setMonitorNum(String monitorNum) {
        this.monitorNum = monitorNum == null ? null : monitorNum.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", superviseCheckTaskId=").append(superviseCheckTaskId);
        sb.append(", productType=").append(productType);
        sb.append(", productName=").append(productName);
        sb.append(", taskBeginTime=").append(taskBeginTime);
        sb.append(", taskEndTime=").append(taskEndTime);
        sb.append(", sampleUnitId=").append(sampleUnitId);
        sb.append(", detectionUnitId=").append(detectionUnitId);
        sb.append(", detectionStandard=").append(detectionStandard);
        sb.append(", judgeStandard=").append(judgeStandard);
        sb.append(", monitorNum=").append(monitorNum);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsMonitorObject other = (AsmsMonitorObject) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSuperviseCheckTaskId() == null ? other.getSuperviseCheckTaskId() == null : this.getSuperviseCheckTaskId().equals(other.getSuperviseCheckTaskId()))
            && (this.getProductType() == null ? other.getProductType() == null : this.getProductType().equals(other.getProductType()))
            && (this.getProductName() == null ? other.getProductName() == null : this.getProductName().equals(other.getProductName()))
            && (this.getTaskBeginTime() == null ? other.getTaskBeginTime() == null : this.getTaskBeginTime().equals(other.getTaskBeginTime()))
            && (this.getTaskEndTime() == null ? other.getTaskEndTime() == null : this.getTaskEndTime().equals(other.getTaskEndTime()))
            && (this.getSampleUnitId() == null ? other.getSampleUnitId() == null : this.getSampleUnitId().equals(other.getSampleUnitId()))
            && (this.getDetectionUnitId() == null ? other.getDetectionUnitId() == null : this.getDetectionUnitId().equals(other.getDetectionUnitId()))
            && (this.getDetectionStandard() == null ? other.getDetectionStandard() == null : this.getDetectionStandard().equals(other.getDetectionStandard()))
            && (this.getJudgeStandard() == null ? other.getJudgeStandard() == null : this.getJudgeStandard().equals(other.getJudgeStandard()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()))
            && (this.getEnable() == null ? other.getEnable() == null : this.getEnable().equals(other.getEnable()))
            && (this.getMonitorNum() == null ? other.getMonitorNum() == null : this.getMonitorNum().equals(other.getMonitorNum()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSuperviseCheckTaskId() == null) ? 0 : getSuperviseCheckTaskId().hashCode());
        result = prime * result + ((getProductType() == null) ? 0 : getProductType().hashCode());
        result = prime * result + ((getProductName() == null) ? 0 : getProductName().hashCode());
        result = prime * result + ((getTaskBeginTime() == null) ? 0 : getTaskBeginTime().hashCode());
        result = prime * result + ((getTaskEndTime() == null) ? 0 : getTaskEndTime().hashCode());
        result = prime * result + ((getSampleUnitId() == null) ? 0 : getSampleUnitId().hashCode());
        result = prime * result + ((getDetectionUnitId() == null) ? 0 : getDetectionUnitId().hashCode());
        result = prime * result + ((getDetectionStandard() == null) ? 0 : getDetectionStandard().hashCode());
        result = prime * result + ((getJudgeStandard() == null) ? 0 : getJudgeStandard().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        result = prime * result + ((getEnable() == null) ? 0 : getEnable().hashCode());
        result = prime * result + ((getMonitorNum() == null) ? 0 : getMonitorNum().hashCode());
        return result;
    }
}