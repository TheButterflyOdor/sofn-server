package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.TScltxxcjComplaint;

import java.util.Map;

/**
 * Created by dwf on 2016/9/20.
 */
public interface TScltxxcjComplaintProvider extends BaseProvider<TScltxxcjComplaint> {
    // public int addSysResource(TScltxxcjComplaintProvider tScltxxcjComplaint);

    /**
     * 查询出所有的投诉
     * @param map
     * @return
     */
    public PageInfo<TScltxxcjComplaint> getTScltxxcjComplaintList(Map<String, Object> map);

    /**
     * 根据ID查找投诉
     * @param id
     * @return
     */
    public TScltxxcjComplaint findTScltxxcjComplaintById(String id);

    public int updateTScltxxcjComplaint(TScltxxcjComplaint tScltxxcjComplaint);

    //public int deleteTScltxxcjComplaint(String id);

}
