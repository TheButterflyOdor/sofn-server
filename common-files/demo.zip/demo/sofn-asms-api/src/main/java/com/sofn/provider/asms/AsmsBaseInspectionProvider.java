package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsBaseInspection;

import java.util.Map;

/**
 * @author sofn
 * @version 2016年08月25日 下午 4:32
 */
public interface AsmsBaseInspectionProvider extends BaseProvider<AsmsBaseInspection>{

    public int addBaseInspection(AsmsBaseInspection baseInspection);

    public PageInfo<AsmsBaseInspection> getBaseInspectionList(Map<String,Object> map);

    public PageInfo getBaseInspectionAllList(Map<String,Object> map);

    //暂加
    public PageInfo getEnterpriseList(Map<String,Object> map);
    //暂加
    public Map<String,Object> findEnterpriseById(String enterpriseId);

    public AsmsBaseInspection findBaseInspectionById(String id);

    public int updateBaseInspection(AsmsBaseInspection baseInspection);

    public int deleteBaseInspection(String id);
}
