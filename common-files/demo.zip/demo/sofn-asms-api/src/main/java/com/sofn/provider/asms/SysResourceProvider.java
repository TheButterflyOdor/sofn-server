package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.SysResource;

import java.util.Map;

/**
 * Created by zhangdong on 2016/9/20.
 */
public interface SysResourceProvider extends BaseProvider<SysResource> {
    public int addSysResource(SysResource sysResource);

    public PageInfo<SysResource> getSysResourceList(Map<String, Object> map);

    public SysResource findSysResourceById(String id);

    public int updateSysResource(SysResource sysResource);

    public int deleteSysResource(String id);

}
