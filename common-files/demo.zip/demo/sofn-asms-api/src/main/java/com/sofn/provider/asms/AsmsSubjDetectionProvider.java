package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProvider;
import com.sofn.model.generator.AsmsSubjDetection;
import com.sofn.model.generator.AsmsSubjDtCancel;
import com.sofn.model.generator.AsmsSubjDtChange;
import com.sofn.model.generator.AsmsSubjDtRevoke;

import java.util.Map;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:34
 */
public interface AsmsSubjDetectionProvider extends BaseProvider<AsmsSubjDetection>{

    public int addSubjDetection(AsmsSubjDetection subjDetection);

    public AsmsSubjDetection findSubjDetectionById(String id);

    public PageInfo getSubjDetectionList(Map<String, Object> map);

    public int addSubjDtRevoke(AsmsSubjDtRevoke subjDtRevoke);

    public PageInfo getSubjDtChangeList(Map<String, Object> map);

    public AsmsSubjDtChange findSubjDtChangeById(String id);

    public void auditSubjDtChange(AsmsSubjDetection subjDetection, AsmsSubjDtChange subjDtChange);

    public PageInfo getSubjDtCancelList(Map<String, Object> map);

    public AsmsSubjDtCancel findSubjDtCancelById(String id);

    public void auditSubjDtCancel(AsmsSubjDetection subjDetection, AsmsSubjDtCancel subjDtCancel);

    public PageInfo getSubjDtRevokeList(Map<String, Object> map);

    public AsmsSubjDtRevoke findSubjDtRevokeById(String id);

    public void auditSubjDtRevoke(AsmsSubjDetection subjDetection, AsmsSubjDtRevoke subjDtRevoke);
}
