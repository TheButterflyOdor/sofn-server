package com.sofn.model.generator;

import com.sofn.core.base.BaseModel;

@SuppressWarnings("serial")
public class AsmsSubjSvModifylog extends BaseModel {
    private String svId;

    private String svModifylog;

    public String getSvId() {
        return svId;
    }

    public void setSvId(String svId) {
        this.svId = svId == null ? null : svId.trim();
    }

    public String getSvModifylog() {
        return svModifylog;
    }

    public void setSvModifylog(String svModifylog) {
        this.svModifylog = svModifylog == null ? null : svModifylog.trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(getClass().getSimpleName());
        sb.append(" [");
        sb.append("Hash = ").append(hashCode());
        sb.append(", svId=").append(svId);
        sb.append(", svModifylog=").append(svModifylog);
        sb.append("]");
        return sb.toString();
    }

    @Override
    public boolean equals(Object that) {
        if (this == that) {
            return true;
        }
        if (that == null) {
            return false;
        }
        if (getClass() != that.getClass()) {
            return false;
        }
        AsmsSubjSvModifylog other = (AsmsSubjSvModifylog) that;
        return (this.getId() == null ? other.getId() == null : this.getId().equals(other.getId()))
            && (this.getSvId() == null ? other.getSvId() == null : this.getSvId().equals(other.getSvId()))
            && (this.getSvModifylog() == null ? other.getSvModifylog() == null : this.getSvModifylog().equals(other.getSvModifylog()))
            && (this.getCreateBy() == null ? other.getCreateBy() == null : this.getCreateBy().equals(other.getCreateBy()))
            && (this.getCreateTime() == null ? other.getCreateTime() == null : this.getCreateTime().equals(other.getCreateTime()))
            && (this.getUpdateBy() == null ? other.getUpdateBy() == null : this.getUpdateBy().equals(other.getUpdateBy()))
            && (this.getUpdateTime() == null ? other.getUpdateTime() == null : this.getUpdateTime().equals(other.getUpdateTime()));
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((getId() == null) ? 0 : getId().hashCode());
        result = prime * result + ((getSvId() == null) ? 0 : getSvId().hashCode());
        result = prime * result + ((getSvModifylog() == null) ? 0 : getSvModifylog().hashCode());
        result = prime * result + ((getCreateBy() == null) ? 0 : getCreateBy().hashCode());
        result = prime * result + ((getCreateTime() == null) ? 0 : getCreateTime().hashCode());
        result = prime * result + ((getUpdateBy() == null) ? 0 : getUpdateBy().hashCode());
        result = prime * result + ((getUpdateTime() == null) ? 0 : getUpdateTime().hashCode());
        return result;
    }
}