package com.sofn.model.asms;

import java.io.Serializable;

/**
 * Created by LIB on 2016/9/27.
 */
public class RmAndQtUnit implements Serializable {

}
