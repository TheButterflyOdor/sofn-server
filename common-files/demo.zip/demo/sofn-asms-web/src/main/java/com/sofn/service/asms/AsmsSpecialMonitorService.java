package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsSpecialMonitor;
import com.sofn.provider.asms.AsmsSpecialMonitorProvider;
import jodd.util.StringUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@Service
public class AsmsSpecialMonitorService extends BaseService<AsmsSpecialMonitorProvider, AsmsSpecialMonitor> {
    @DubboReference
    public void setProvider(AsmsSpecialMonitorProvider provider) {
        this.provider = provider;
    }

    public void addTask(AsmsSpecialMonitor r, String qtIds) {
        r.setSmState("0");//待发布
        String id = provider.update(r).getId();//主表信息
        //关联表信息
        String[] ids = qtIds.split("\\|");
        for (String oid : ids) {
            provider.addGlInfo(id,oid);
        }
    }

    public void updateTask(AsmsSpecialMonitor r, String qtIds) {
        AsmsSpecialMonitor o = provider.queryById(r.getId());
        o.setSmName(r.getSmName());
        o.setSmType(r.getSmType());
        o.setSmModelId(r.getSmModelId());
        o.setSmYear(r.getSmYear());
        o.setSmBatch(r.getSmBatch());
        o.setSmDateBegin(r.getSmDateBegin());
        o.setSmDateEnd(r.getSmDateEnd());
        o.setSmReleaseUnit(r.getSmReleaseUnit());
        o.setSmFile(r.getSmFile());
        o.setSmFileNum(r.getSmFileNum());
        o.setSmRemark(r.getSmRemark());
        provider.update(o);//主表信息
        //关联表信息
        provider.delGlInfoByTaskId(r.getId());//删除原数据
        String[] ids = qtIds.split("\\|");
        for (String oid : ids) {
            provider.addGlInfo(r.getId(),oid);//新数据添加
        }
    }

    public PageInfo<List<Map<String, Object>>> list(AsmsSpecialMonitor r, String dateBegin, String dateEnd, int pageNum, int pageSize) {
        Map<String, Object> params = new HashMap<>();
        //page
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        //query
        params.put("dateBegin", StringUtil.isNotBlank(dateBegin) ? dateBegin : null);
        params.put("dateEnd", StringUtil.isNotBlank(dateEnd) ? dateEnd : null);
        //
        params.put("smName", StringUtil.isNotBlank(r.getSmName()) ? "%"+r.getSmName()+"%" : null);
        params.put("smState", StringUtil.isNotBlank(r.getSmState()) ? r.getSmState() : null);
        PageInfo<List<Map<String, Object>>> i = provider.list(params);
        return i;
    }

    public Object rel() {
        return null;
    }

    public Object abo() {
        return null;
    }

    public Object export() {
        return null;
    }

    public Object querypre() {
        return null;
    }

    public Object download() {
        return null;
    }

}
