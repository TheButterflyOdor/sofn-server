package com.sofn.web.asms;

/**
 * Created by Administrator on 2016/9/20.
 */

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.generator.SysResource;
import com.sofn.service.asms.SysResourceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author dongwenfeng
 * @version 2016年09月20日 下午 5:05
 */
@RestController
@Api(value = "专家信息", description = "专家信息")
@RequestMapping(value = "/sysResource",method = RequestMethod.POST)
public class SysResourceController extends BaseController {

    @Autowired
    private SysResourceService sysResourceService;
    /**
     * "新增日常执法任务--修改日常执法
     *
     * @param
     * @return
     */
//    @ApiOperation(value = "新增日常执法任务/修改日常执法任务")
//    @RequestMapping(value = "/addSysResource", method = RequestMethod.POST)
//    public Map<String, Object> addSysResource(@RequestBody SysResource sysResource) {
//        sysResourceService.addSysResource(sysResource);
//        Map<String, Object> map = new HashMap<String, Object>();
//        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
//        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
//        return map;
//    }

    /**
     * 根据条件获取日常执法任务
     *
     * @param
     * @return
     */
    @ApiOperation(value = "获取专家信息列表")
    @RequestMapping(value = "/getSysResourceList", method = RequestMethod.POST)
    public Map<String, Object> getSysResourceList(SysResource sysResource,String domain,String location,int start,int length, String queryCon) {
        PageInfo<SysResource> pageInfo = sysResourceService.getSysResourceList(sysResource,domain,location,
                ((start+1)/length)+1,length,queryCon);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",pageInfo);
        return map;
    }

    /**
     * 根据ID获取单个专家信息
     *
     * @param
     * @return
     */
    @ApiOperation(value = "获取单个专家信息")
    @RequestMapping(value = "/getSysResourceById", method = RequestMethod.POST)
    public Map<String, Object> findSysResourceById(@RequestBody SysResource sysResource) {
        sysResource = sysResourceService.findSysResource(sysResource.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("sysResource",sysResource);
        return map;
    }

    /**
     * 修改日常执法任务
     *
     * @param
     * @return
     */
//    @ApiOperation(value = "修改专家信息")
//    @RequestMapping(value = "/updateDailyEnforceLaw", method = RequestMethod.POST)
//    public Map<String, Object> updateDailyEnforceLaw(@RequestBody SuperviseEmergency superviseEmergency) {
//        return null;
//    }

    /**
     * 删除日常执法任务
     *
     * @param
     * @return
     */
//    @ApiOperation(value = "删除专家信息")
//    @RequestMapping(value = "/deleteDailyEnforceLaw", method = RequestMethod.POST)
//    public Map<String, Object> deleteDailyEnforceLaw() {
//
//        return null;
//    }
}
