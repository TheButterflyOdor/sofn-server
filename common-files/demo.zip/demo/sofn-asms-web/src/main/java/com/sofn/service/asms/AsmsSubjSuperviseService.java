package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.core.util.*;
import com.sofn.core.util.DateUtil;
import com.sofn.model.generator.AsmsSubjSupervise;
import com.sofn.model.generator.AsmsSubjSvCancel;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.model.generator.AsmsSubjSvRevoke;
import com.sofn.provider.asms.AsmsSubjSuperviseProvider;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.*;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:29
 */
@Service
public class AsmsSubjSuperviseService extends BaseService<AsmsSubjSuperviseProvider,AsmsSubjSupervise>{

    @DubboReference
    public void setSubjSuperviseProvider(AsmsSubjSuperviseProvider provider){
        this.provider = provider;
    }

    public int addSubjSupervise(AsmsSubjSupervise subjSupervise){
        subjSupervise.setId(UUID.randomUUID().toString().replace("-", ""));
        subjSupervise.setCreateBy("暂无");
        subjSupervise.setCreateTime(new Date());
        subjSupervise.setEnable(true);
        return provider.addSubjSupervise(subjSupervise);
    }

    public AsmsSubjSupervise findSubjSuperviseById(AsmsSubjSupervise subjSupervise){
        return provider.findSubjSuperviseById(subjSupervise.getId());
    }

    public PageInfo getSubjSuperviseList(AsmsSubjSupervise subjSupervise,int pageNum,int pageSize,String dateBegin,String dateEnd){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("svLevel",subjSupervise.getSvLevel());
        queryMap.put("svName",subjSupervise.getSvName());
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        queryMap.put("dateBegin", dateBegin);
        queryMap.put("dateEnd", dateEnd);
        return provider.getSubjSuperviseList(queryMap);
    }

    public int addSubjSvRevoke(AsmsSubjSvRevoke subjSvRevoke){
        subjSvRevoke.setId(UUID.randomUUID().toString().replace("-",""));
        subjSvRevoke.setApplyTime(new Date());
        subjSvRevoke.setApplySvId("29daee6600264e7fb2795eb17434fbcc");
        subjSvRevoke.setApplyUserId("暂无");
        return provider.addSubjSvRevoke(subjSvRevoke);
    }

    public void importSubjSupervise(HttpServletRequest request) throws Exception{
        //创建一个基于磁盘的文件项的工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        //设置工厂约束
        factory.setSizeThreshold(4096);//设置缓冲区大小，这里是4kb
        //创建一个新的文件上传机制
        ServletFileUpload upload = new ServletFileUpload(factory);
        //设置整体请求大小约束
        upload.setFileSizeMax(4194304);// 设置最大文件尺寸，这里是4MB
        //可能有多个文件
        List<FileItem> items;
        items = upload.parseRequest(request);
        Iterator<FileItem> iterator = items.iterator();
        while(iterator.hasNext()){
            InputStream inputStream = iterator.next().getInputStream();
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet;
            for(int sheetIndex = 0;sheetIndex<workbook.getNumberOfSheets();sheetIndex++){//循环Sheet
                sheet = workbook.getSheetAt(sheetIndex);
                int rowNum = sheet.getLastRowNum()+1;//有多少行
                for(int rowIndex = 1;rowIndex<rowNum;rowIndex++){//循环Sheet里面的row
                    Row row = sheet.getRow(rowIndex);
                    AsmsSubjSupervise subjectSupervise = new AsmsSubjSupervise();
                    for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){//循环row里的单元格
                        Cell cell = row.getCell(cellIndex);
                        String cellContent = this.getCellValue(cell);
                        if(cellIndex==0) {
                            subjectSupervise.setSvName(cellContent);
                        }else if(cellIndex==1){
                            subjectSupervise.setSvCode(cellContent);
                        }else if(cellIndex==2){
                            subjectSupervise.setSvLevel(cellContent);
                        }else if(cellIndex==3){
                            subjectSupervise.setSvAreaId(cellContent);
                        }else if(cellIndex==4){
                            subjectSupervise.setSvAddress(cellContent);
                        }else if(cellIndex==5){
                            subjectSupervise.setSvLeader(cellContent);
                        }else if(cellIndex==6){
                            subjectSupervise.setSvLeaderPhone(cellContent);
                        }else if(cellIndex==7){
                            subjectSupervise.setSvContact(cellContent);
                        }else if(cellIndex==8){
                            subjectSupervise.setSvContactPhone(cellContent);
                        }else if(cellIndex==9){
                            subjectSupervise.setSvContactQQ(cellContent);
                        }else if(cellIndex==10){
                            subjectSupervise.setSvContactEmail(cellContent);
                        }else if(cellIndex==11){
                            subjectSupervise.setSvPostcode(cellContent);
                        }
                    }
                    this.addSubjSupervise(subjectSupervise);
                }
            }
        }
    }

    /**
     * 查询监管机构主体变更申请列表
     * @param subjSvChange
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjSvChangeList(AsmsSubjSvChange subjSvChange,int pageNum,int pageSize,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("svName",subjSvChange.getSvName());
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjSvChangeList(queryMap);
    }

    /**
     * 通过ID获取单个监管机构主体变更申请
     * @param subjSvChange
     * @return
     */
    public AsmsSubjSvChange findSubjSvChangeById(AsmsSubjSvChange subjSvChange){
        return provider.findSubjSvChangeById(subjSvChange.getId());
    }

    /**
     * 审核监管机构主体变更
     * @param subjSvChange
     */
    public void auditSubjSvChange(AsmsSubjSvChange subjSvChange){
        subjSvChange.setAuditTime(new Date());
        AsmsSubjSupervise subjSupervise = new AsmsSubjSupervise();
        subjSupervise.setId(subjSvChange.getApplySvId());
        subjSupervise = this.findSubjSuperviseById(subjSupervise);
        provider.auditSubjSvChange(subjSupervise, subjSvChange);
    }

    /**
     * 查询监管机构主体注销申请列表
     * @param subjSvCancel
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjSvCancelList(AsmsSubjSvCancel subjSvCancel,int pageNum,int pageSize,String date,String svName){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        queryMap.put("date",date);
        queryMap.put("svName",svName);
        return provider.getSubjSvCancelList(queryMap);
    }

    /**
     * 通过ID获取单个监管机构主体注销申请
     * @param subjSvCancel
     * @return
     */
    public AsmsSubjSvCancel findSubjSvCancelById(AsmsSubjSvCancel subjSvCancel){
        return provider.findSubjSvCancelById(subjSvCancel.getId());
    }

    /**
     * 审核监管机构主体注销申请
     * @param subjSvCancel
     */
    public void auditSubjSvCancel(AsmsSubjSvCancel subjSvCancel){
        subjSvCancel.setAuditTime(new Date());
        AsmsSubjSupervise subjSupervise = new AsmsSubjSupervise();
        subjSupervise.setId(subjSvCancel.getSvId());
        subjSupervise = this.findSubjSuperviseById(subjSupervise);
        provider.auditSubjSvCancel(subjSupervise, subjSvCancel);
    }

    /**
     * 查询监管机构主体撤销申请列表
     * @param subjSvRevoke
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjSvRevokeList(AsmsSubjSvRevoke subjSvRevoke,int pageNum,int pageSize,String date,String svName){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        queryMap.put("date",date);
        queryMap.put("svName",svName);
        return provider.getSubjSvRevokeList(queryMap);
    }

    /**
     * 通过ID获取单个监管机构主体撤销申请
     * @param subjSvRevoke
     * @return
     */
    public AsmsSubjSvRevoke findSubjSvRevokeById(AsmsSubjSvRevoke subjSvRevoke){
        return provider.findSubjSvRevokeById(subjSvRevoke.getId());
    }

    /**
     * 审核监管机构主体撤销申请
     * @param subjSvRevoke
     */
    public void auditSubjSvRevoke(AsmsSubjSvRevoke subjSvRevoke){
        subjSvRevoke.setAuditTime(new Date());
        AsmsSubjSupervise subjSupervise = new AsmsSubjSupervise();
        subjSupervise.setId(subjSvRevoke.getSvId());
        subjSupervise = this.findSubjSuperviseById(subjSupervise);
        provider.auditSubjSvRevoke(subjSupervise,subjSvRevoke);
    }

    /**
     * 单纯上传文件--暂加
     * @param request
     * @throws Exception
     */
    public Map<String,Object> upload(HttpServletRequest request) throws Exception{
        //创建一个基于磁盘的文件项的工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        //设置工厂约束
        factory.setSizeThreshold(4096);//设置缓冲区大小，这里是4kb
        //创建一个新的文件上传机制
        ServletFileUpload upload = new ServletFileUpload(factory);
        //设置整体请求大小约束
        upload.setFileSizeMax(4194304);// 设置最大文件尺寸，这里是4MB
        //可能有多个文件
        List<FileItem> items;
        items = upload.parseRequest(request);
        Iterator<FileItem> iterator = items.iterator();
        String tomcatPath = request.getSession().getServletContext().getRealPath("")+"\\uploadFile\\baseInspection\\"
                +com.sofn.core.util.DateUtil.getDateTime("yyyyMMdd");
        File fileD = new File(tomcatPath);
        if(!fileD.exists()){
            fileD.mkdir();
        }
        //文件路径
        StringBuilder sb = new StringBuilder();
        byte[] imgByte = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while(iterator.hasNext()){
            FileItem fileItem = iterator.next();
            InputStream inputStream = fileItem.getInputStream();
            if(fileItem.getName()!=null) {
                String fileName = UUID.randomUUID().toString().replace("-", "") + fileItem.getName().substring(fileItem.getName().lastIndexOf("."),fileItem.getName().length());
                File file = new File(tomcatPath +"\\"+ fileName);
                sb.append("uploadFile/baseInspection/"+com.sofn.core.util.DateUtil.getDateTime("yyyyMMdd") +"/" + fileName);
                fileItem.write(file);

//            int ch;
//            while((ch=inputStream.read())!=-1){
//                byteArrayOutputStream.write(ch);
//            }
                imgByte = IOUtils.toByteArray(inputStream);
                for(int i=0;i<imgByte.length;i++){
                    System.out.print(imgByte[i]);
                }
            }

        }
        Map<String,Object> map = new HashMap<>();
        map.put("path",sb.toString());
        map.put("img",imgByte);
        return map;
    }

    public String getCellValue(Cell cell){
        String value = "";
        switch(cell.getCellType()){
            case Cell.CELL_TYPE_STRING:
                value = cell.getRichStringCellValue().toString();
                break;
            case Cell.CELL_TYPE_NUMERIC:
                value = cell.getNumericCellValue()+"";
                break;
            case Cell.CELL_TYPE_FORMULA:
                value = String.valueOf(cell.getCellFormula());
                break;
            case Cell.CELL_TYPE_BOOLEAN:
                value = String.valueOf(cell.getBooleanCellValue());
                break;
            case Cell.CELL_TYPE_ERROR:
                value = String.valueOf(cell.getErrorCellValue());
                break;
        }
        return value;
    }
}
