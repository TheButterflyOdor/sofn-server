package com.sofn.web.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.core.support.HttpCode;
import com.sofn.model.generator.AsmsSubjDetection;
import com.sofn.model.generator.AsmsSubjDtCancel;
import com.sofn.model.generator.AsmsSubjDtChange;
import com.sofn.model.generator.AsmsSubjDtRevoke;
import com.sofn.service.asms.AsmsSubjDetectionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:28
 */
@RestController
@Api(value = "主体管理-检测机构",description = "主体管理-检测机构")
@RequestMapping(value = "/subjDetection",method = RequestMethod.POST)
public class AsmsSubjDetectionController extends BaseController{

    @Autowired
    private AsmsSubjDetectionService subjDetectionService;

    /**
     * 新增检测机构主体
     * @param subjDetection
     * @return
     */
    @ApiOperation(value = "新增检测机构主体备案")
    @RequestMapping(value = "/addSubjDetection")
    public Object addSubjDetection(@RequestBody AsmsSubjDetection subjDetection){
        int result = subjDetectionService.addSubjDetection(subjDetection);
        if(result==1){
            return setSuccessModelMap(new ModelMap());
        }else {
            return setModelMap(new ModelMap(), HttpCode.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 根据ID获取单个检测机构主体详情
     * @param subjDetection
     * @return
     */
    @ApiOperation(value = "查看检测机构主体详情")
    @RequestMapping(value = "/findSubjDetectionById")
    public Object findSubjDetectionById(@RequestBody AsmsSubjDetection subjDetection){
        subjDetection = subjDetectionService.findSubjDetectionById(subjDetection);
        return setSuccessModelMap(new ModelMap(),subjDetection);
    }

    /**
     * 根据查询条件获取检测机构主体列表
     * @param subjDetection
     * @param start
     * @param length
     * @param date
     * @return
     */
    @ApiOperation(value = "根据条件获取检测机构主体列表")
    @RequestMapping(value = "/getSubjDetectionList")
    public Object getSubjDetectionList(AsmsSubjDetection subjDetection,int start,int length,String date){
        Object object = subjDetectionService.getSubjDetectionList(subjDetection, ((start + 1) / length) + 1, length,date);
        return setSuccessModelMap(new ModelMap(),object);
    }

    /**
     * 新增检测机构主体撤销申请
     * @param subjDtRevoke
     * @return
     */
    @ApiOperation(value = "新增检测机构主体撤销申请")
    @RequestMapping(value = "/addSubjDtRevoke")
    public Object addSubjDtRevoke(@RequestBody AsmsSubjDtRevoke subjDtRevoke){
        int result = subjDetectionService.addSubjDtRevoke(subjDtRevoke);
        if(result==1){
            return setSuccessModelMap(new ModelMap());
        }else {
            return setModelMap(new ModelMap(),HttpCode.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 批量导入检测机构主体
     * @param request
     * @return
     */
    @ApiOperation(value = "批量导入检测机构主体")
    @RequestMapping(value = "/importSubjDetection")
    public Object importSubjDetection(HttpServletRequest request)throws Exception{
        subjDetectionService.importSubjDetection(request);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 通过条件获取检测机构主体变更申请
     * @param subjDtChange
     * @param start
     * @param length
     * @param date
     * @return
     */
    @ApiOperation(value = "获取检测机构主体变更申请列表")
    @RequestMapping(value = "/getSubjDtChangeList")
    public Object getSubjDtChangeList(AsmsSubjDtChange subjDtChange,int start,int length,String date){
        PageInfo pageInfo = subjDetectionService.getSubjDtChangeList(subjDtChange, ((start + 1) / length) + 1, length,date);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个检测机构主体变更申请
     * @param subjDtChange
     * @return
     */
    @ApiOperation(value = "通过ID获取单个检测机构主体变更申请")
    @RequestMapping(value = "/findSubjDtChangeById")
    public Object findSubjDtChangeById(@RequestBody AsmsSubjDtChange subjDtChange){
        Map<String,Object> map = new HashMap<>();
        subjDtChange = subjDetectionService.findSubjDtChangeById(subjDtChange);
        map.put("subjDtChange",subjDtChange);
        AsmsSubjDetection subjDetection = new AsmsSubjDetection();
        subjDetection.setId(subjDtChange.getApplyDtId());
        subjDetection = subjDetectionService.findSubjDetectionById(subjDetection);
        map.put("subjDt",subjDetection);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核检测机构主体变更申请
     * @param subjDetection
     * @param subjDtChange
     * @return
     */
    @ApiOperation(value = "审核检测机构主体变更申请")
    @RequestMapping(value = "/auditSubjDtChange")
    public Object auditSubjDtChange(AsmsSubjDetection subjDetection,AsmsSubjDtChange subjDtChange){
        subjDetectionService.auditSubjDtChange(subjDetection, subjDtChange);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 获取检测机构主体注销申请列表
     * @param subjDtCancel
     * @param start
     * @param length
     * @param dtName
     * @param date
     * @return
     */
    @ApiOperation(value = "获取检测机构主体注销申请列表")
    @RequestMapping(value = "/getSubjDtCancelList")
    public Object getSubjDtCancelList(AsmsSubjDtCancel subjDtCancel,int start,int length,String dtName,String date){
        PageInfo pageInfo = subjDetectionService.getSubjDtCancelList(subjDtCancel, ((start + 1) / length) + 1, length,dtName,date);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个检测机构主体注销申请
     * @param subjDtCancel
     * @return
     */
    @ApiOperation(value = "通过ID获取单个检测机构主体注销申请")
    @RequestMapping(value = "/findSubjDtCancelById")
    public Object findSubjDtCancelById(@RequestBody AsmsSubjDtCancel subjDtCancel){
        Map<String,Object> map = new HashMap<>();
        subjDtCancel = subjDetectionService.findSubjDtCancelById(subjDtCancel);
        map.put("subjDtCancel",subjDtCancel);
        AsmsSubjDetection subjDetection = new AsmsSubjDetection();
        subjDetection.setId(subjDtCancel.getDtId());
        subjDetection = subjDetectionService.findSubjDetectionById(subjDetection);
        map.put("subjDt",subjDetection);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核检测机构主体注销申请
     * @param subjDetection
     * @param subjDtCancel
     * @return
     */
    @ApiOperation(value = "审核检测机构主体注销申请")
    @RequestMapping(value = "/auditSubjDtCancel")
    public Object auditSubjDtCancel(AsmsSubjDetection subjDetection,AsmsSubjDtCancel subjDtCancel){
        subjDetectionService.auditSubjDtCancel(subjDetection, subjDtCancel);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 通过条件获取检测机构主体撤销申请
     * @param subjDtRevoke
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取检测机构主体撤销申请")
    @RequestMapping(value = "/getSubjDtRevokeList")
    public Object getSubjDtRevokeList(AsmsSubjDtRevoke subjDtRevoke,int start,int length,String dtName,String date){
        PageInfo pageInfo = subjDetectionService.getSubjDtRevokeList(subjDtRevoke, ((start + 1) / length) + 1, length,dtName,date);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个检测机构主体撤销申请
     * @param subjDtRevoke
     * @return
     */
    @ApiOperation(value = "通过ID获取单个检测机构主体撤销申请")
    @RequestMapping(value = "/findSubjDtRevokeById")
    public Object findSubjDtRevokeById(@RequestBody AsmsSubjDtRevoke subjDtRevoke){
        Map<String,Object> map = new HashMap<>();
        subjDtRevoke = subjDetectionService.findSubjDtRevokeById(subjDtRevoke);
        map.put("subjDtRevoke",subjDtRevoke);
        AsmsSubjDetection subjDetection = new AsmsSubjDetection();
        subjDetection.setId(subjDtRevoke.getDtId());
        subjDetection = subjDetectionService.findSubjDetectionById(subjDetection);
        map.put("subjDt",subjDetection);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核检测机构主体撤销申请
     * @param subjDetection
     * @param subjDtRevoke
     * @return
     */
    @ApiOperation(value = "审核检测机构主体撤销申请")
    @RequestMapping(value = "/auditSubjDtRevoke")
    public Object auditSubjDtRevoke(AsmsSubjDetection subjDetection,AsmsSubjDtRevoke subjDtRevoke){
        subjDetectionService.auditSubjDtRevoke(subjDetection, subjDtRevoke);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 单纯上传文件--暂加
     * @param request
     * @return
     */
    @ApiOperation(value = "上传文件")
    @RequestMapping(value = "/upload")
    public Map<String,Object> upload(HttpServletRequest request){
        //返回对象
        Map<String,Object> map = new HashMap<>();
        try {
            map.putAll(subjDetectionService.upload(request));
        }catch (Exception e){
            map.put(ApiConstants.CODE,ApiMsgConstants.FAILED_CODE);
            map.put(ApiConstants.MSG,ApiMsgConstants.FAILED_MSG);
        }
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG,ApiMsgConstants.SUCCESS_MSG);
        return map;
    }
}
