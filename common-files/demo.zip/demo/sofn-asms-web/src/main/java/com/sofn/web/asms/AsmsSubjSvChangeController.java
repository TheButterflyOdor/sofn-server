package com.sofn.web.asms;

import com.sofn.core.base.BaseController;
import com.sofn.core.support.HttpCode;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.service.asms.AsmsSubjSvChangeService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by Administrator on 2016/10/12.
 */
@RestController
@Api(value = "主体管理-监管机构备案变更",description = "主体管理-监管机构备案变更")
@RequestMapping(value = "/subjSvChange",method = RequestMethod.POST)
public class AsmsSubjSvChangeController extends BaseController {

    @Autowired
    private AsmsSubjSvChangeService subjSvChangeService;

    /**
     * 新增监管机构主体
     *
     * @param subjSvChange
     * @return
     */
    @ApiOperation(value = "监管机构主体备案变更申请")
    @RequestMapping(value = "/addSubjSvChange")
    public Object addSubjSvChange(@RequestBody AsmsSubjSvChange subjSvChange) {
        int result = subjSvChangeService.addSubjSvChange(subjSvChange);
        if (result == 1) {
            return setSuccessModelMap(new ModelMap());
        } else {
            return setModelMap(new ModelMap(), HttpCode.INTERNAL_SERVER_ERROR);
        }
    }
}
