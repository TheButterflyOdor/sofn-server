package com.sofn.web.asms;

/**
 * Created by Administrator on 2016/9/20.
 */

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.generator.TScltxxcjComplaint;
import com.sofn.service.asms.TScltxxcjComplaintService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

/**
 * @author dongwenfeng
 * @version 2016年09月20日 下午 5:05
 */
@RestController
@Api(value = "投诉处理", description = "投诉处理")
@RequestMapping(value = "/tScltxxcjComplaint",method = RequestMethod.POST)
public class TScltxxcjComplaintController extends BaseController {

    @Autowired
    private TScltxxcjComplaintService tScltxxcjComplaintService;
    /**
     * 投诉处理
     *
     * @param
     * @return
     */
    @ApiOperation(value = "投诉处理")
    @RequestMapping(value = "/updateTScltxxcjComplaint", method = RequestMethod.POST)
    public Map<String, Object> updateTScltxxcjComplaint(@RequestBody TScltxxcjComplaint tScltxxcjComplaint) {
        TScltxxcjComplaint  tScltxxcjComplaints=tScltxxcjComplaintService.findTScltxxcjComplaint(tScltxxcjComplaint.getId());
        tScltxxcjComplaints.setAcceptance(tScltxxcjComplaint.getAcceptance());
        tScltxxcjComplaints.setStatus("1");
        tScltxxcjComplaintService.updatetScltxxcjComplaint(tScltxxcjComplaints);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    /**
     * 根据条件获取日常执法任务
     *
     * @param
     * @return
     */
    @ApiOperation(value = "获取投诉处理列表")
    @RequestMapping(value = "/getTScltxxcjComplaintList", method = RequestMethod.POST)
        public Map<String, Object> getTScltxxcjComplaintList(TScltxxcjComplaint tScltxxcjComplaint, String entityIdcode, String beEntityIdcode,
                                                         String complaintTitle,String status,int start,int length, String queryCon) {
        PageInfo<TScltxxcjComplaint> pageInfo = tScltxxcjComplaintService.getTScltxxcjComplaintList(tScltxxcjComplaint,entityIdcode,beEntityIdcode,complaintTitle,status,
                ((start+1)/length)+1,length,queryCon);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",pageInfo);
        return map;
    }

    /**
     * 根据ID获取单个专家信息
     *
     * @param
     * @return
     */
    @ApiOperation(value = "获取单个投诉处理")
    @RequestMapping(value = "/getTScltxxcjComplaintById", method = RequestMethod.POST)
    public Map<String, Object> findTScltxxcjComplaintById(@RequestBody TScltxxcjComplaint tScltxxcjComplaint) {
        tScltxxcjComplaint = tScltxxcjComplaintService.findTScltxxcjComplaint(tScltxxcjComplaint.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("tScltxxcjComplaint",tScltxxcjComplaint);
        return map;
    }
}
