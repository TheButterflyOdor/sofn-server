/**
 *
 */
package com.sofn.web.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.asms.SuperviseTaskInfo;
import com.sofn.model.generator.AsmsBaseInspection;
import com.sofn.model.generator.AsmsInspectionAssess;
import com.sofn.model.generator.AsmsInspectionTask;
import com.sofn.service.asms.AsmsBaseInspectionService;
import com.sofn.service.asms.AsmsInspectionAssessService;
import com.sofn.service.asms.AsmsInspectionTaskService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import jodd.util.StringUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * 巡查人员考核控制器
 *
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@RestController
@Api(value = "巡查人员考核", description = "巡查人员考核")
@RequestMapping(value = "/tspinstask", method = RequestMethod.POST)
public class AsmsInspectionTaskController extends BaseController {
    private static Logger logger = Logger.getLogger("AsmsInspectionTaskController");
    @Autowired
    private AsmsInspectionTaskService taskService;
    @Autowired
    private AsmsInspectionAssessService assessService;
    @Autowired
    private AsmsBaseInspectionService baseInspectionService;

    @ApiOperation(value = "新增任务")
//    @RequiresPermissions("asms.task.add")
    @RequestMapping(value = "/add")
    public Object add(HttpServletRequest request, @RequestBody SuperviseTaskInfo taskInfo) {
        String id;//新增任务信息id
        Map<String, Object> map = new HashMap<String, Object>();
        /*-新增任务信息-*/
        AsmsInspectionTask task = new AsmsInspectionTask();
        task.setEnable(true);//任务状态正常
        task.setTaskType(taskInfo.getTaskType());
        task.setTaskDateType(taskInfo.getTaskDateType());
        task.setTaskDate(taskInfo.getTaskDate());
        task.setInspectionAreaId(taskInfo.getInspectionAreaId());
        task.setInspectionCount(taskInfo.getInspectionCount());
        id = taskService.add(task).getId();//任务信息提交,获取新增任务id
        /*--------------*/

        /*新增巡查人员信息*/
        String taskUserIds = taskInfo.getUserIds();//巡查人员id集合
        String UserNames = taskInfo.getUserName();//巡查人员名称集合
        try {
            //根据设置巡查人员存入关联表，一人一条单独信息
            String[] ids = taskUserIds.split("\\|");
            String[] Names = UserNames.split("\\|");
            for (int i =0 ; i<= ids.length ; i++){
                AsmsInspectionAssess o = new AsmsInspectionAssess();
                o.setInspectionTaskId(id);
                o.setUserId(ids[i]);
                o.setUserName(Names[i]);
                assessService.add(o);
            }
        } catch (Exception e) {
            taskService.delete(id);//回滚新增任务信息
            map.put(ApiConstants.CODE, ApiMsgConstants.REQUEST_ERROR_MSG);
            map.put(ApiConstants.MSG, "add error!");
            return map;
        }
        /*---------------*/
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "修改任务")
//    @RequiresPermissions("asms.task.update")
    @RequestMapping(value = "/update")
    public Object update(HttpServletRequest request, @RequestBody SuperviseTaskInfo taskInfo) {
        String taskId = taskInfo.getId();
        Map<String, Object> map = new HashMap<String, Object>();
        /*----更新关联表数据-----*/
        try {
            //新巡查人员数据
            LinkedList<String> nIds = new LinkedList<String>();
            String[] auto = taskInfo.getUserIds().split("\\|");//需更新的巡查人员id集合
            for (int i = 1; i <= auto.length; i++) {
                nIds.add(i - 1, auto[i - 1]);
            }
            //旧数据剔除
            AsmsInspectionAssess r = new AsmsInspectionAssess();
            r.setInspectionTaskId(taskId);
            assessService.delOldDate(r);
            //新数据增加
//            for (String id : nIds) {
//                AsmsInspectionAssess u = new AsmsInspectionAssess();
//                u.setEnable(false);
//                u.setUserId(id);
//                u.setInspectionTaskId(taskId);
//                assessService.add(u);
//            }

            String UserNames = taskInfo.getUserName();
            String[] Names = UserNames.split("\\|");
            for (int i =0 ; i<= nIds.size() ; i++){
                AsmsInspectionAssess u = new AsmsInspectionAssess();
                u.setEnable(true);
                u.setUserId(nIds.get(i));
                u.setUserName(Names[i]);
                u.setInspectionTaskId(taskId);
                assessService.add(u);
            }
        } catch (Exception e) {
            map.put(ApiConstants.CODE, ApiMsgConstants.REQUEST_ERROR_MSG);
            map.put(ApiConstants.MSG, "update error!");
            return map;
        }
        /*----------------------*/

        /*---任务信息修改-------*/
        AsmsInspectionTask task = taskService.findById(taskId);
        task.setId(taskId);
        if (StringUtil.isNotBlank(taskInfo.getTaskType())) {
            task.setTaskType(taskInfo.getTaskType());
        }
        if (StringUtil.isNotBlank(taskInfo.getTaskDateType())) {
            task.setTaskDateType(taskInfo.getTaskDateType());
        }
        if (StringUtil.isNotBlank(taskInfo.getTaskDate())) {
            task.setTaskDate(taskInfo.getTaskDate());
        }
        if (StringUtil.isNotBlank(taskInfo.getInspectionAreaId())) {
            task.setInspectionAreaId(taskInfo.getInspectionAreaId());
        }
        if (taskInfo.getInspectionCount() != null && !"".equals(taskInfo.getInspectionCount())) {
            task.setInspectionCount(taskInfo.getInspectionCount());
        }
        taskService.update(task);
        /*---------------------*/
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "逻辑删除任务")
//    @RequiresPermissions("asms.task.delete")
    @RequestMapping(value = "/delete")
    public Object delete(HttpServletRequest request, @RequestBody AsmsInspectionTask task) {
        taskService.delete(task.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "根据id查询任务")
//    @RequiresPermissions("asms.task.queryById")
    @RequestMapping(value = "/queryById")
    public Object queryById(HttpServletRequest request, @RequestBody AsmsInspectionTask task) {
        AsmsInspectionTask returnTask = taskService.queryById(task.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", returnTask);
        return map;
    }

    @ApiOperation(value = "巡查人员考核结果提交")
//    @RequiresPermissions("asms.task.taskResult")
    @RequestMapping(value = "/taskResult")
    public Object taskResult(HttpServletRequest request, String id, String taskResult) {
        AsmsInspectionAssess nUser = assessService.queryById(id);
        nUser.setTaskResult(taskResult);
        assessService.update(nUser);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "任务列表")
//    @RequiresPermissions("asms.task.taskList")
    @RequestMapping(value = "/taskList")
    public Object taskList(HttpServletRequest request, AsmsInspectionTask task, String dateBegin, String dateEnd, int start, int length) {
        //查询条件：任务类型、考核类型
        PageInfo<List<Map<String, Object>>> returnDate = taskService.getPages(task, dateBegin, dateEnd, ((start + 1) / length) + 1, length);
        Map<String, Object> map = new HashMap<>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", returnDate);
        return map;
    }


    @ApiOperation(value = "巡查人员考核列表")
//    @RequiresPermissions("asms.task.list")
    @RequestMapping(value = "/list")
    public Object list(HttpServletRequest request, SuperviseTaskInfo taskInfo, String dateBegin, String dateEnd, int start, int length) {
        //TODO 缺少次数统计,查询条件(任务类型已实现)
        //固定项  以巡查人员关联表为主表，巡查报告表为附表，根据巡查人员、任务期限检索出实际巡查次数
        //列表展示限制 巡查人员id、任务类型、考核类型、考核类型、任务期限
        //省、市、县、任务类型、任务期限、任务状态、查找内容(查询)
        PageInfo<List<Map<String, Object>>> returnDate = assessService.getPages(taskInfo, dateBegin, dateEnd, ((start + 1) / length) + 1, length);
        Map<String, Object> map = new HashMap<>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", returnDate);
        return map;
    }

    // 查看任务报告列表
    @ApiOperation(value = "根据任务设置查看巡查任务报告列表")
//    @RequiresPermissions("asms.task.getReports")
    @RequestMapping(value = "/getReports")
    public Object getReports(HttpServletRequest request, AsmsBaseInspection superviseBaseInspection, String dateBegin, String dateEnd, int start, int length, String enterpriseIndustry, String xcPsersionId) {
        //数据固定查询条件
        //根据巡查人员、任务类型、任务期限检索出报告列表
        AsmsInspectionAssess st = assessService.queryById(xcPsersionId);
        String xcUserId = null;
        if (st != null) {
            xcUserId = st.getUserId();
        }
        PageInfo<AsmsBaseInspection> returnDate = new PageInfo<AsmsBaseInspection>();
        if (StringUtil.isNotBlank(xcUserId)) {
            returnDate = assessService.getBaseInspectionList(superviseBaseInspection, dateBegin, dateEnd, ((start + 1) / length) + 1, length, enterpriseIndustry, xcUserId);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", returnDate);
        return map;
    }

    // 查看任务报告详情
    @ApiOperation(value = "查看任务报告详情")
//    @RequiresPermissions("asms.task.getReportsInfo")
    @RequestMapping(value = "/getReportsInfo")
    public Object getReportsInfo(HttpServletRequest request, @RequestBody AsmsBaseInspection report) {
        AsmsBaseInspection returnDate = baseInspectionService.findBaseInspectionById(report.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", returnDate);
        return map;
    }

}
