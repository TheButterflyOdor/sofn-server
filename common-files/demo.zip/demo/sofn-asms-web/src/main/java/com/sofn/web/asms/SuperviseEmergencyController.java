package com.sofn.web.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.generator.AsmsEmergencyExpert;
import com.sofn.model.generator.AsmsEmergencyTask;
import com.sofn.service.asms.AsmsEmergencyExpertService;
import com.sofn.service.asms.SuperviseEmergencyService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by zhangdong on 2016/9/27 11:21.
 */
@RestController
@Api(value = "应急管理",description = "应急管理")
@RequestMapping(value = "/superviseEmergency")
public class SuperviseEmergencyController {
    @Autowired
    private SuperviseEmergencyService superviseEmergencyService;
    @Autowired
    private AsmsEmergencyExpertService asmsEmergencyExpertService;

    /**
     * 根据ID获取单个应急任务
     * @param asmsEmergencyTask
     * @return
     */
    @ApiOperation(value = "根据ID获取单个应急任务")
    @RequestMapping(value = "/findAsmsEmergencyTaskById",method = RequestMethod.POST)
    public Map<String,Object> findAsmsEmergencyTaskById(@RequestBody AsmsEmergencyTask asmsEmergencyTask){
        asmsEmergencyTask = superviseEmergencyService.findAsmsEmergencyTaskById(asmsEmergencyTask.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("asmsEmergencyTask",asmsEmergencyTask);
        return map;
    }
    /**
     * 新增应急任务
     * @param asmsEmergencyTask
     * @return
     */
    @ApiOperation(value = "新增应急任务")
    @RequestMapping(value = "/addSuperviseEmergency",method = RequestMethod.POST)
    public Map<String, Object> addSuperviseEmergency(@RequestBody AsmsEmergencyTask asmsEmergencyTask){
        //插入应急任务信息
        String emergencyId=superviseEmergencyService.addSuperviseEmergency(asmsEmergencyTask);
        //插入应急任务与专家资源关联关系
        AsmsEmergencyExpert asmsEmergencyExpert=new AsmsEmergencyExpert();
        asmsEmergencyExpert.setId(UUID.randomUUID().toString().replace("-", ""));
        asmsEmergencyExpert.setEmergencyId(emergencyId);
        asmsEmergencyExpert.setExpertId(asmsEmergencyTask.getExpertId());
        asmsEmergencyExpertService.addAsmsEmergencyExpert(asmsEmergencyExpert);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }
    /**
     * 根据条件获取基地巡查列表
     * @param asmsEmergencyTask
     * @return
     */
    @ApiOperation(value = "获取应急任务列表")
    @RequestMapping(value = "/getSuperviseEmergencyList",method = RequestMethod.POST)
    public Map<String,Object> getSuperviseEmergencyList(AsmsEmergencyTask asmsEmergencyTask ,
                                                    String dateBegin, String dateEnd, int start, int length,String queryCon, String releaseUnit, String areaId, String bearUnit){

        PageInfo<AsmsEmergencyTask> pageInfo = superviseEmergencyService.getAsmsEmergencyTaskList(asmsEmergencyTask,dateBegin,dateEnd,
                ((start+1)/length)+1,length,queryCon,releaseUnit,areaId,bearUnit);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",pageInfo);
        return map;
    }
}
