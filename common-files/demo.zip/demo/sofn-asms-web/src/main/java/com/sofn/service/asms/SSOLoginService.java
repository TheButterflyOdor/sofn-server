package com.sofn.service.asms;

import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.sso.LoginUser;
import com.sofn.provider.sso.SSOLoginProvider;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * Created by dong4j on 16/9/13.
 * Description:
 */
@Service
public class SSOLoginService extends BaseService<SSOLoginProvider, LoginUser> {
    /**
     * Sets provider.
     *
     * @param provider the provider
     */
    @DubboReference
    public void setProvider(SSOLoginProvider provider) {
        this.provider = provider;
    }

    /**
     * Login map.
     *
     * @param account  the account
     * @param password the password
     * @return the map
     */
    public Map<String,String> login(String account, String password){
        logger.debug("login: account = {} password = {}",account, password);
        return provider.login(account,password);
    }

    /**
     * Logout.
     *
     * @param token the token
     * @param type  the type
     */
    public void logout(String token, String type){
        logger.debug("logout: token = {} type = {}", token, type);
        provider.logout(token, type);
    }
}
