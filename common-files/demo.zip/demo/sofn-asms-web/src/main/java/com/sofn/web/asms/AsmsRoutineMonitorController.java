package com.sofn.web.asms;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.generator.AsmsRoutineMonitor;
import com.sofn.service.asms.AsmsRoutineMonitorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * 例行监测控制器
 *
 * @author sofn
 * @version 2016年9月9日 上午9:1:0
 */
@RestController
@Api(value = "例行监测", description = "例行监测")
@RequestMapping(value = "/routineMonitor", method = RequestMethod.POST)
public class AsmsRoutineMonitorController extends BaseController {
    private static Logger logger = Logger.getLogger("AsmsRoutineMonitorController");
    @Autowired
    private AsmsRoutineMonitorService service;

    @ApiOperation(value = "新增任务")
//    @RequiresPermissions("asms.rmtask.add")
    @RequestMapping(value = "/add")
    public Object add(HttpServletRequest request,AsmsRoutineMonitor r,String qtIds) {
        service.addTask(r,qtIds);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "修改任务")
//    @RequiresPermissions("asms.rmtask.update")
    @RequestMapping(value = "/update")
    public Object update(HttpServletRequest request, AsmsRoutineMonitor r,String qtIds) {
        service.updateTask(r,qtIds);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "根据id查询任务")
//    @RequiresPermissions("asms.rmtask.getTaskById")
    @RequestMapping(value = "/getTaskById")
    public Object getTaskById(HttpServletRequest request,@RequestBody AsmsRoutineMonitor r) {
        AsmsRoutineMonitor o = service.queryById(r.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",o);
        return map;
    }

    @ApiOperation(value = "发布任务")
//    @RequiresPermissions("asms.rmtask.rel")
    @RequestMapping(value = "/rel")
    public Object rel(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            AsmsRoutineMonitor o = service.queryById(id.toString());
            o.setRmState("1");//已废止状态
            service.update(o);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "废止任务")
//    @RequiresPermissions("asms.rmtask.abo")
    @RequestMapping(value = "/abo")
    public Object abo(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            AsmsRoutineMonitor o = service.queryById(id.toString());
            o.setRmState("2");//已废止状态
            service.update(o);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "删除")
//    @RequiresPermissions("asms.rmtask.del")
    @RequestMapping(value = "/del")
    public Object del(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            service.delete(id.toString());
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "任务列表")
//    @RequiresPermissions("asms.rmtask.list")
    @RequestMapping(value = "/list")
    public Object list(HttpServletRequest request,AsmsRoutineMonitor r, String dateBegin, String dateEnd, int start, int length) {
        PageInfo<List<Map<String, Object>>> data = service.list(r, dateBegin, dateEnd, ((start + 1) / length) + 1, length);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",data);
        return map;
    }

    @ApiOperation(value = "报告列表")
//    @RequiresPermissions("asms.rmtask.presList")
    @RequestMapping(value = "/presList")
    public Object presList(HttpServletRequest request,AsmsRoutineMonitor r,String dateBegin, String dateEnd, int start, int length) {
        //TODO 待确定报告bean
        Map<String, Object> map = new HashMap<>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

    @ApiOperation(value = "导出任务")
//    @RequiresPermissions("asms.rmtask.export")
    @RequestMapping(value = "/export")
    public Object export(HttpServletRequest request, @RequestBody AsmsRoutineMonitor r) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

    @ApiOperation(value = "报告下载")
//    @RequiresPermissions("asms.rmtask.download")
    @RequestMapping(value = "/download")
    public Object download(HttpServletRequest request, AsmsRoutineMonitor r) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

}
