package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsSubjDetection;
import com.sofn.model.generator.AsmsSubjDtCancel;
import com.sofn.model.generator.AsmsSubjDtChange;
import com.sofn.model.generator.AsmsSubjDtRevoke;
import com.sofn.provider.asms.AsmsSubjDetectionProvider;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.*;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:29
 */
@Service
public class AsmsSubjDetectionService extends BaseService<AsmsSubjDetectionProvider,AsmsSubjDetection>{

    @DubboReference
    public void setSubjDetectionProvider(AsmsSubjDetectionProvider provider){
        this.provider = provider;
    }

    public int addSubjDetection(AsmsSubjDetection subjDetection){
        subjDetection.setId(UUID.randomUUID().toString().replace("-", ""));
        subjDetection.setCreateBy("暂无");
        subjDetection.setCreateTime(new Date());
        subjDetection.setEnable(true);
        return provider.addSubjDetection(subjDetection);
    }

    public AsmsSubjDetection findSubjDetectionById(AsmsSubjDetection subjDetection){
        return provider.findSubjDetectionById(subjDetection.getId());
    }

    public PageInfo getSubjDetectionList(AsmsSubjDetection subjDetection,int pageNum,int pageSize,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("dtName",subjDetection.getDtName());
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjDetectionList(queryMap);
    }

    public int addSubjDtRevoke(AsmsSubjDtRevoke subjDtRevoke){
        subjDtRevoke.setId(UUID.randomUUID().toString().replace("-",""));
        subjDtRevoke.setApplyUserId("暂无");
        subjDtRevoke.setApplySvId("zanwu");
        subjDtRevoke.setApplyTime(new Date());
        return provider.addSubjDtRevoke(subjDtRevoke);
    }

    public void importSubjDetection(HttpServletRequest request) throws Exception{
        //创建一个基于磁盘的文件项的工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        //设置工厂约束
        factory.setSizeThreshold(4096);//设置缓冲区大小，这里是4kb
        //创建一个新的文件上传机制
        ServletFileUpload upload = new ServletFileUpload(factory);
        //设置整体请求大小约束
        upload.setFileSizeMax(4194304);// 设置最大文件尺寸，这里是4MB
        //可能有多个文件
        List<FileItem> items;
        items = upload.parseRequest(request);
        Iterator<FileItem> iterator = items.iterator();
        while(iterator.hasNext()){
            InputStream inputStream = iterator.next().getInputStream();
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet;
            for(int sheetIndex = 0;sheetIndex<workbook.getNumberOfSheets();sheetIndex++){//循环Sheet
                sheet = workbook.getSheetAt(sheetIndex);
                int rowNum = sheet.getLastRowNum()+1;//有多少行
                for(int rowIndex = 1;rowIndex<rowNum;rowIndex++){//循环Sheet里面的row
                    Row row = sheet.getRow(rowIndex);
                    AsmsSubjDetection subjDetection = new AsmsSubjDetection();
                    for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){//循环row里的单元格
                        Cell cell = row.getCell(cellIndex);
                        String cellContent = this.getCellValue(cell);
                        if(cellIndex==0) {
                            subjDetection.setDtName(cellContent);
                        }else if(cellIndex==1){
                            subjDetection.setDtCode(cellContent);
                        }else if(cellIndex==2){
                            subjDetection.setDtLevel(cellContent);
                        }else if(cellIndex==3){
                            subjDetection.setDtAreaId(cellContent);
                        }else if(cellIndex==4){
                            subjDetection.setDtAddress(cellContent);
                        }else if(cellIndex==5){
                            subjDetection.setDtLeader(cellContent);
                        }else if(cellIndex==6){
                            subjDetection.setDtLeaderPhone(cellContent);
                        }else if(cellIndex==7){
                            subjDetection.setDtContact(cellContent);
                        }else if(cellIndex==8){
                            subjDetection.setDtContactPhone(cellContent);
                        }else if(cellIndex==9){
                            subjDetection.setDtContactQQ(cellContent);
                        }else if(cellIndex==10){
                            subjDetection.setDtContactEmail(cellContent);
                        }else if(cellIndex==11){
                            subjDetection.setDtPostcode(cellContent);
                        }
                    }
                    this.addSubjDetection(subjDetection);
                }
            }
        }
    }

    /**
     * 查询检测机构主体变更申请列表
     * @param subjDtChange
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjDtChangeList(AsmsSubjDtChange subjDtChange,int pageNum,int pageSize,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("dtName",subjDtChange.getDtName());
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjDtChangeList(queryMap);
    }

    /**
     * 通过ID获取单个检测机构主体变更申请
     * @param subjDtChange
     * @return
     */
    public AsmsSubjDtChange findSubjDtChangeById(AsmsSubjDtChange subjDtChange){
        return provider.findSubjDtChangeById(subjDtChange.getId());
    }

    /**
     * 审核检测机构主体变更
     * @param subjDetection
     * @param subjDtChange
     */
    public void auditSubjDtChange(AsmsSubjDetection subjDetection,AsmsSubjDtChange subjDtChange){
        provider.auditSubjDtChange(subjDetection, subjDtChange);
    }

    /**
     * 查询检测机构主体注销申请列表
     * @param subjDtCancel
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjDtCancelList(AsmsSubjDtCancel subjDtCancel,int pageNum,int pageSize,String dtName,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("dtName",dtName);
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjDtCancelList(queryMap);
    }

    /**
     * 通过ID获取单个检测机构主体注销申请
     * @param subjDtCancel
     * @return
     */
    public AsmsSubjDtCancel findSubjDtCancelById(AsmsSubjDtCancel subjDtCancel){
        return provider.findSubjDtCancelById(subjDtCancel.getId());
    }

    /**
     * 审核检测机构主体注销申请
     * @param subjDetection
     * @param subjDtCancel
     */
    public void auditSubjDtCancel(AsmsSubjDetection subjDetection,AsmsSubjDtCancel subjDtCancel){
        provider.auditSubjDtCancel(subjDetection, subjDtCancel);
    }

    /**
     * 查询检测机构主体撤销申请列表
     * @param subjDtRevoke
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjDtRevokeList(AsmsSubjDtRevoke subjDtRevoke,int pageNum,int pageSize,String dtName,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("dtName",dtName);
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjDtRevokeList(queryMap);
    }

    /**
     * 通过ID获取单个检测机构主体撤销申请
     * @param subjDtRevoke
     * @return
     */
    public AsmsSubjDtRevoke findSubjDtRevokeById(AsmsSubjDtRevoke subjDtRevoke){
        return provider.findSubjDtRevokeById(subjDtRevoke.getId());
    }

    /**
     * 审核检测机构主体撤销申请
     * @param subjDetection
     * @param subjDtRevoke
     */
    public void auditSubjDtRevoke(AsmsSubjDetection subjDetection,AsmsSubjDtRevoke subjDtRevoke){
        provider.auditSubjDtRevoke(subjDetection, subjDtRevoke);
    }

    /**
     * 单纯上传文件--暂加
     * @param request
     * @throws Exception
     */
    public Map<String,Object> upload(HttpServletRequest request) throws Exception{
        //创建一个基于磁盘的文件项的工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        //设置工厂约束
        factory.setSizeThreshold(4096);//设置缓冲区大小，这里是4kb
        //创建一个新的文件上传机制
        ServletFileUpload upload = new ServletFileUpload(factory);
        //设置整体请求大小约束
        upload.setFileSizeMax(4194304);// 设置最大文件尺寸，这里是4MB
        //可能有多个文件
        List<FileItem> items;
        items = upload.parseRequest(request);
        Iterator<FileItem> iterator = items.iterator();
        String tomcatPath = request.getSession().getServletContext().getRealPath("")+"\\uploadFile\\baseInspection\\"
                +com.sofn.core.util.DateUtil.getDateTime("yyyyMMdd");
        File fileD = new File(tomcatPath);
        if(!fileD.exists()){
            fileD.mkdir();
        }
        //文件路径
        StringBuilder sb = new StringBuilder();
        byte[] imgByte = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while(iterator.hasNext()){
            FileItem fileItem = iterator.next();
            InputStream inputStream = fileItem.getInputStream();
            if(fileItem.getName()!=null) {
                String fileName = UUID.randomUUID().toString().replace("-", "") + fileItem.getName().substring(fileItem.getName().lastIndexOf("."),fileItem.getName().length());
                File file = new File(tomcatPath +"\\"+ fileName);
                sb.append("uploadFile/baseInspection/"+com.sofn.core.util.DateUtil.getDateTime("yyyyMMdd") +"/" + fileName);
                fileItem.write(file);

//            int ch;
//            while((ch=inputStream.read())!=-1){
//                byteArrayOutputStream.write(ch);
//            }
                imgByte = IOUtils.toByteArray(inputStream);
                for(int i=0;i<imgByte.length;i++){
                    System.out.print(imgByte[i]);
                }
            }

        }
        Map<String,Object> map = new HashMap<>();
        map.put("path",sb.toString());
        map.put("img",imgByte);
        return map;
    }

    public String getCellValue(Cell cell){
        String value = "";
        switch(cell.getCellType()){
            case Cell.CELL_TYPE_STRING:
                value = cell.getRichStringCellValue().toString();
                break;
            case Cell.CELL_TYPE_NUMERIC:
                value = cell.getNumericCellValue()+"";
                break;
            case Cell.CELL_TYPE_FORMULA:
                value = String.valueOf(cell.getCellFormula());
                break;
            case Cell.CELL_TYPE_BOOLEAN:
                value = String.valueOf(cell.getBooleanCellValue());
                break;
            case Cell.CELL_TYPE_ERROR:
                value = String.valueOf(cell.getErrorCellValue());
                break;
        }
        return value;
    }
}
