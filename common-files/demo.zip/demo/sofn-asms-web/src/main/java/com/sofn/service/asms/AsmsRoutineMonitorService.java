package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsRoutineMonitor;
import com.sofn.provider.asms.AsmsRoutineMonitorProvider;
import jodd.util.StringUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@Service
public class AsmsRoutineMonitorService extends BaseService<AsmsRoutineMonitorProvider, AsmsRoutineMonitor> {
    @DubboReference
    public void setProvider(AsmsRoutineMonitorProvider provider) {
        this.provider = provider;
    }

    public void addTask(AsmsRoutineMonitor r, String qtIds) {
        r.setRmState("0");//待发布
        String id = provider.update(r).getId();//主表信息
        //关联表信息
        String[] ids = qtIds.split("\\|");
        for (String oid : ids) {
            provider.addGlInfo(id,oid);
        }
    }

    public void updateTask(AsmsRoutineMonitor r, String qtIds) {
        AsmsRoutineMonitor o = provider.queryById(r.getId());
        o.setRmName(r.getRmName());
        o.setRmType(r.getRmType());
        o.setRmModelId(r.getRmModelId());
        o.setRmYear(r.getRmYear());
        o.setRmBatch(r.getRmBatch());
        o.setRmDateBegin(r.getRmDateBegin());
        o.setRmDateEnd(r.getRmDateEnd());
        o.setRmReleaseUnit(r.getRmReleaseUnit());
        o.setRmFile(r.getRmFile());
        o.setRmFileNum(r.getRmFileNum());
        o.setRmFileNum(r.getRmFileNum());
        provider.update(o);//主表信息
        //关联表信息
        provider.delGlInfoByTaskId(r.getId());//删除原数据
        String[] ids = qtIds.split("\\|");
        for (String oid : ids) {
            provider.addGlInfo(r.getId(),oid);//新数据添加
        }
    }

    public PageInfo<List<Map<String, Object>>> list(AsmsRoutineMonitor r, String dateBegin, String dateEnd, int pageNum, int pageSize) {
        Map<String, Object> params = new HashMap<>();
        //page
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        //query
        params.put("dateBegin", StringUtil.isNotBlank(dateBegin) ? dateBegin : null);
        params.put("dateEnd", StringUtil.isNotBlank(dateEnd) ? dateEnd : null);
        params.put("rmName", StringUtil.isNotBlank(r.getRmName()) ? "%"+r.getRmName()+"%" : null);
        params.put("rmState", StringUtil.isNotBlank(r.getRmState()) ? r.getRmState() : null);
        PageInfo<List<Map<String, Object>>> i = provider.list(params);
        return i;
    }

    public Object download() {
        return null;
    }

    public Object rel() {
        return null;
    }

    public Object abo() {
        return null;
    }

    public Object export() {
        return null;
    }

    public Object querypre() {
        return null;
    }

}
