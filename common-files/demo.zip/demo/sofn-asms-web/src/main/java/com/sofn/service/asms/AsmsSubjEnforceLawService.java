package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AlesSubjElCancel;
import com.sofn.model.generator.AlesSubjElChange;
import com.sofn.model.generator.AlesSubjElRevoke;
import com.sofn.model.generator.AlesSubjEnforceLaw;
import com.sofn.provider.asms.AsmsSubjEnforceLawProvider;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.poi.ss.usermodel.*;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.*;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:29
 */
@Service
public class AsmsSubjEnforceLawService extends BaseService<AsmsSubjEnforceLawProvider,AlesSubjEnforceLaw>{

    @DubboReference
    public void setSubjectEnforceLawProvider(AsmsSubjEnforceLawProvider provider){
        this.provider = provider;
    }

    public int addSubjEnforceLaw(AlesSubjEnforceLaw subjEnforceLaw){
        subjEnforceLaw.setId(UUID.randomUUID().toString().replace("-", ""));
        subjEnforceLaw.setCreateBy("暂无");
        subjEnforceLaw.setCreateTime(new Date());
        subjEnforceLaw.setEnable(true);
        return provider.addSubjEnforceLaw(subjEnforceLaw);
    }

    public AlesSubjEnforceLaw findSubjEnforceLawById(AlesSubjEnforceLaw subjEnforceLaw){
        return provider.findSubjEnforceLawById(subjEnforceLaw.getId());
    }

    public PageInfo getSubjEnforceLawList(AlesSubjEnforceLaw subjEnforceLaw,int pageNum,int pageSize,String dateBegin,String dateEnd){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("elName",subjEnforceLaw.getElName());
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        queryMap.put("dateBegin",dateBegin);
        queryMap.put("dateEnd",dateEnd);
        return provider.getSubjEnforceLawList(queryMap);
    }

    public int addSubjElRevoke(AlesSubjElRevoke subjElRevoke){
        subjElRevoke.setId(UUID.randomUUID().toString().replace("-",""));
        subjElRevoke.setApplyTime(new Date());
        subjElRevoke.setApplySvId("zanwu");
        subjElRevoke.setApplyUserId("暂无");
        return provider.addSubjElRevoke(subjElRevoke);
    }

    public void importSubjEnforceLaw(HttpServletRequest request) throws Exception{
        //创建一个基于磁盘的文件项的工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        //设置工厂约束
        factory.setSizeThreshold(4096);//设置缓冲区大小，这里是4kb
        //创建一个新的文件上传机制
        ServletFileUpload upload = new ServletFileUpload(factory);
        //设置整体请求大小约束
        upload.setFileSizeMax(4194304);// 设置最大文件尺寸，这里是4MB
        //可能有多个文件
        List<FileItem> items;
        items = upload.parseRequest(request);
        Iterator<FileItem> iterator = items.iterator();
        while(iterator.hasNext()){
            InputStream inputStream = iterator.next().getInputStream();
            Workbook workbook = WorkbookFactory.create(inputStream);
            Sheet sheet;
            for(int sheetIndex = 0;sheetIndex<workbook.getNumberOfSheets();sheetIndex++){//循环Sheet
                sheet = workbook.getSheetAt(sheetIndex);
                int rowNum = sheet.getLastRowNum()+1;//有多少行
                for(int rowIndex = 1;rowIndex<rowNum;rowIndex++){//循环Sheet里面的row
                    Row row = sheet.getRow(rowIndex);
                    AlesSubjEnforceLaw subjEnforceLaw = new AlesSubjEnforceLaw();
                    for(int cellIndex=0;cellIndex<row.getLastCellNum();cellIndex++){//循环row里的单元格
                        Cell cell = row.getCell(cellIndex);
                        String cellContent = this.getCellValue(cell);
                        if(cellIndex==0) {
                            subjEnforceLaw.setElName(cellContent);
                        }else if(cellIndex==1){
                            subjEnforceLaw.setElCode(cellContent);
                        }else if(cellIndex==2){
                            subjEnforceLaw.setElLevel(cellContent);
                        }else if(cellIndex==3){
                            subjEnforceLaw.setElAreaId(cellContent);
                        }else if(cellIndex==4){
                            subjEnforceLaw.setElAddress(cellContent);
                        }else if(cellIndex==5){
                            subjEnforceLaw.setElLeader(cellContent);
                        }else if(cellIndex==6){
                            subjEnforceLaw.setElLeaderPhone(cellContent);
                        }else if(cellIndex==7){
                            subjEnforceLaw.setElContact(cellContent);
                        }else if(cellIndex==8){
                            subjEnforceLaw.setElContactPhone(cellContent);
                        }else if(cellIndex==9){
                            subjEnforceLaw.setElContactQQ(cellContent);
                        }else if(cellIndex==10){
                            subjEnforceLaw.setElContactEmail(cellContent);
                        }else if(cellIndex==11){
                            subjEnforceLaw.setElPostcode(cellContent);
                        }
                    }
                    this.addSubjEnforceLaw(subjEnforceLaw);
                }
            }
        }
    }

    /**
     * 查询执法机构主体变更申请列表
     * @param subjElChange
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjElChangeList(AlesSubjElChange subjElChange,int pageNum,int pageSize,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        queryMap.put("date",date);
        queryMap.put("elName",subjElChange.getElName());
        return provider.getSubjElChangeList(queryMap);
    }

    /**
     * 通过ID获取单个执法机构主体变更申请
     * @param subjElChange
     * @return
     */
    public AlesSubjElChange findSubjElChangeById(AlesSubjElChange subjElChange){
        return provider.findSubjElChangeById(subjElChange.getId());
    }

    /**
     * 审核执法机构主体变更
     * @param subjEnforceLaw
     * @param subjElChange
     */
    public void auditSubjElChange(AlesSubjEnforceLaw subjEnforceLaw,AlesSubjElChange subjElChange){
        provider.auditSubjElChange(subjEnforceLaw, subjElChange);
    }

    /**
     * 查询执法机构主体注销申请列表
     * @param subjElCancel
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjElCancelList(AlesSubjElCancel subjElCancel,int pageNum,int pageSize,String elName,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("elName",elName);
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjElCancelList(queryMap);
    }

    /**
     * 通过ID获取单个执法机构主体注销申请
     * @param subjElCancel
     * @return
     */
    public AlesSubjElCancel findSubjElCancelById(AlesSubjElCancel subjElCancel){
        return provider.findSubjElCancelById(subjElCancel.getId());
    }

    /**
     * 审核执法机构主体注销申请
     * @param subjEnforceLaw
     * @param subjElCancel
     */
    public void auditSubjElCancel(AlesSubjEnforceLaw subjEnforceLaw,AlesSubjElCancel subjElCancel){
        provider.auditSubjElCancel(subjEnforceLaw, subjElCancel);
    }

    /**
     * 查询执法机构主体撤销申请列表
     * @param subjElRevoke
     * @param pageNum
     * @param pageSize
     * @return
     */
    public PageInfo getSubjElRevokeList(AlesSubjElRevoke subjElRevoke,int pageNum,int pageSize,String elName,String date){
        Map<String,Object> queryMap = new HashMap<>();
        queryMap.put("elName",elName);
        queryMap.put("date",date);
        queryMap.put("pageNum",pageNum);
        queryMap.put("pageSize",pageSize);
        return provider.getSubjElRevokeList(queryMap);
    }

    /**
     * 通过ID获取单个执法机构主体撤销申请
     * @param subjElRevoke
     * @return
     */
    public AlesSubjElRevoke findSubjElRevokeById(AlesSubjElRevoke subjElRevoke){
        return provider.findSubjElRevokeById(subjElRevoke.getId());
    }

    /**
     * 审核执法机构主体撤销申请
     * @param subjEnforceLaw
     * @param subjElRevoke
     */
    public void auditSubjElRevoke(AlesSubjEnforceLaw subjEnforceLaw,AlesSubjElRevoke subjElRevoke){
        provider.auditSubjElRevoke(subjEnforceLaw,subjElRevoke);
    }

    /**
     * 单纯上传文件--暂加
     * @param request
     * @throws Exception
     */
    public Map<String,Object> upload(HttpServletRequest request) throws Exception{
        //创建一个基于磁盘的文件项的工厂
        DiskFileItemFactory factory = new DiskFileItemFactory();
        //设置工厂约束
        factory.setSizeThreshold(4096);//设置缓冲区大小，这里是4kb
        //创建一个新的文件上传机制
        ServletFileUpload upload = new ServletFileUpload(factory);
        //设置整体请求大小约束
        upload.setFileSizeMax(4194304);// 设置最大文件尺寸，这里是4MB
        //可能有多个文件
        List<FileItem> items;
        items = upload.parseRequest(request);
        Iterator<FileItem> iterator = items.iterator();
        String tomcatPath = request.getSession().getServletContext().getRealPath("")+"\\uploadFile\\baseInspection\\"
                +com.sofn.core.util.DateUtil.getDateTime("yyyyMMdd");
        File fileD = new File(tomcatPath);
        if(!fileD.exists()){
            fileD.mkdir();
        }
        //文件路径
        StringBuilder sb = new StringBuilder();
        byte[] imgByte = null;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        while(iterator.hasNext()){
            FileItem fileItem = iterator.next();
            InputStream inputStream = fileItem.getInputStream();
            if(fileItem.getName()!=null) {
                String fileName = UUID.randomUUID().toString().replace("-", "") + fileItem.getName().substring(fileItem.getName().lastIndexOf("."),fileItem.getName().length());
                File file = new File(tomcatPath +"\\"+ fileName);
                sb.append("uploadFile/baseInspection/"+com.sofn.core.util.DateUtil.getDateTime("yyyyMMdd") +"/" + fileName);
                fileItem.write(file);

//            int ch;
//            while((ch=inputStream.read())!=-1){
//                byteArrayOutputStream.write(ch);
//            }
                imgByte = IOUtils.toByteArray(inputStream);
                for(int i=0;i<imgByte.length;i++){
                    System.out.print(imgByte[i]);
                }
            }

        }
        Map<String,Object> map = new HashMap<>();
        map.put("path",sb.toString());
        map.put("img",imgByte);
        return map;
    }

    public String getCellValue(Cell cell){
        String value = "";
        switch(cell.getCellType()){
            case Cell.CELL_TYPE_STRING:
                value = cell.getRichStringCellValue().toString();
                break;
            case Cell.CELL_TYPE_NUMERIC:
                value = cell.getNumericCellValue()+"";
                break;
            case Cell.CELL_TYPE_FORMULA:
                value = String.valueOf(cell.getCellFormula());
                break;
            case Cell.CELL_TYPE_BOOLEAN:
                value = String.valueOf(cell.getBooleanCellValue());
                break;
            case Cell.CELL_TYPE_ERROR:
                value = String.valueOf(cell.getErrorCellValue());
                break;
        }
        return value;
    }
}
