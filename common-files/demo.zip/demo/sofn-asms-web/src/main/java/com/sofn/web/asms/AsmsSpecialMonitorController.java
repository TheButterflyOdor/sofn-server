package com.sofn.web.asms;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.asms.SuperviseTaskInfo;
import com.sofn.model.generator.AsmsBaseInspection;
import com.sofn.model.generator.AsmsInspectionTask;
import com.sofn.model.generator.AsmsSpecialMonitor;
import com.sofn.service.asms.AsmsSpecialMonitorService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * 专项监测控制器
 *
 * @author sofn
 * @version 2016年9月9日 上午9:1:0
 */
@RestController
@Api(value = "专项监测", description = "专项监测")
@RequestMapping(value = "/specialMonitor", method = RequestMethod.POST)
public class AsmsSpecialMonitorController extends BaseController {
    private static Logger logger = Logger.getLogger("AsmsSpecialMonitorController");
    @Autowired
    private AsmsSpecialMonitorService service;

    @ApiOperation(value = "新增任务")
//    @RequiresPermissions("asms.smtask.add")
    @RequestMapping(value = "/add")
    public Object add(HttpServletRequest request, AsmsSpecialMonitor r, String qtIds,
                      @RequestHeader (value="token",required = false) String token) {
        service.addTask(r,qtIds);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "修改任务")
//    @RequiresPermissions("asms.smtask.update")
    @RequestMapping(value = "/update")
    public Object update(HttpServletRequest request, AsmsSpecialMonitor r,String qtIds) {
        service.updateTask(r,qtIds);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "根据id查询任务")
//    @RequiresPermissions("asms.smtask.getTaskById")
    @RequestMapping(value = "/getTaskById")
    public Object getTaskById(HttpServletRequest request,@RequestBody AsmsSpecialMonitor r) {
        AsmsSpecialMonitor o = service.queryById(r.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",o);
        return map;
    }

    @ApiOperation(value = "发布任务")
//    @RequiresPermissions("asms.smtask.rel")
    @RequestMapping(value = "/rel")
    public Object rel(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            AsmsSpecialMonitor o = service.queryById(id.toString());
            o.setSmState("1");//已废止状态
            service.update(o);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "废止任务")
//    @RequiresPermissions("asms.smtask.abo")
    @RequestMapping(value = "/abo")
    public Object abo(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            AsmsSpecialMonitor o = service.queryById(id.toString());
            o.setSmState("2");//已废止状态
            service.update(o);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "删除")
//    @RequiresPermissions("asms.smtask.del")
    @RequestMapping(value = "/del")
    public Object del(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            service.delete(id.toString());
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "任务列表")
//    @RequiresPermissions("asms.smtask.list")
    @RequestMapping(value = "/list")
    public Object list(HttpServletRequest request,AsmsSpecialMonitor r,String dateBegin, String dateEnd, int start, int length) {
        PageInfo<List<Map<String, Object>>> data = service.list(r, dateBegin, dateEnd, ((start + 1) / length) + 1, length);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",data);
        return map;
    }

    @ApiOperation(value = "报告列表")
//    @RequiresPermissions("asms.smtask.presList")
    @RequestMapping(value = "/presList")
    public Object presList(HttpServletRequest request, SuperviseTaskInfo taskInfo, String dateBegin, String dateEnd, int start, int length) {
        //TODO 待确定报告bean
        Map<String, Object> map = new HashMap<>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);//返回分页数据
        return map;
    }

    @ApiOperation(value = "导出任务")
//    @RequiresPermissions("asms.smtask.export")
    @RequestMapping(value = "/export")
    public Object export(HttpServletRequest request, @RequestBody AsmsInspectionTask task) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

    @ApiOperation(value = "报告下载")
//    @RequiresPermissions("asms.smtask.download")
    @RequestMapping(value = "/download")
    public Object download(HttpServletRequest request, AsmsBaseInspection superviseBaseInspection, String dateBegin, String dateEnd, int start, int length, String enterpriseIndustry, String xcPsersionId) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }
}
