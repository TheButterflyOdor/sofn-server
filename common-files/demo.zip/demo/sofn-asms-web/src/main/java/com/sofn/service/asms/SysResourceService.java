package com.sofn.service.asms;


import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.SysResource;
import com.sofn.provider.asms.SysResourceProvider;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;
/**
 * @author dongwenfeng
 * @version 2016年09月20日 下午 4:50
 */

@Service
public class SysResourceService extends BaseService<SysResourceProvider,SysResource> {
    @DubboReference
    public void setSysResourceProvider(SysResourceProvider provider){
        this.provider = provider;
    }

    public PageInfo getSysResourceList(SysResource sysResource, String domain, String location,
                                          int pageNum, int pageSize,String queryCon){
        Map<String,Object> queryParams = new HashMap<>();
        queryParams.put("domain",domain);
        queryParams.put("location",location);
        queryParams.put("pageNum",pageNum);
        queryParams.put("pageSize",pageSize);
        queryParams.put("queryCon",queryCon);
        return provider.getSysResourceList(queryParams);
    }

    /**
     * 新增专家信息
     * 修改专家信息
     * @param aisDailyEnforceLaw
     * @return
     */
//    public int addDailyEnforceLaw(AlesDailyEnforceLaw aisDailyEnforceLaw){
//        if(StringUtils.isNullEmpty(aisDailyEnforceLaw.getId())){
//            aisDailyEnforceLaw.setId(UUID.randomUUID().toString().replace("-", ""));
//            aisDailyEnforceLaw.setEnable(true);
//            aisDailyEnforceLaw.setCreateTime(new Date());
//            return provider.addDailyEnforceLaw(aisDailyEnforceLaw);
//        }else{
//            aisDailyEnforceLaw.setUpdateTime(new Date());
//            return provider.updateDailyEnforceLaw(aisDailyEnforceLaw);
//        }
//
//    }

    /**
     * 根据ID查看当前专家信息
     * @param id
     * @return
     */
    public SysResource findSysResource(String id){

        return provider.findSysResourceById(id);
    }

}
