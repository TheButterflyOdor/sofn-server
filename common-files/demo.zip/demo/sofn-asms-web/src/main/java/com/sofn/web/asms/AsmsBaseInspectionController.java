package com.sofn.web.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.generator.AsmsBaseInspection;
import com.sofn.service.asms.AsmsBaseInspectionService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年08月25日 下午 5:05
 */
@RestController
@Api(value = "基地巡查",description = "基地巡查")
@RequestMapping(value = "/baseInspection")
public class AsmsBaseInspectionController {
    @Autowired
    private AsmsBaseInspectionService baseInspectionService;

    /**
     * 新增基地巡查
     * @param asmsBaseInspection
     * @return
     */
    @ApiOperation(value = "新增基地巡查")
    @RequestMapping(value = "/addBaseInspection",method = RequestMethod.POST)
    public Map<String, Object> addBaseInspection(@RequestBody AsmsBaseInspection asmsBaseInspection){
        baseInspectionService.addBaseInspection(asmsBaseInspection);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    /**
     * 根据条件获取基地巡查列表
     * @param asmsBaseInspection
     * @return
     */
    @ApiOperation(value = "获取基地巡查列表")
    @RequestMapping(value = "/getBaseInspectionList",method = RequestMethod.POST)
    public Map<String,Object> getBaseInspectionList(AsmsBaseInspection asmsBaseInspection ,
                                                              String dateBegin,String dateEnd,int start,int length,
                                                              String enterpriseIndustry,String entityScale,String enterpriseName){

        PageInfo<AsmsBaseInspection> pageInfo = baseInspectionService.getBaseInspectionList(asmsBaseInspection,dateBegin,dateEnd,
                ((start+1)/length)+1,length,enterpriseIndustry,entityScale,enterpriseName);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
//        map.put("recordsTotal", 25);
//        map.put("recordsFiltered", 25);
//        map.put("pageNumber", 1);
//        map.put("pageSize", 10);
//        map.put("start", start);
//        map.put("length", length);
        map.put("data",pageInfo);
        return map;
    }

    /**
     * 根据ID获取单个基地巡查详情
     * @param asmsBaseInspection
     * @return
     */
    @ApiOperation(value = "获取单个基地巡查详情")
    @RequestMapping(value = "/findBaseInspectionById",method = RequestMethod.POST)
    public Map<String,Object> findBaseInspectionById(@RequestBody AsmsBaseInspection asmsBaseInspection){
        asmsBaseInspection = baseInspectionService.findBaseInspectionById(asmsBaseInspection.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("baseInspection",asmsBaseInspection);
        return map;
    }

    /**
     * 修改基地巡查
     * @param asmsBaseInspection
     * @return
     */
    @ApiOperation(value = "修改基地巡查")
    @RequestMapping(value = "/updateBaseInspection",method = RequestMethod.POST)
    public Map<String,Object> updateBaseInspection(@RequestBody AsmsBaseInspection asmsBaseInspection){
        baseInspectionService.updateBaseInspection(asmsBaseInspection);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    /**
     * 删除基地巡查
     * @param asmsBaseInspection
     * @return
     */
    @ApiOperation(value = "删除基地巡查")
    @RequestMapping(value = "/deleteBaseInspection",method = RequestMethod.POST)
    public Map<String,Object> deleteBaseInspection(AsmsBaseInspection asmsBaseInspection){
        baseInspectionService.deleteBaseInspection(asmsBaseInspection.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    /**
     * 暂时加的获取生产经营主体列表
     * @return
     */
    @ApiOperation(value = "获取生产经营主体列表（暂加，后面这段代码修改或删除）")
    @RequestMapping(value = "/getEnterpriseList",method = RequestMethod.POST)
    public Map<String,Object> getEnterpriseList(int start,int length){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        PageInfo<AsmsBaseInspection> pageInfo = baseInspectionService.getEnterpriseList(((start+1)/length)+1,length);
        map.put("data",pageInfo);
        return map;
    }

    /**
     * 暂加的根据ID获取生产经营主体
     * @param enterpriseId
     * @return
     */
    @ApiOperation(value = "根据ID获取生产经营主体")
    @RequestMapping(value = "/findEnterpriseById",method = RequestMethod.POST)
    public Map<String,Object> findEnterpriseById(@RequestBody String enterpriseId){
        Map<String,Object> map = new HashMap<>();
        map.put(ApiConstants.CODE,ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("enterprise",baseInspectionService.findEnterpriseById(enterpriseId));
        return map;
    }
}
