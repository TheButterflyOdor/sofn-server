package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.core.util.StringUtils;
import com.sofn.model.generator.AsmsEmergencyTask;
import com.sofn.provider.asms.SuperviseEmergencyProvider;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Created by zhangdong on 2016/9/27 11:21.
 */
@Service
public class SuperviseEmergencyService extends BaseService<SuperviseEmergencyProvider,AsmsEmergencyTask> {
    @DubboReference
    public void setSuperviseEmergencyProvider(SuperviseEmergencyProvider provider){

        this.provider = provider;
    }

    public String addSuperviseEmergency(AsmsEmergencyTask asmsEmergencyTask){
        String reId="";

        if(StringUtils.isNullEmpty(asmsEmergencyTask.getId())){
            reId=UUID.randomUUID().toString().replace("-", "");
            asmsEmergencyTask.setId(reId);
            asmsEmergencyTask.setEnable(false);
            asmsEmergencyTask.setCreateTime(new Date());
            asmsEmergencyTask.setUpdateTime(new Date());
             provider.addAsmsEmergencyTask(asmsEmergencyTask);
        }else{
            reId=asmsEmergencyTask.getId();
            asmsEmergencyTask.setUpdateTime(new Date());
            provider.updateAsmsEmergencyTask(asmsEmergencyTask);
        }
        return reId;
    }
    public PageInfo getAsmsEmergencyTaskList(AsmsEmergencyTask asmsEmergencyTask, String dateBegin, String dateEnd,
                                          int pageNum, int pageSize,String queryCon, String releaseUnit, String areaId, String bearUnit){
        Map<String,Object> queryParams = new HashMap<>();
        queryParams.put("dateBegin",dateBegin);
        queryParams.put("dateEnd",dateEnd);
        queryParams.put("pageNum",pageNum);
        queryParams.put("pageSize",pageSize);
        queryParams.put("releaseUnit",asmsEmergencyTask.getReleaseUnit());
        queryParams.put("areaId",asmsEmergencyTask.getAreaId());
        queryParams.put("bearUnit",asmsEmergencyTask.getBearUnit());
        queryParams.put("queryCon",queryCon);
        return provider.getSuperviseEmergencyList(queryParams);
//        return provider.getBaseInspectionList(queryParams);
    }

    public AsmsEmergencyTask findAsmsEmergencyTaskById(String id){
        return provider.findAsmsEmergencyTaskById(id);
    }

}
