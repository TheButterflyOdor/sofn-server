package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.asms.SuperviseCheckDto;
import com.sofn.model.asms.SuperviseTaskInfo;
import com.sofn.model.generator.AsmsBaseInspection;
import com.sofn.model.generator.AsmsInspectionAssess;
import com.sofn.provider.asms.AsmsInspectionAssessProvider;
import jodd.util.StringUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@Service
public class AsmsInspectionAssessService extends BaseService<AsmsInspectionAssessProvider, AsmsInspectionAssess> {
    @DubboReference
    public void setProvider(AsmsInspectionAssessProvider provider) {
        this.provider = provider;
    }

    public List<AsmsInspectionAssess> getXcUserId(AsmsInspectionAssess taskUser) {
        return provider.getXcUserIds(taskUser);
    }

    public void delOldDate(AsmsInspectionAssess taskUser) {
        provider.delOldDate(taskUser);
    }

    /*获取分页列表*/
    public PageInfo<AsmsInspectionAssess> getPageList(Map<String, Object> params) {
        return provider.getPageList(params);
    }

    /*获取巡查人员考核列表*/
    public PageInfo<List<Map<String, Object>>> getPages(SuperviseTaskInfo taskInfo, String dateBegin, String dateEnd, int pageNum, int pageSize) {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("dateBegin", dateBegin);
        queryParams.put("dateEnd", dateEnd);
        queryParams.put("pageNum", pageNum);
        queryParams.put("pageSize", pageSize);
        queryParams.put("taskType", StringUtil.isNotBlank(taskInfo.getTaskType()) ? "%" + taskInfo.getTaskType() + "%" : null);
        queryParams.put("taskDateType", StringUtil.isNotBlank(taskInfo.getTaskDateType()) ? "%" + taskInfo.getTaskDateType() + "%" : null);
        queryParams.put("userName", StringUtil.isNotBlank(taskInfo.getUserName()) ? "%" + taskInfo.getUserName() + "%" : null);
        queryParams.put("taskResult", StringUtil.isNotBlank(taskInfo.getTaskResult()) ? taskInfo.getTaskResult() : null);
        PageInfo<List<Map<String, Object>>> i = provider.getPages(queryParams);
        return i;
    }

    public List<SuperviseCheckDto> getSuperviseTaskInfos() {
        return provider.getSuperviseTaskInfos();
    }

    /*根据人员获取报告列表*/
    public PageInfo getBaseInspectionList(AsmsBaseInspection superviseBaseInspection, String dateBegin, String dateEnd, int pageNum, int pageSize, String enterpriseIndustry,String xcPsersionId) {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("dateBegin", dateBegin);
        queryParams.put("dateEnd", dateEnd);
        queryParams.put("pageNum", pageNum);
        queryParams.put("pageSize", pageSize);
        queryParams.put("inspectionResult", superviseBaseInspection.getInspectionResult());
        queryParams.put("enterpriseIndustry", enterpriseIndustry);
        queryParams.put("xcPsersionId", xcPsersionId);
        return provider.getBaseInspectionAllList(queryParams);
//        return provider.getBaseInspectionList(queryParams);
    }

}
