package com.sofn.web.asms;

import com.alibaba.fastjson.JSONArray;
import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.model.generator.AsmsCheckTask;
import com.sofn.model.generator.AsmsMonitorObject;
import com.sofn.service.asms.AsmsCheckTaskService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * 监督抽查控制器
 *
 * @author sofn
 * @version 2016年9月29日 上午9:1:0
 */
@RestController
@Api(value = "监督抽查", description = "监督抽查")
@RequestMapping(value = "/checkTask", method = RequestMethod.POST)
public class AsmsCheckTaskController extends BaseController {
    private static Logger logger = Logger.getLogger("AsmsCheckTaskController");
    @Autowired
    private AsmsCheckTaskService service;

    @ApiOperation(value = "新增任务(省级)")
//    @RequiresPermissions("asms.cktask.add")
    @RequestMapping(value = "/add")
    public Object add(HttpServletRequest request,AsmsCheckTask r,String Objects) {
        service.addTask(r,Objects);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "修改任务(省级)")
//    @RequiresPermissions("asms.cktask.update")
    @RequestMapping(value = "/update")
    public Object update(HttpServletRequest request, AsmsCheckTask r,String Objects) {
        service.updateTask(r,Objects);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "新增任务(部级)")
//    @RequiresPermissions("asms.cktask.addBjTask")
    @RequestMapping(value = "/addBjTask")
    public Object addBjTask(HttpServletRequest request,AsmsCheckTask r,String Objects) {
        service.addBjTask(r,Objects);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "修改任务(部级)")
//    @RequiresPermissions("asms.cktask.updateBjTask")
    @RequestMapping(value = "/updateBjTask")
    public Object updateBjTask(HttpServletRequest request, AsmsCheckTask r,String Objects) {
        service.updateBjTask(r,Objects);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }


    @ApiOperation(value = "根据id查询任务")
//    @RequiresPermissions("asms.cktask.getTaskById")
    @RequestMapping(value = "/getTaskById")
    public Object getTaskById(HttpServletRequest request,@RequestBody AsmsCheckTask r) {
        AsmsCheckTask o = service.queryById(r.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",o);
        return map;
    }

    @ApiOperation(value = "发布任务")
//    @RequiresPermissions("asms.cktask.rel")
    @RequestMapping(value = "/rel")
    public Object rel(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            AsmsCheckTask o = service.queryById(id.toString());
            o.setState("1");//已废止状态
            service.update(o);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "废止任务")
//    @RequiresPermissions("asms.cktask.abo")
    @RequestMapping(value = "/abo")
    public Object abo(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            AsmsCheckTask o = service.queryById(id.toString());
            o.setState("2");//已废止状态
            service.update(o);
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "删除")
//    @RequiresPermissions("asms.cktask.del")
    @RequestMapping(value = "/del")
    public Object del(HttpServletRequest request,String jsonStr) {
        JSONArray a = JSONArray.parseArray(jsonStr);
        for (Object id : a) {
            service.delete(id.toString());
        }
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        return map;
    }

    @ApiOperation(value = "任务列表")
//    @RequiresPermissions("asms.cktask.list")
    @RequestMapping(value = "/list")
    public Object list(HttpServletRequest request,AsmsCheckTask r, String dateBegin, String dateEnd, int start, int length) {
        PageInfo<List<Map<String, Object>>> data = service.list(r, dateBegin, dateEnd, ((start + 1) / length) + 1, length);
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",data);
        return map;
    }

    @ApiOperation(value = "根据任务id查询抽查对象")
//    @RequiresPermissions("asms.rcktask.getObjById")
    @RequestMapping(value = "/getObjById")
    public Object getObjById(HttpServletRequest request,@RequestBody AsmsMonitorObject r) {
        List<Map<String,Object>> o = service.getObjById(r.getId());
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data",o);
        return map;
    }

    @ApiOperation(value = "报告列表")
//    @RequiresPermissions("asms.cktask.presList")
    @RequestMapping(value = "/presList")
    public Object presList(HttpServletRequest request,AsmsCheckTask r,String dateBegin, String dateEnd, int start, int length) {
        //TODO 待确定报告bean
        Map<String, Object> map = new HashMap<>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

    @ApiOperation(value = "导出任务")
//    @RequiresPermissions("asms.cktask.export")
    @RequestMapping(value = "/export")
    public Object export(HttpServletRequest request, @RequestBody AsmsCheckTask r) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

    @ApiOperation(value = "报告下载")
//    @RequiresPermissions("asms.cktask.download")
    @RequestMapping(value = "/download")
    public Object download(HttpServletRequest request, AsmsCheckTask r) {
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG, ApiMsgConstants.SUCCESS_MSG);
        map.put("data", null);
        return map;
    }

}
