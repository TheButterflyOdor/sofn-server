package com.sofn.web.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.core.support.HttpCode;
import com.sofn.model.generator.*;
import com.sofn.service.asms.AsmsSubjEnforceLawService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:28
 */
@RestController
@Api(value = "主体管理-执法机构",description = "主体管理-执法机构")
@RequestMapping(value = "/subjEnforceLaw",method = RequestMethod.POST)
public class AsmsSubjEnforceLawController extends BaseController{

    @Autowired
    private AsmsSubjEnforceLawService subjEnforceLawService;

    /**
     * 新增执法机构主体
     * @param subjEnforceLaw
     * @return
     */
    @ApiOperation(value = "执法机构主体备案")
    @RequestMapping(value = "/addSubjEnforceLaw")
    public Object addSubjEnforceLaw(@RequestBody AlesSubjEnforceLaw subjEnforceLaw){
        int result = subjEnforceLawService.addSubjEnforceLaw(subjEnforceLaw);
        if(result==1){
            return setSuccessModelMap(new ModelMap());
        }else {
            return setModelMap(new ModelMap(), HttpCode.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 根据ID获取单个执法机构主体详情
     * @param subjEnforceLaw
     * @return
     */
    @ApiOperation(value = "查看执法机构主体详情")
    @RequestMapping(value = "/findSubjEnforceLawById")
    public Object findSubjEnforceLawById(@RequestBody AlesSubjEnforceLaw subjEnforceLaw){
        subjEnforceLaw = subjEnforceLawService.findSubjEnforceLawById(subjEnforceLaw);
        return setSuccessModelMap(new ModelMap(),subjEnforceLaw);
    }

    /**
     * 根据查询条件获取执法机构主体列表
     * @param subjEnforceLaw
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "根据条件获取执法机构主体列表")
    @RequestMapping(value = "/getSubjEnforceLawList")
    public Object getSubjEnforceLawList(AlesSubjEnforceLaw subjEnforceLaw,int start,int length,String dateBegin,String dateEnd){
        PageInfo pageInfo = subjEnforceLawService.getSubjEnforceLawList(subjEnforceLaw, ((start + 1) / length) + 1, length, dateBegin, dateEnd);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 新增执法机构主体撤销申请
     * @param subjElRevoke
     * @return
     */
    @ApiOperation(value = "新增执法机构主体撤销申请")
    @RequestMapping(value = "/addSubjElRevoke")
    public Object addSubjElRevoke(@RequestBody AlesSubjElRevoke subjElRevoke){
        int result = subjEnforceLawService.addSubjElRevoke(subjElRevoke);
        if(result==1){
            return setSuccessModelMap(new ModelMap());
        }else {
            return setModelMap(new ModelMap(),HttpCode.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 批量导入执法机构主体
     * @param request
     * @return
     */
    @ApiOperation(value = "批量导入执法机构主体")
    @RequestMapping(value = "/importSubjEnforceLaw")
    public Object importSubjEnforceLaw(HttpServletRequest request) throws Exception{
        subjEnforceLawService.importSubjEnforceLaw(request);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 通过条件获取执法机构主体变更申请
     * @param subjElChange
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取执法机构主体变更申请")
    @RequestMapping(value = "/getSubjElChangeList")
    public Object getSubjElChangeList(AlesSubjElChange subjElChange,int start,int length,String date){
        PageInfo pageInfo = subjEnforceLawService.getSubjElChangeList(subjElChange, ((start + 1) / length) + 1, length,date);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个执法机构主体变更申请
     * @param subjElChange
     * @return
     */
    @ApiOperation(value = "通过ID获取单个执法机构主体变更申请")
    @RequestMapping(value = "/findSubjElChangeById")
    public Object findSubjElChangeById(@RequestBody AlesSubjElChange subjElChange){
        Map<String,Object> map = new HashMap<>();
        subjElChange = subjEnforceLawService.findSubjElChangeById(subjElChange);
        map.put("subjElChange",subjElChange);
        AlesSubjEnforceLaw subjEnforceLaw = new AlesSubjEnforceLaw();
        subjEnforceLaw.setId(subjElChange.getApplyElId());
        subjEnforceLaw = subjEnforceLawService.findSubjEnforceLawById(subjEnforceLaw);
        map.put("subjEl",subjEnforceLaw);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核执法机构主体变更申请
     * @param subjEnforceLaw
     * @param subjElChange
     * @return
     */
    @ApiOperation(value = "审核执法机构主体变更申请")
    @RequestMapping(value = "/auditSubjElChange")
    public Object auditSubjElChange(AlesSubjEnforceLaw subjEnforceLaw,AlesSubjElChange subjElChange){
        subjEnforceLawService.auditSubjElChange(subjEnforceLaw, subjElChange);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 获取执法机构主体注销申请列表
     * @param subjElCancel
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取执法机构主体注销申请列表")
    @RequestMapping(value = "/getSubjElCancelList")
    public Object getSubjElCancelList(AlesSubjElCancel subjElCancel,int start,int length,String elName,String date){
        PageInfo pageInfo = subjEnforceLawService.getSubjElCancelList(subjElCancel, ((start + 1) / length) + 1, length,elName,date);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个执法机构主体注销申请
     * @param subjElCancel
     * @return
     */
    @ApiOperation(value = "通过ID获取单个执法机构主体注销申请")
    @RequestMapping(value = "/findSubjElCancelById")
    public Object findSubjElCancelById(@RequestBody AlesSubjElCancel subjElCancel){
        Map<String,Object> map = new HashMap<>();
        subjElCancel = subjEnforceLawService.findSubjElCancelById(subjElCancel);
        map.put("subjElCancel",subjElCancel);
        AlesSubjEnforceLaw subjEnforceLaw = new AlesSubjEnforceLaw();
        subjEnforceLaw.setId(subjElCancel.getElId());
        subjEnforceLaw = subjEnforceLawService.findSubjEnforceLawById(subjEnforceLaw);
        map.put("subjEl",subjEnforceLaw);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核执法机构主体注销申请
     * @param subjEnforceLaw
     * @param subjElCancel
     * @return
     */
    @ApiOperation(value = "审核执法机构主体注销申请")
    @RequestMapping(value = "/auditSubjElCancel")
    public Object auditSubjElCancel(AlesSubjEnforceLaw subjEnforceLaw,AlesSubjElCancel subjElCancel){
        subjEnforceLawService.auditSubjElCancel(subjEnforceLaw, subjElCancel);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 通过条件获取执法机构主体撤销申请
     * @param subjElRevoke
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取执法机构主体撤销申请")
    @RequestMapping(value = "/getSubjElRevokeList")
    public Object getSubjElRevokeList(AlesSubjElRevoke subjElRevoke,int start,int length,String elName,String date){
        PageInfo pageInfo = subjEnforceLawService.getSubjElRevokeList(subjElRevoke, ((start + 1) / length) + 1, length,elName,date);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个执法机构主体撤销申请
     * @param subjElRevoke
     * @return
     */
    @ApiOperation(value = "通过ID获取单个执法机构主体撤销申请")
    @RequestMapping(value = "/findSubjElRevokeById")
    public Object findSubjElRevokeById(@RequestBody AlesSubjElRevoke subjElRevoke){
        Map<String,Object> map = new HashMap<>();
        subjElRevoke = subjEnforceLawService.findSubjElRevokeById(subjElRevoke);
        map.put("subjElRevoke",subjElRevoke);
        AlesSubjEnforceLaw subjEnforceLaw = new AlesSubjEnforceLaw();
        subjEnforceLaw.setId(subjElRevoke.getElId());
        subjEnforceLaw = subjEnforceLawService.findSubjEnforceLawById(subjEnforceLaw);
        map.put("subjEl",subjEnforceLaw);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核执法机构主体撤销申请
     * @param subjEnforceLaw
     * @param subjElRevoke
     * @return
     */
    @ApiOperation(value = "审核执法机构主体撤销申请")
    @RequestMapping(value = "/auditSubjElRevoke")
    public Object auditSubjElRevoke(AlesSubjEnforceLaw subjEnforceLaw,AlesSubjElRevoke subjElRevoke){
        subjEnforceLawService.auditSubjElRevoke(subjEnforceLaw, subjElRevoke);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 单纯上传文件--暂加
     * @param request
     * @return
     */
    @ApiOperation(value = "上传文件")
    @RequestMapping(value = "/upload")
    public Map<String,Object> upload(HttpServletRequest request){
        //返回对象
        Map<String,Object> map = new HashMap<>();
        try {
            map.putAll(subjEnforceLawService.upload(request));
        }catch (Exception e){
            map.put(ApiConstants.CODE,ApiMsgConstants.FAILED_CODE);
            map.put(ApiConstants.MSG,ApiMsgConstants.FAILED_MSG);
        }
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG,ApiMsgConstants.SUCCESS_MSG);
        return map;
    }
}
