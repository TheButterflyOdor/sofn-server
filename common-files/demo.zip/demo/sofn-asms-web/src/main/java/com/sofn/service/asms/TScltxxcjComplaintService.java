package com.sofn.service.asms;


import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.TScltxxcjComplaint;
import com.sofn.provider.asms.TScltxxcjComplaintProvider;
import org.springframework.stereotype.Service;
//import java.sql.Timestamp;
//import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * @author dongwenfeng
 * @version 2016年10月8日 下午 4:50
 */

@Service
public class TScltxxcjComplaintService extends BaseService<TScltxxcjComplaintProvider,TScltxxcjComplaint> {
    @DubboReference
    public void setTScltxxcjComplaintProvider(TScltxxcjComplaintProvider provider){
        this.provider = provider;
    }

    public PageInfo getTScltxxcjComplaintList(TScltxxcjComplaint tScltxxcjComplaint, String entityIdcode, String beEntityIdcode,
                                              String complaintTitle,String status,
                                          int pageNum, int pageSize,String queryCon){
        Map<String,Object> queryParams = new HashMap<>();
        queryParams.put("entityIdcode",entityIdcode);
        queryParams.put("beEntityIdcode",beEntityIdcode);
        queryParams.put("complaintTitle",complaintTitle);
        queryParams.put("status",status);
        queryParams.put("pageNum",pageNum);
        queryParams.put("pageSize",pageSize);
        queryParams.put("queryCon",queryCon);
        return provider.getTScltxxcjComplaintList(queryParams);
    }

    /**
     * 根据ID查看当前投诉处理
     * @param id
     * @return
     */
    public TScltxxcjComplaint findTScltxxcjComplaint(String id){

        return provider.findTScltxxcjComplaintById(id);
    }
    public int updatetScltxxcjComplaint(TScltxxcjComplaint tScltxxcjComplaint){
       //tScltxxcjComplaint.setUpdateTime(new Timestamp((new Date()).getTime()));
       return provider.updateTScltxxcjComplaint(tScltxxcjComplaint);
    }
}
