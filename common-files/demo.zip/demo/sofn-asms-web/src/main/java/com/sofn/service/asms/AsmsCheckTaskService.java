package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsCheckBearUnit;
import com.sofn.model.generator.AsmsCheckTask;
import com.sofn.model.generator.AsmsMonitorObject;
import com.sofn.provider.asms.AsmsCheckTaskProvider;
import jodd.util.StringUtil;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@Service
public class AsmsCheckTaskService extends BaseService<AsmsCheckTaskProvider, AsmsCheckTask> {
    @DubboReference
    public void setProvider(AsmsCheckTaskProvider provider) {
        this.provider = provider;
    }

    public void addTask(AsmsCheckTask r, String Objects) {
        r.setState("0");//待发布
        r.setTaskLevel("1");//省级1 部级0
        String id = provider.update(r).getId();//主表信息
        String[] RecheckObject = Objects.split("TableTR");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        for (int i =1; i<=RecheckObject.length; i++) {
            if (i==1) continue;
            String[] TD = RecheckObject[i-1].split("TableTD");
            AsmsMonitorObject o = new AsmsMonitorObject();
            o.setProductType(TD[1]);//产品种类
            o.setProductName(TD[2]);//产品名称
            o.setMonitorNum(TD[3]);//抽样数量
            o.setSampleUnitId(TD[4]);//抽样单位
            o.setDetectionUnitId(TD[5]);//监测单位
            try {
                o.setTaskBeginTime(sdf.parse(TD[6]));//任务时间开始
                o.setTaskEndTime(sdf.parse(TD[7]));//任务时间结束
            }catch (ParseException e)
            {
                System.out.println(e.getMessage());
            }
            o.setDetectionStandard(TD[8]); //检测标准
            o.setJudgeStandard(TD[9]); //判定标准
            o.setSuperviseCheckTaskId(id);//关联复检任务id
            o.setEnable(true);
            provider.addGlInfo(o);//抽检对象
        }
    }

    public void updateTask(AsmsCheckTask r, String Objects) {
        AsmsCheckTask o1 = provider.queryById(r.getId());
        o1.setTaskName(r.getTaskName());//任务名称
        o1.setTaskYear(r.getTaskYear());//年限
        o1.setTaskAreaId(r.getTaskAreaId());//受检区域id
        o1.setTaskBeginTime(r.getTaskBeginTime());//开始时间
        o1.setTaskEndTime(r.getTaskEndTime());//结束时间
        o1.setTaskIsSeparate(r.getTaskIsSeparate());//是否抽检分离
        o1.setTaskReleaseUnit(r.getTaskReleaseUnit());//发布单位
        o1.setTaskSampleDeadline(r.getTaskSampleDeadline());//抽样信息上报截止时间
        provider.update(o1);//主表信息
        provider.delGlInfoByTaskId(r.getId());//删除原数据
        String[] RecheckObject = Objects.split("TableTR");
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        for (int i =1; i<=RecheckObject.length; i++) {
            if (i==1) continue;
            String[] TD = RecheckObject[i-1].split("TableTD");
            AsmsMonitorObject o = new AsmsMonitorObject();
            o.setProductType(TD[1]);//产品种类
            o.setProductName(TD[2]);//产品名称
            o.setMonitorNum(TD[3]);//抽样数量
            o.setSampleUnitId(TD[4]);//抽样单位
            o.setDetectionUnitId(TD[5]);//监测单位
            try {
                o.setTaskBeginTime(sdf.parse(TD[6]));//任务时间开始
                o.setTaskEndTime(sdf.parse(TD[7]));//任务时间结束
            }catch (ParseException e)
            {
                System.out.println(e.getMessage());
            }
            o.setDetectionStandard(TD[8]); //检测标准
            o.setJudgeStandard(TD[9]); //判定标准
            o.setSuperviseCheckTaskId(r.getId());//关联复检任务id
            o.setEnable(true);
            provider.addGlInfo(o);//抽检对象
        }
    }


    public void addBjTask(AsmsCheckTask r, String Objects) {
        r.setState("0");//待发布
        r.setTaskLevel("0");//省级1 部级0
        String id = provider.update(r).getId();//主表信息
        String[] ids = Objects.split("\\|");
        for (String oid : ids) {
            AsmsCheckBearUnit o = new AsmsCheckBearUnit();
            o.setSuperviseCheckTaskId(id);
            o.setSuperviseBearUnitId(oid);
            provider.addBjGlInfo(o);
        }
    }

    public void updateBjTask(AsmsCheckTask r, String Objects) {
        AsmsCheckTask o1 = provider.queryById(r.getId());
        o1.setTaskName(r.getTaskName());//任务名称
        o1.setTaskType(r.getTaskType());//任务类型
        o1.setTaskYear(r.getTaskYear());//年限
        o1.setTaskBeginTime(r.getTaskBeginTime());//开始时间
        o1.setTaskEndTime(r.getTaskEndTime());//结束时间
        o1.setTaskReleaseUnit(r.getTaskReleaseUnit());//发布单位
        o1.setFiles(r.getFiles());//附件
        o1.setFileCode(r.getFileCode());//文件号
        o1.setRemark(r.getRemark());//备注
        provider.update(o1);//主表信息
        //关联表信息
        provider.delBjGlInfoByTaskId(r.getId());//删除原数据
        String[] ids = Objects.split("\\|");
        for (String oid : ids) {
            AsmsCheckBearUnit o = new AsmsCheckBearUnit();
            o.setSuperviseCheckTaskId(r.getId());
            o.setSuperviseBearUnitId(oid);
            provider.addBjGlInfo(o);//新数据添加
        }
    }

    public List<Map<String,Object>> getObjById(String id){
        return provider.getObjById(id);
    }

    public PageInfo<List<Map<String, Object>>> list(AsmsCheckTask r, String dateBegin, String dateEnd, int pageNum, int pageSize) {
        Map<String, Object> params = new HashMap<>();
        //page
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        //query
        params.put("dateBegin", StringUtil.isNotBlank(dateBegin) ? dateBegin : null);
        params.put("dateEnd", StringUtil.isNotBlank(dateEnd) ? dateEnd : null);
        params.put("taskName", StringUtil.isNotBlank(r.getTaskName()) ? "%"+r.getTaskName()+"%" : null);
        params.put("state", StringUtil.isNotBlank(r.getState()) ? r.getState() : null);
        PageInfo<List<Map<String, Object>>> i = provider.list(params);
        return i;
    }

    public Object download() {
        return null;
    }

    public Object rel() {
        return null;
    }

    public Object abo() {
        return null;
    }

    public Object export() {
        return null;
    }

    public Object querypre() {
        return null;
    }

}
