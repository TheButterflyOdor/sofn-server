package com.sofn.web.asms;

import com.sofn.core.base.BaseController;
import com.sofn.core.config.Resources;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.exception.LoginException;
import com.sofn.core.support.Assert;
import com.sofn.core.support.HttpCode;
import com.sofn.core.util.RedisUtil;
import com.sofn.core.util.ValidateCodeUtil;
import com.sofn.core.util.WebUtil;
import com.sofn.model.sso.LoginUser;
import com.sofn.service.asms.SSOLoginService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.Map;

/**
 * Created by dong4j on 16/9/13.
 * Description: 调用单点系统进行验证登录
 */
@RestController
@Api(value = "单点登录接口", description = "单点登录接口")
public class LoginController extends BaseController  {
    /**
     * The Sso login service.
     */
    @Autowired
    private SSOLoginService ssoLoginService;

    /**
     * Login sso object.
     *
     * @param modelMap the model map
     * @param account  the account
     * @param password the password
     * @return the object
     */
//////////////////////////////////////////////////////////////////////////
    @ApiOperation(value = "用户登录")
    @PostMapping("/login")
    public Object login(ModelMap modelMap,
                            @ApiParam(required = true, value = "登录帐号")
                            @RequestParam(value = "account", required = false) String account,
                            @ApiParam(required = true, value = "登录密码")
                            @RequestParam(value = "password", required = false) String password,
                            @ApiParam(required = true, value = "刷新后UUID")
                            @RequestParam(name = "uuid", required = false) String uuid,
                            @ApiParam(required = true, value = "验证码")
                            @RequestParam(name = "code", required = false) String code) {
        // 参数检查
        Assert.isNotBlank(account, "ACCOUNT");
        Assert.isNotBlank(password, "PASSWORD");
        Assert.isNotBlank(uuid, "UUID");
        Assert.isNotBlank(code, "CODE");
        if(ValidateCodeUtil.checkCode(uuid,code)){
            //登录逻辑
            Map<String,String> map = ssoLoginService.login(account,password);
            if(map == null){
                throw new LoginException(Resources.getMessage("LOGIN_FAIL"));
            }
            WebUtil.saveCurrentUser(map.get("userId"));
            return setSuccessModelMap(modelMap,map);
        }
        throw new LoginException(Resources.getMessage("CODE_ERROR"));
    }
    /////////////////////////////////////////////////////////////////////////

    /**
     * Gets uuid.
     * 前端刷新登录页面或者点击验证码图片时调用此接口,用于生成uuid
     * @param modelMap the model map
     * @param prevUUID the prev uuid 如果没有则不传
     * @return the uuid
     */
    @ApiOperation(value = "加载login.html时向后台获取UUID")
    @RequestMapping(value = "/getUUID",method = RequestMethod.GET)
    public Object generatorCode(ModelMap modelMap,HttpServletResponse response,
                                @ApiParam(required = false, value = "前一次的uuid")
                                @RequestParam(name = "prev", required = false) String prevUUID) {
        // 解决垮域请求
        response.setHeader("Access-Control-Allow-Origin", "*");
        String uuid = ValidateCodeUtil.getUUID(prevUUID, ApiConstants.VALIDATE_CODE_LEN);
        modelMap.addAttribute("uuid", uuid);
        String code = (String) RedisUtil.get(uuid);
        modelMap.addAttribute("code",code);
        return setSuccessModelMap(modelMap);
    }

    /**
     * Generator image.
     * 前端先调用 generatorCode 获取uuid,然后将uuid传入到此接口获取验证码图片反给前端
     * @param request  the request
     * @param response the response
     * @param currUUID the curr uuid
     * @throws Exception the exception
     */
    @ApiOperation(value = "生成验证码")
    @RequestMapping(value="/generatorImage",method = RequestMethod.GET)
    public void generatorImage(HttpServletRequest request, HttpServletResponse response,
                               @ApiParam(required = true, value = "刷新后UUID")
                               @RequestParam(name = "curr", required = false) String currUUID) throws Exception {
        Assert.isNotBlank(currUUID, "CURRUUID");
        response.setHeader("Access-Control-Allow-Origin", "*");
        ValidateCodeUtil.getRandcode(request, response, currUUID);
    }

    /**
     * Logout object.
     * 用户登出
     * @param modelMap the model map
     * @param token    the token
     * @return the object
     */
    @ApiOperation(value = "用户登出")
    @PostMapping("/logout")
    public Object logout(ModelMap modelMap,
                         @ApiParam(required = true, value = "token")
                         @RequestHeader(value = "token", defaultValue = "") String  token,
                         @ApiParam(required = true, value = "pc or app")
                         @RequestHeader(value = "type", defaultValue = "") String  type) {
        Assert.isNotBlank(token,"TOKEN");
        Assert.isNotBlank(type,"TYPE");
        ssoLoginService.logout(token, type);
        return setSuccessModelMap(modelMap);
    }
}
