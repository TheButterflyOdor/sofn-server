package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsRecheckObject;
import com.sofn.model.generator.AsmsRecheckTask;
import com.sofn.provider.asms.AsmsRecheckTaskProvider;
import jodd.util.StringUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@Service
public class AsmsRecheckTaskService extends BaseService<AsmsRecheckTaskProvider, AsmsRecheckTask> {
    @DubboReference
    public void setProvider(AsmsRecheckTaskProvider provider) {
        this.provider = provider;
    }

    public void addTask(AsmsRecheckTask r, String RecheckObjects) {
        r.setState("0");//待发布
        String id = provider.update(r).getId();//主表信息
        String[] RecheckObject = RecheckObjects.split("TableTR");
        for (int i =1; i<=RecheckObject.length; i++) {
            if (i==1) continue;
            String[] TD = RecheckObject[i-1].split("TableTD");
            AsmsRecheckObject o = new AsmsRecheckObject();
            o.setRecheckSampleName(TD[1]);//复检样品名称
            o.setRecheckSampleCode(TD[2]);//复检样品编码
            o.setRecheckUnitId(TD[3]);//复检单位
            o.setRecheckStandard(TD[4]);//复检标准
            o.setRecheckJudgeStandard(TD[5]);//判断标准
            o.setRecheckTaskId(id);//关联复检任务id
            o.setEnable(true);
            provider.addGlInfo(o);//复检对象
        }
    }

    public void updateTask(AsmsRecheckTask r, String RecheckObjects) {
        AsmsRecheckTask o1 = provider.queryById(r.getId());
        o1.setRecheckTaskName(r.getRecheckTaskName());
        o1.setRecheckTaskYear(r.getRecheckTaskYear());
        o1.setRecheckTaskBegin(r.getRecheckTaskBegin());
        o1.setRecheckTaskEnd(r.getRecheckTaskEnd());
        provider.update(o1);//主表信息
        provider.delGlInfoByTaskId(r.getId());//删除原数据
        String[] RecheckObject = RecheckObjects.split("TableTR");
        for (int i =1; i<=RecheckObject.length; i++) {
            if (i==1) continue;
            String[] TD = RecheckObject[i-1].split("TableTD");
            AsmsRecheckObject o = new AsmsRecheckObject();
            o.setRecheckSampleName(TD[1]);
            o.setRecheckSampleCode(TD[2]);
            o.setRecheckUnitId(TD[3]);
            o.setRecheckStandard(TD[4]);
            o.setRecheckJudgeStandard(TD[5]);
            o.setRecheckTaskId(r.getId());
            o.setEnable(true);
            provider.addGlInfo(o);//关联表信息
        }
    }

    public List<Map<String,Object>> getObjById(String id){
        return provider.getObjById(id);
    }

    public PageInfo<List<Map<String, Object>>> list(AsmsRecheckTask r, String dateBegin, String dateEnd, int pageNum, int pageSize) {
        Map<String, Object> params = new HashMap<>();
        //page
        params.put("pageNum", pageNum);
        params.put("pageSize", pageSize);
        //query
        params.put("recheckTaskBegin", StringUtil.isNotBlank(dateBegin) ? dateBegin : null);
        params.put("recheckTaskEnd", StringUtil.isNotBlank(dateEnd) ? dateEnd : null);
        params.put("recheckTaskName", StringUtil.isNotBlank(r.getRecheckTaskName()) ? "%"+r.getRecheckTaskName()+"%" : null);
        params.put("recheckTaskYear", StringUtil.isNotBlank(r.getRecheckTaskYear()) ? "%"+r.getRecheckTaskYear()+"%" : null);
        params.put("state", StringUtil.isNotBlank(r.getState()) ? r.getState() : null);
        PageInfo<List<Map<String, Object>>> i = provider.list(params);
        return i;
    }

    public Object download() {
        return null;
    }

    public Object rel() {
        return null;
    }

    public Object abo() {
        return null;
    }

    public Object export() {
        return null;
    }

    public Object querypre() {
        return null;
    }

}
