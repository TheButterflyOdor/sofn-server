package com.sofn.service.asms;

import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.provider.asms.AsmsSubjSvChangeProvider;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.UUID;

/**
 * Created by Administrator on 2016/10/12.
 */
@Service
public class AsmsSubjSvChangeService extends BaseService<AsmsSubjSvChangeProvider,AsmsSubjSvChange>{
    @DubboReference
    public void setSubjSvChangeProvider(AsmsSubjSvChangeProvider provider){
        this.provider = provider;
    }
    public int addSubjSvChange(AsmsSubjSvChange subjSvChange){
        subjSvChange.setId(UUID.randomUUID().toString().replace("-", ""));
        subjSvChange.setApplySvId("暂无");
        subjSvChange.setApplyTime(new Date());
        subjSvChange.setEnable(true);
        return provider.addSubjSvChange(subjSvChange);
    }
}
