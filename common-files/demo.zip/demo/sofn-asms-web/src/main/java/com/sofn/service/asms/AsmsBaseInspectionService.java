package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.core.util.StringUtils;
import com.sofn.model.generator.AsmsBaseInspection;
import com.sofn.provider.asms.AsmsBaseInspectionProvider;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author sofn
 * @version 2016年08月25日 下午 4:50
 */
@Service
public class AsmsBaseInspectionService extends BaseService<AsmsBaseInspectionProvider,AsmsBaseInspection> {

    @DubboReference
    public void setBaseInspectionProvider(AsmsBaseInspectionProvider provider){
        this.provider = provider;
    }

    public int addBaseInspection(AsmsBaseInspection asmsBaseInspection){
        if(StringUtils.isNullEmpty(asmsBaseInspection.getId())){
            asmsBaseInspection.setId(UUID.randomUUID().toString().replace("-", ""));
            asmsBaseInspection.setElCheckState("0");//新增基地巡查的时候执法检查设为未执行
            asmsBaseInspection.setEnable(true);
            asmsBaseInspection.setCreateTime(new Date());
            return provider.addBaseInspection(asmsBaseInspection);
        }else{
            return provider.updateBaseInspection(asmsBaseInspection);
        }

    }

    public PageInfo getBaseInspectionList(AsmsBaseInspection asmsBaseInspection,String dateBegin,String dateEnd,
                                          int pageNum,int pageSize,String enterpriseIndustry,String entityScale,String enterpriseName){
        Map<String,Object> queryParams = new HashMap<>();
        queryParams.put("dateBegin",dateBegin);
        queryParams.put("dateEnd",dateEnd);
        queryParams.put("pageNum",pageNum);
        queryParams.put("pageSize",pageSize);
        queryParams.put("inspectionResult",asmsBaseInspection.getInspectionResult());
        queryParams.put("enterpriseIndustry",enterpriseIndustry);
        queryParams.put("entityScale",entityScale);
        queryParams.put("enterpriseName",enterpriseName);
        return provider.getBaseInspectionAllList(queryParams);
//        return provider.getBaseInspectionList(queryParams);
    }

    //暂加
    public PageInfo getEnterpriseList(int pageNum,int pageSize){
        Map<String,Object> queryParams = new HashMap<>();
        queryParams.put("pageNum",pageNum);
        queryParams.put("pageSize",pageSize);
        return provider.getEnterpriseList(queryParams);
    }

    //暂加
    public Map<String,Object> findEnterpriseById(String enterpriseId){
        return provider.findEnterpriseById(enterpriseId);
    }

    public AsmsBaseInspection findBaseInspectionById(String id){
        return provider.findBaseInspectionById(id);
    }

    public int updateBaseInspection(AsmsBaseInspection asmsBaseInspection){
        return provider.updateBaseInspection(asmsBaseInspection);
    }

    public int deleteBaseInspection(String id){
        return provider.deleteBaseInspection(id);
    }

}
