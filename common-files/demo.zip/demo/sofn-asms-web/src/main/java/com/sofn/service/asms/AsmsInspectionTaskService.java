package com.sofn.service.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseService;
import com.sofn.core.support.dubbo.spring.annotation.DubboReference;
import com.sofn.model.generator.AsmsInspectionTask;
import com.sofn.provider.asms.AsmsInspectionTaskProvider;
import jodd.util.StringUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@Service
public class AsmsInspectionTaskService extends BaseService<AsmsInspectionTaskProvider, AsmsInspectionTask> {
    @DubboReference
    public void setProvider(AsmsInspectionTaskProvider provider) {
        this.provider = provider;
    }

    /*获取分页列表*/
    public PageInfo<AsmsInspectionTask> getPageList (Map<String, Object> params){
        return  provider.getPageList(params);
    }

    public AsmsInspectionTask findById(String id) {
        AsmsInspectionTask   record = provider.findById(id);
        return record;
    }

    /*任务列表*/
    public PageInfo<List<Map<String, Object>>> getPages(AsmsInspectionTask task, String dateBegin, String dateEnd, int pageNum, int pageSize) {
        Map<String, Object> queryParams = new HashMap<>();
        queryParams.put("dateBegin", dateBegin);
        queryParams.put("dateEnd", dateEnd);
        queryParams.put("pageNum", pageNum);
        queryParams.put("pageSize", pageSize);
        queryParams.put("taskType",StringUtil.isNotBlank(task.getTaskType()) ? "%" + task.getTaskType() + "%" : null);
        queryParams.put("taskDateType",StringUtil.isNotBlank(task.getTaskDateType()) ? "%" + task.getTaskDateType() + "%" : null);
        PageInfo<List<Map<String, Object>>> i = provider.getPages(queryParams);
        return i;
    }
}
