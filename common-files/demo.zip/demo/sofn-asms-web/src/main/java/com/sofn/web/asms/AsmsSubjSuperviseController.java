package com.sofn.web.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseController;
import com.sofn.core.constant.ApiConstants;
import com.sofn.core.constant.ApiMsgConstants;
import com.sofn.core.support.HttpCode;
import com.sofn.model.generator.AsmsSubjSupervise;
import com.sofn.model.generator.AsmsSubjSvCancel;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.model.generator.AsmsSubjSvRevoke;
import com.sofn.service.asms.AsmsSubjSuperviseService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:28
 */
@RestController
@Api(value = "主体管理-监管机构",description = "主体管理-监管机构")
@RequestMapping(value = "/subjSupervise",method = RequestMethod.POST)
public class AsmsSubjSuperviseController extends BaseController{

    @Autowired
    private AsmsSubjSuperviseService subjSuperviseService;

    /**
     * 新增监管机构主体
     * @param subjSupervise
     * @return
     */
    @ApiOperation(value = "监管机构主体备案")
    @RequestMapping(value = "/addSubjSupervise")
    public Object addSubjSupervise(@RequestBody AsmsSubjSupervise subjSupervise){
        int result = subjSuperviseService.addSubjSupervise(subjSupervise);
        if(result==1){
            return setSuccessModelMap(new ModelMap());
        }else{
            return setModelMap(new ModelMap(), HttpCode.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 根据ID获取单个监管机构主体详情
     * @param subjSupervise
     * @return
     */
    @ApiOperation(value = "查看监管机构主体详情")
    @RequestMapping(value = "/findSubjSuperviseById")
    public Object findSubjSuperviseById(@RequestBody AsmsSubjSupervise subjSupervise){
        subjSupervise = subjSuperviseService.findSubjSuperviseById(subjSupervise);
        return setSuccessModelMap(new ModelMap(), subjSupervise);
    }

    /**
     * 根据查询条件获取监管机构主体列表
     * @param subjSupervise
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "根据条件获取监管机构主体列表")
    @RequestMapping(value = "/getSubjSuperviseList")
    public Object getSubjSuperviseList(AsmsSubjSupervise subjSupervise,int start,int length,String dateBegin,String dateEnd){
        PageInfo pageInfo = subjSuperviseService.getSubjSuperviseList(subjSupervise, ((start + 1) / length) + 1, length,dateBegin,dateEnd);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 新增监管机构主体撤销申请
     * @param subjSvRevoke
     * @return
     */
    @ApiOperation(value = "新增监管机构主体撤销申请")
    @RequestMapping(value = "/addSubjSvRevoke")
    public Object addSubjSvRevoke(@RequestBody AsmsSubjSvRevoke subjSvRevoke){
        int result = subjSuperviseService.addSubjSvRevoke(subjSvRevoke);
        if(result==1){
            return setSuccessModelMap(new ModelMap());
        }else{
            return setModelMap(new ModelMap(), HttpCode.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * 批量导入监管机构主体
     * @param request
     * @return
     */
    @ApiOperation(value = "批量导入监管机构主体")
    @RequestMapping(value = "/importSubjSupervise")
    public Object importSubjSupervise(HttpServletRequest request) throws Exception{
        subjSuperviseService.importSubjSupervise(request);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 通过条件获取监管机构主体变更申请
     * @param subjSvChange
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取监管机构主体变更申请")
    @RequestMapping(value = "/getSubjSvChangeList")
    public Object getSubjSvChangeList(AsmsSubjSvChange subjSvChange,int start,int length,String date){
        return setSuccessModelMap(new ModelMap(),subjSuperviseService.getSubjSvChangeList(subjSvChange, ((start + 1) / length) + 1, length,date));
    }

    /**
     * 通过ID获取单个监管机构主体变更申请
     * @param subjSvChange
     * @return
     */
    @ApiOperation(value = "通过ID获取单个监管机构主体变更申请")
    @RequestMapping(value = "/findSubjSvChangeById")
    public Object findSubjSvChangeById(@RequestBody AsmsSubjSvChange subjSvChange){
        Map<String,Object> map = new HashMap<>();
        subjSvChange = subjSuperviseService.findSubjSvChangeById(subjSvChange);
        map.put("subjSvChange",subjSvChange);
        AsmsSubjSupervise subjSupervise = new AsmsSubjSupervise();
        subjSupervise.setId(subjSvChange.getApplySvId());
        subjSupervise = subjSuperviseService.findSubjSuperviseById(subjSupervise);
        map.put("subjSv",subjSupervise);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核监管机构主体变更申请
     * @param subjSvChange
     * @return
     */
    @ApiOperation(value = "审核监管机构主体变更申请")
    @RequestMapping(value = "/auditSubjSvChange")
    public Object auditSubjSvChange(@RequestBody AsmsSubjSvChange subjSvChange){
        subjSuperviseService.auditSubjSvChange(subjSvChange);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 获取监管机构主体注销申请列表
     * @param subjSvCancel
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取监管机构主体注销申请列表")
    @RequestMapping(value = "/getSubjSvCancelList")
    public Object getSubjSvCancelList(AsmsSubjSvCancel subjSvCancel,int start,int length,String date,String svName){
        PageInfo pageInfo = subjSuperviseService.getSubjSvCancelList(subjSvCancel, ((start + 1) / length) + 1, length,date,svName);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个监管机构主体注销申请
     * @param subjSvCancel
     * @return
     */
    @ApiOperation(value = "通过ID获取单个监管机构主体注销申请")
    @RequestMapping(value = "/findSubjSvCancelById")
    public Object findSubjSvCancelById(@RequestBody AsmsSubjSvCancel subjSvCancel){
        Map<String,Object> map = new HashMap<>();
        subjSvCancel = subjSuperviseService.findSubjSvCancelById(subjSvCancel);
        map.put("subjSvCancel",subjSvCancel);
        AsmsSubjSupervise subjSupervise = new AsmsSubjSupervise();
        subjSupervise.setId(subjSvCancel.getSvId());
        subjSupervise = subjSuperviseService.findSubjSuperviseById(subjSupervise);
        map.put("subjSv",subjSupervise);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核监管机构主体注销申请
     * @param subjSvCancel
     * @return
     */
    @ApiOperation(value = "审核监管机构主体注销申请")
    @RequestMapping(value = "/auditSubjSvCancel")
    public Object auditSubjSvCancel(@RequestBody AsmsSubjSvCancel subjSvCancel){
        subjSuperviseService.auditSubjSvCancel(subjSvCancel);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 通过条件获取监管机构主体撤销申请
     * @param subjSvRevoke
     * @param start
     * @param length
     * @return
     */
    @ApiOperation(value = "获取监管机构主体撤销申请")
    @RequestMapping(value = "/getSubjSvRevokeList")
    public Object getSubjSvRevokeList(AsmsSubjSvRevoke subjSvRevoke,int start,int length,String date,String svName){
        PageInfo pageInfo = subjSuperviseService.getSubjSvRevokeList(subjSvRevoke, ((start + 1) / length) + 1, length,date,svName);
        return setSuccessModelMap(new ModelMap(),pageInfo);
    }

    /**
     * 通过ID获取单个监管机构主体撤销申请
     * @param subjSvRevoke
     * @return
     */
    @ApiOperation(value = "通过ID获取单个监管机构主体撤销申请")
    @RequestMapping(value = "/findSubjSvRevokeById")
    public Object findSubjSvRevokeById(@RequestBody AsmsSubjSvRevoke subjSvRevoke){
        Map<String,Object> map = new HashMap<>();
        subjSvRevoke = subjSuperviseService.findSubjSvRevokeById(subjSvRevoke);
        map.put("subjSvRevoke",subjSvRevoke);
        AsmsSubjSupervise subjSupervise = new AsmsSubjSupervise();
        subjSupervise.setId(subjSvRevoke.getSvId());
        subjSupervise = subjSuperviseService.findSubjSuperviseById(subjSupervise);
        map.put("subjSv",subjSupervise);
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG,ApiMsgConstants.SUCCESS_MSG);
        return setSuccessModelMap(new ModelMap(),map);
    }

    /**
     * 审核监管机构主体撤销申请
     * @param subjSvRevoke
     * @return
     */
    @ApiOperation(value = "审核监管机构主体撤销申请")
    @RequestMapping(value = "/auditSubjSvRevoke")
    public Object auditSubjSvRevoke(@RequestBody AsmsSubjSvRevoke subjSvRevoke){
        subjSuperviseService.auditSubjSvRevoke(subjSvRevoke);
        return setSuccessModelMap(new ModelMap());
    }

    /**
     * 单纯上传文件--暂加
     * @param request
     * @return
     */
    @ApiOperation(value = "上传文件")
    @RequestMapping(value = "/upload")
    public Map<String,Object> upload(HttpServletRequest request){
        //返回对象
        Map<String,Object> map = new HashMap<>();
        try {
            map.putAll(subjSuperviseService.upload(request));
        }catch (Exception e){
            map.put(ApiConstants.CODE,ApiMsgConstants.FAILED_CODE);
            map.put(ApiConstants.MSG,ApiMsgConstants.FAILED_MSG);
        }
        map.put(ApiConstants.CODE, ApiMsgConstants.SUCCESS_CODE);
        map.put(ApiConstants.MSG,ApiMsgConstants.SUCCESS_MSG);
        return map;
    }
}
