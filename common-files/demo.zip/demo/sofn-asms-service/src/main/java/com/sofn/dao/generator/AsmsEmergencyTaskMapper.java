package com.sofn.dao.generator;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseMapper;
import com.sofn.model.generator.AsmsEmergencyTask;

import java.util.List;
@MyBatisDao
public interface AsmsEmergencyTaskMapper extends BaseMapper<AsmsEmergencyTask> {
    int deleteByPrimaryKey(String id);

    int insert(AsmsEmergencyTask record);

    AsmsEmergencyTask selectByPrimaryKey(String id);

    List<AsmsEmergencyTask> selectAll();

    int updateByPrimaryKey(AsmsEmergencyTask record);
}