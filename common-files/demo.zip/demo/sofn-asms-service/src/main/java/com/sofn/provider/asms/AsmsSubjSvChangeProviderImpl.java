package com.sofn.provider.asms;

import com.sofn.core.base.BaseProviderImpl;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.generator.*;
import com.sofn.model.generator.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;
/**
 * Created by Administrator on 2016/10/12.
 */
@DubboService(interfaceClass = AsmsSubjSvChangeProvider.class)
public class AsmsSubjSvChangeProviderImpl extends BaseProviderImpl<AsmsSubjSvChange> implements AsmsSubjSvChangeProvider {

    @Autowired
    private AsmsSubjSvChangeMapper subjSvChangeMapper;

    @Override
    public int addSubjSvChange(AsmsSubjSvChange subjSvChange) {
        return subjSvChangeMapper.insert(subjSvChange);
    }
}
