package com.sofn.dao.asms;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.generator.AsmsSubjSupervise;
import com.sofn.model.generator.AsmsSubjSvCancel;
import com.sofn.model.generator.AsmsSubjSvChange;
import com.sofn.model.generator.AsmsSubjSvRevoke;

import java.util.List;
import java.util.Map;

/**
 * Mapper 扩展
 *
 * @author sofn
 * @version 2016年09月12日 下午 4:02
 */
@MyBatisDao
public interface AsmsSubjSuperviseExpandMapper extends BaseExpandMapper{

    public List<AsmsSubjSupervise> getSubjSuperviseList(Map<String,Object> map);

    public long getSubjSuperviseCount(Map<String,Object> map);

    public List<Map<String,Object>> getSubjSvChangeList(Map<String,Object> map);

    public long getSubjSvChangeCount(Map<String,Object> map);

    public List<Map<String,Object>> getSubjSvCancelList(Map<String,Object> map);

    public long getSubjSvCancelCount(Map<String,Object> map);

    public List<Map<String,Object>> getSubjSvRevokeList(Map<String,Object> map);

    public long getSubjSvRevokeCount(Map<String,Object> map);
}
