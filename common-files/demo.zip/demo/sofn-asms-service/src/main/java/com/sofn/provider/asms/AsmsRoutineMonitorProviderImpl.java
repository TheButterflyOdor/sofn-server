/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsRoutineLeadUnitExpandMapper;
import com.sofn.dao.asms.AsmsRoutineMonitorExpandMapper;
import com.sofn.dao.generator.AsmsRoutineLeadUnitMapper;
import com.sofn.model.generator.AsmsRoutineLeadUnit;
import com.sofn.model.generator.AsmsRoutineMonitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@DubboService(interfaceClass = AsmsRoutineMonitorProvider.class)
@CacheConfig(cacheNames = "AsmsRoutineMonitor")
public class AsmsRoutineMonitorProviderImpl extends BaseProviderImpl<AsmsRoutineMonitor> implements AsmsRoutineMonitorProvider {
    @Autowired
    private AsmsRoutineMonitorExpandMapper mapper;
    @Autowired
    private AsmsRoutineLeadUnitMapper LeadUnitMapper;//自动生成关联表mapp
    @Autowired
    private AsmsRoutineLeadUnitExpandMapper LeadUnitExpandMapper;//扩展关联表mapp

    @Override
    public PageInfo<List<Map<String, Object>>> list(Map<String, Object> params) {
        PageInfo pageInfo = new PageInfo();
        List<Map<String, Object>> list = mapper.getPagesList(params);
        long count = mapper.getPageCount(params);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    public void addGlInfo(String taskId, String jgId) {
        AsmsRoutineLeadUnit b = new AsmsRoutineLeadUnit();
        b.setId(UUID.randomUUID().toString().replace("-", ""));//赋值id
        b.setRoutineMonitorId(taskId);//任务id
        b.setLeadUnitId(jgId);//牵头单位id
        LeadUnitMapper.insert(b);
    }

    @Override
    public void delGlInfoByTaskId(String taskId) {
        AsmsRoutineLeadUnit t = new AsmsRoutineLeadUnit();
        t.setRoutineMonitorId(taskId);
        LeadUnitExpandMapper.delByTaskId(t);
    }

}
