package com.sofn.dao.asms;

import com.github.pagehelper.Page;
import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.asms.SuperviseCheckDto;
import com.sofn.model.asms.UserAndTaskDto;
import com.sofn.model.generator.AsmsInspectionAssess;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

/**
 * Mapper扩展
 *
 * @author sofn
 * @version 2016年8月29日 下午3:4:0
 */
@MyBatisDao
public interface AsmsInspectionAssessExpandMapper extends BaseExpandMapper {

    List<AsmsInspectionAssess> getXcUserIds(AsmsInspectionAssess taskUser);

    void  delOldDate (AsmsInspectionAssess taskUser);

    Page<String> getPageList(Map<String, Object> params);
	
	Page<String> getPageIds(Map<String, Object> params);

    List<SuperviseCheckDto> getSuperviseTaskInfos();

    List<UserAndTaskDto> getgetSuperviseTaskInfoOther();

    Map<String, Object> expandSelectByPrimaryKey(String id);

    Long getPageCount(Map<String, Object> params);

    List<Map<String,Object>> getPagesList(Map<String, Object> map);

    List<Map<String,Object>> getBaseInspectionAllList(Map<String, Object> map);

    long getBaseInspectionAllCount(@Param("xcPsersionId")String  xcPsersionId);

    long getRealCount(@Param("userId")String  userId);

}