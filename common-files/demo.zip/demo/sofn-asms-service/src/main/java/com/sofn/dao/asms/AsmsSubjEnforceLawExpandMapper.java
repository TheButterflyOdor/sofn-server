package com.sofn.dao.asms;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.generator.AlesSubjElCancel;
import com.sofn.model.generator.AlesSubjElChange;
import com.sofn.model.generator.AlesSubjElRevoke;
import com.sofn.model.generator.AlesSubjEnforceLaw;

import java.util.List;
import java.util.Map;

/**
 * Mapper 扩展
 *
 * @author sofn
 * @version 2016年09月27日 上午 9:49
 */
@MyBatisDao
public interface AsmsSubjEnforceLawExpandMapper extends BaseExpandMapper{

    public List<AlesSubjEnforceLaw> getSubjectEnforceLawList(Map<String,Object> map);

    public long getSubjectEnforceLawCount(Map<String,Object> map);

    public List<Map<String,Object>> getSubjElChangeList(Map<String,Object> map);

    public long getSubjElChangeCount(Map<String,Object> map);

    public List<Map<String,Object>> getSubjElCancelList(Map<String,Object> map);

    public long getSubjElCancelCount(Map<String,Object> map);

    public List<Map<String,Object>> getSubjElRevokeList(Map<String,Object> map);

    public long getSubjElRevokeCount(Map<String,Object> map);
}
