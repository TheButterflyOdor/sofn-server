
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsSubjEnforceLawExpandMapper;
import com.sofn.dao.generator.*;
import com.sofn.model.generator.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:35
 */
@DubboService(interfaceClass = AsmsSubjEnforceLawProvider.class)
public class AsmsSubjEnforceLawProviderImpl extends BaseProviderImpl<AlesSubjEnforceLaw> implements AsmsSubjEnforceLawProvider {

    @Autowired
    private AlesSubjEnforceLawMapper subjEnforceLawMapper;
    @Autowired
    private AsmsSubjEnforceLawExpandMapper subjEnforceLawExpandMapper;
    @Autowired
    private AlesSubjElRevokeMapper subjElRevokeMapper;
    @Autowired
    private AlesSubjElChangeMapper subjElChangeMapper;
    @Autowired
    private AlesSubjElCancelMapper subjElCancelMapper;
    @Autowired
    private AlesSubjElModifylogMapper subjElModifylogMapper;

    @Override
    public int addSubjEnforceLaw(AlesSubjEnforceLaw subjEnforceLaw) {
        return subjEnforceLawMapper.insert(subjEnforceLaw);
    }

    @Override
    public AlesSubjEnforceLaw findSubjEnforceLawById(String id) {
        return subjEnforceLawMapper.selectByPrimaryKey(id);
    }

    @Override
    public PageInfo getSubjEnforceLawList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        List<AlesSubjEnforceLaw> list = subjEnforceLawExpandMapper.getSubjectEnforceLawList(map);
        long count = subjEnforceLawExpandMapper.getSubjectEnforceLawCount(map);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    public int addSubjElRevoke(AlesSubjElRevoke subjElRevoke) {
        return subjElRevokeMapper.insert(subjElRevoke);
    }

    @Override
    public PageInfo getSubjElChangeList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        pageInfo.setTotal(subjEnforceLawExpandMapper.getSubjElChangeCount(map));
        pageInfo.setList(subjEnforceLawExpandMapper.getSubjElChangeList(map));
        return pageInfo;
    }

    @Override
    public AlesSubjElChange findSubjElChangeById(String id) {
        return subjElChangeMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void auditSubjElChange(AlesSubjEnforceLaw subjEnforceLaw, AlesSubjElChange subjElChange) {
        //第一步，先修改申请表的状态
        subjElChangeMapper.updateByPrimaryKey(subjElChange);
        //第二步，将修改记录插入修改记录表
        AlesSubjElModifylog subjElModifylog = new AlesSubjElModifylog();
        subjElModifylog.setId(UUID.randomUUID().toString().replace("-",""));
        subjElModifylog.setUpdateTime(new Date());
        subjElModifylogMapper.insert(subjElModifylog);
        //第三步，修改执法机构主体信息
        subjEnforceLawMapper.updateByPrimaryKey(subjEnforceLaw);
    }

    @Override
    public PageInfo getSubjElCancelList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        pageInfo.setTotal(subjEnforceLawExpandMapper.getSubjElCancelCount(map));
        pageInfo.setList(subjEnforceLawExpandMapper.getSubjElCancelList(map));
        return pageInfo;
    }

    @Override
    public AlesSubjElCancel findSubjElCancelById(String id) {
        return subjElCancelMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void auditSubjElCancel(AlesSubjEnforceLaw subjEnforceLaw, AlesSubjElCancel subjElCancel) {
        //第一步，先修改申请表的状态
        subjElCancelMapper.updateByPrimaryKey(subjElCancel);
        //第二步，将修改记录插入修改记录表
        AlesSubjElModifylog subjElModifylog = new AlesSubjElModifylog();
        subjElModifylog.setId(UUID.randomUUID().toString().replace("-",""));
        subjElModifylog.setUpdateTime(new Date());
        subjElModifylogMapper.insert(subjElModifylog);
        //第三步，修改执法机构主体信息
        subjEnforceLawMapper.updateByPrimaryKey(subjEnforceLaw);
    }

    @Override
    public PageInfo getSubjElRevokeList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        pageInfo.setTotal(subjEnforceLawExpandMapper.getSubjElRevokeCount(map));
        pageInfo.setList(subjEnforceLawExpandMapper.getSubjElRevokeList(map));
        return pageInfo;
    }

    @Override
    public AlesSubjElRevoke findSubjElRevokeById(String id) {
        return subjElRevokeMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void auditSubjElRevoke(AlesSubjEnforceLaw subjEnforceLaw, AlesSubjElRevoke subjElRevoke) {
        //第一步，先修改申请表的状态
        subjElRevokeMapper.updateByPrimaryKey(subjElRevoke);
        //第二步，将修改记录插入修改记录表
        AlesSubjElModifylog subjElModifylog = new AlesSubjElModifylog();
        subjElModifylog.setId(UUID.randomUUID().toString().replace("-",""));
        subjElModifylog.setUpdateTime(new Date());
        subjElModifylogMapper.insert(subjElModifylog);
        //第三步，修改执法机构主体信息
        subjEnforceLawMapper.updateByPrimaryKey(subjEnforceLaw);
    }
}
