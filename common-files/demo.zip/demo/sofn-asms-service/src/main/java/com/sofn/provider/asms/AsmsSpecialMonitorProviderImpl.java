/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsSpecialLeadUnitExpandMapper;
import com.sofn.dao.asms.AsmsSpecialMonitorExpandMapper;
import com.sofn.dao.generator.AsmsSpecialLeadUnitMapper;
import com.sofn.model.generator.AsmsSpecialLeadUnit;
import com.sofn.model.generator.AsmsSpecialMonitor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@DubboService(interfaceClass = AsmsSpecialMonitorProvider.class)
@CacheConfig(cacheNames = "AsmsSpecialMonitor")
public class AsmsSpecialMonitorProviderImpl extends BaseProviderImpl<AsmsSpecialMonitor> implements AsmsSpecialMonitorProvider {
    @Autowired
    private AsmsSpecialMonitorExpandMapper mapper;
    @Autowired
    private AsmsSpecialLeadUnitMapper LeadUnitMapper;//自动生成关联表mapp
    @Autowired
    private AsmsSpecialLeadUnitExpandMapper LeadUnitExpandMapper;//扩展关联表mapp

    @Override
    public PageInfo<List<Map<String, Object>>> list(Map<String, Object> params) {
        PageInfo pageInfo = new PageInfo();
        List<Map<String,Object>> list = mapper.getPagesList(params);
        long count = mapper.getPageCount(params);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    public void addGlInfo(String taskId, String jgId) {
        AsmsSpecialLeadUnit b = new AsmsSpecialLeadUnit();
        b.setId(UUID.randomUUID().toString().replace("-", ""));//赋值id
        b.setSpecialMonitorId(taskId);//任务id
        b.setLeadUnitId(jgId);//牵头单位id
        LeadUnitMapper.insert(b);
    }

    @Override
    public void delGlInfoByTaskId(String taskId) {
        AsmsSpecialLeadUnit t = new AsmsSpecialLeadUnit();
        t.setSpecialMonitorId(taskId);
        LeadUnitExpandMapper.delByTaskId(t);
    }
}
