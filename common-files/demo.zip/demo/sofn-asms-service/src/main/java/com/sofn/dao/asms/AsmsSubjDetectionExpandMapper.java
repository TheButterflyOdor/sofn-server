package com.sofn.dao.asms;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.generator.AsmsSubjDetection;
import com.sofn.model.generator.AsmsSubjDtCancel;
import com.sofn.model.generator.AsmsSubjDtChange;
import com.sofn.model.generator.AsmsSubjDtRevoke;

import java.util.List;
import java.util.Map;

/**
 * Mapper 扩展
 *
 * @author sofn
 * @version 2016年09月12日 下午 4:02
 */
@MyBatisDao
public interface AsmsSubjDetectionExpandMapper extends BaseExpandMapper{

    public List<AsmsSubjDetection> getSubjDetectionList(Map<String, Object> map);

    public long getSubjDetectionCount(Map<String, Object> map);

    public List<Map<String,Object>> getSubjDtChangeList(Map<String, Object> map);

    public long getSubjDtChangeCount(Map<String, Object> map);

    public List<Map<String,Object>> getSubjDtCancelList(Map<String, Object> map);

    public long getSubjDtCancelCount(Map<String, Object> map);

    public List<Map<String,Object>> getSubjDtRevokeList(Map<String, Object> map);

    public long getSubjDtRevokeCount(Map<String, Object> map);
}
