package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.TScltxxcjComplaintExpandMapper;
import com.sofn.dao.generator.TScltxxcjComplaintMapper;
import com.sofn.model.generator.TScltxxcjComplaint;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * @author dongwenfeng
 * @version 2016年09月20日 下午 4:35
 */
@DubboService(interfaceClass = TScltxxcjComplaintProvider.class)
public class TScltxxcjComplaintImpl extends BaseProviderImpl<TScltxxcjComplaint> implements TScltxxcjComplaintProvider {
    @Autowired
    private TScltxxcjComplaintMapper tScltxxcjComplaintMapper;
    @Autowired
    private TScltxxcjComplaintExpandMapper tScltxxcjComplaintExpandMapper;

    @Override
    public PageInfo<TScltxxcjComplaint> getTScltxxcjComplaintList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        List<Map<String, Object>> list = tScltxxcjComplaintExpandMapper.selectAllByCondition(map);
        long count = tScltxxcjComplaintExpandMapper.getTScltxxcjComplaintCount(map);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }
    @Override
    public TScltxxcjComplaint findTScltxxcjComplaintById(String id) {
        return tScltxxcjComplaintMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateTScltxxcjComplaint(TScltxxcjComplaint tScltxxcjComplaint) {

        return tScltxxcjComplaintMapper.updateByPrimaryKey(tScltxxcjComplaint);
    }
}
