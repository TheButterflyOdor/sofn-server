package com.sofn.dao.asms;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.generator.AsmsRoutineLeadUnit;

/**
 * Mapper扩展
 *
 * @author sofn
 * @version 2016年8月29日 下午3:4:0
 */
@MyBatisDao
public interface AsmsRoutineLeadUnitExpandMapper extends BaseExpandMapper {

  public void delByTaskId(AsmsRoutineLeadUnit t);

}