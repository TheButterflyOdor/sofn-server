package com.sofn.dao.generator;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseMapper;
import com.sofn.model.generator.AsmsEmergencyExpert;

import java.util.List;
@MyBatisDao
public interface AsmsEmergencyExpertMapper extends BaseMapper<AsmsEmergencyExpert>{
    int deleteByPrimaryKey(String id);

    int insert(AsmsEmergencyExpert record);

    AsmsEmergencyExpert selectByPrimaryKey(String id);

    List<AsmsEmergencyExpert> selectAll();

    int updateByPrimaryKey(AsmsEmergencyExpert record);
}