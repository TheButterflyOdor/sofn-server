/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsInspectionAssessExpandMapper;
import com.sofn.model.asms.SuperviseCheckDto;
import com.sofn.model.generator.AsmsInspectionAssess;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;

import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@DubboService(interfaceClass = AsmsInspectionAssessProvider.class)
@CacheConfig(cacheNames = "AsmsInspectionAssess")
public class AsmsInspectionAssessProviderImpl extends BaseProviderImpl<AsmsInspectionAssess> implements AsmsInspectionAssessProvider {
    @Autowired
    private AsmsInspectionAssessExpandMapper mapper;

    public List<AsmsInspectionAssess> getXcUserIds(AsmsInspectionAssess taskUser){
        return mapper.getXcUserIds(taskUser);
    }

    public  void  delOldDate (AsmsInspectionAssess taskUser){
        mapper.delOldDate (taskUser);
    }

    public PageInfo<AsmsInspectionAssess> getPageList (Map<String, Object> params){
        startPage(params);
        return getPage(mapper.getPageList(params));
    }
	 public PageInfo<List<Map<String, Object>>> getPages(Map<String, Object> params) {
         PageInfo pageInfo = new PageInfo();
         List<Map<String,Object>> list = mapper.getPagesList(params);
         //获取实际巡查次数
         if (list.size()>0){
             for (Map<String,Object> mp : list){
                 String userId = (String)mp.get("USERID");
                 Long c = mapper.getRealCount(userId);
                 mp.put("INSPECTIONREALCOUNT",c.toString());
                 Long i =0l;
                 if (mp.get("INSPECTIONCOUNT")!=null) {
                     i = Long.parseLong(mp.get("INSPECTIONCOUNT").toString());
                 }else {
                     mp.put("INSPECTIONCOUNT",i);
                 }
                 if (c<i&&i!=0){
                     mp.put("TASKSTATUS","未完成");
                 }else {
                     mp.put("TASKSTATUS","已完成");
                 }
             }
         }
         long count = mapper.getPageCount(params);
         pageInfo.setList(list);
         pageInfo.setTotal(count);
//        startPage(params);
//        Page<String> ids = mapper.getPageIds(params);
//        PageInfo<List<Map<String, Object>>> i = getExpandPage(ids);
        return pageInfo;
    }

    @Override
    public List<SuperviseCheckDto> getSuperviseTaskInfos() {
        return mapper.getSuperviseTaskInfos();
    }

    @Override
    public PageInfo getBaseInspectionAllList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        String xcPsersionId = (String)map.get("xcPsersionId");
        long count = mapper.getBaseInspectionAllCount(xcPsersionId);
        List<Map<String,Object>> list = mapper.getBaseInspectionAllList(map);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }


    /*------------------------------------------------------*/
    public PageInfo getExpandPage(Page<String> ids) {
        if (ids != null) {
            Page page = new Page(ids.getPageNum(), ids.getPageSize());
            page.setTotal(ids.getTotal());
            page.clear();
            for (String id : ids) {
                Map<String, Object> record = mapper.expandSelectByPrimaryKey(id);
                page.add(record);
            }
            return new PageInfo(page);
        }
        return new PageInfo();
    }

}
