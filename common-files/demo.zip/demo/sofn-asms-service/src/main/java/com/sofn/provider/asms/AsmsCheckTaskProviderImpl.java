/**
 *
 */
package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsCheckBearUnitExpandMapper;
import com.sofn.dao.asms.AsmsCheckTaskExpandMapper;
import com.sofn.dao.asms.AsmsMonitorObjectExpandMapper;
import com.sofn.dao.generator.AsmsCheckBearUnitMapper;
import com.sofn.dao.generator.AsmsMonitorObjectMapper;
import com.sofn.model.generator.AsmsCheckBearUnit;
import com.sofn.model.generator.AsmsCheckTask;
import com.sofn.model.generator.AsmsMonitorObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CacheConfig;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author sofn
 * @version 2016年5月26日 上午9:1:0
 */
@DubboService(interfaceClass = AsmsCheckTaskProvider.class)
@CacheConfig(cacheNames = "AsmsCheckTask")
public class AsmsCheckTaskProviderImpl extends BaseProviderImpl<AsmsCheckTask> implements AsmsCheckTaskProvider {

    @Autowired
    private AsmsCheckTaskExpandMapper expandMapper;
    @Autowired
    private AsmsCheckBearUnitMapper UnitMapper;//自动生成关联表mapp-牵头单位
    @Autowired
    private AsmsCheckBearUnitExpandMapper UnitExpandMapper;//扩展关联表mapp-牵头单位
    @Autowired
    private AsmsMonitorObjectMapper objMapper;//自动生成关联表mapp-抽查对象
    @Autowired
    private AsmsMonitorObjectExpandMapper objExpandMapper;//扩展关联表mapp-抽查对象


    @Override
    public PageInfo<List<Map<String, Object>>> list(Map<String, Object> params) {
        PageInfo pageInfo = new PageInfo();
        List<Map<String, Object>> list = expandMapper.getPagesList(params);
        long count = expandMapper.getPageCount(params);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    public void addGlInfo(AsmsMonitorObject o) {
        o.setId(UUID.randomUUID().toString().replace("-", ""));//赋值id
        objMapper.insert(o);
    }

    @Override
    public void delGlInfoByTaskId(String taskId) {
        AsmsMonitorObject t = new AsmsMonitorObject();
        t.setSuperviseCheckTaskId(taskId);
        objExpandMapper.delByTaskId(t);
    }

    @Override
    public void addBjGlInfo(AsmsCheckBearUnit o) {
        o.setId(UUID.randomUUID().toString().replace("-", ""));//赋值id
        UnitMapper.insert(o);
    }

    @Override
    public void delBjGlInfoByTaskId(String taskId) {
        AsmsCheckBearUnit t = new AsmsCheckBearUnit();
        t.setSuperviseCheckTaskId(taskId);
        UnitExpandMapper.delByTaskId(t);
    }

    @Override
    public List<Map<String, Object>> getObjById(String id) {
        return objExpandMapper.getObjById(id);
    }

}
