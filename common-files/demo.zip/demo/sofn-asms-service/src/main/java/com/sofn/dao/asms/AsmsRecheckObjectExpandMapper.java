package com.sofn.dao.asms;

import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;
import com.sofn.model.generator.AsmsRecheckObject;

import java.util.List;
import java.util.Map;

/**
 * Mapper扩展
 *
 * @author sofn
 * @version 2016年8月29日 下午3:4:0
 */
@MyBatisDao
public interface AsmsRecheckObjectExpandMapper extends BaseExpandMapper {

  public void delByTaskId(AsmsRecheckObject t);

  List<Map<String, Object>> getObjById(String id);

}