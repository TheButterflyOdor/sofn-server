package com.sofn.dao.asms;

import com.github.pagehelper.Page;
import com.sofn.core.annotation.MyBatisDao;
import com.sofn.core.base.BaseExpandMapper;

import java.util.List;
import java.util.Map;
@MyBatisDao
public interface AsmsBaseInspectionExpandMapper extends BaseExpandMapper{
    Page<String> selectAllByCondition(Map<String, Object> map);

    List<Map<String,Object>> getBaseInspectionAllList(Map<String, Object> map);

    long getBaseInspectionAllCount(Map<String, Object> map);

    //暂加
    List<Map<String,Object>> getEnterpriseList(Map<String, Object> map);
    //暂加
    long getEnterpriseCount(Map<String, Object> map);

    //暂加
    Map<String,Object> findEnterpriseById(String enterpriseId);

}