package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsSubjSuperviseExpandMapper;
import com.sofn.dao.generator.*;
import com.sofn.model.generator.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author sofn
 * @version 2016年09月08日 下午 4:35
 */
@DubboService(interfaceClass = AsmsSubjSuperviseProvider.class)
public class AsmsSubjSuperviseProviderImpl extends BaseProviderImpl<AsmsSubjSupervise> implements AsmsSubjSuperviseProvider {

    @Autowired
    private AsmsSubjSuperviseMapper subjSuperviseMapper;
    @Autowired
    private AsmsSubjSuperviseExpandMapper subjectSuperviseExpandMapper;
    @Autowired
    private AsmsSubjSvRevokeMapper subjSvRevokeMapper;
    @Autowired
    private AsmsSubjSvChangeMapper subjSvChangeMapper;
    @Autowired
    private AsmsSubjSvCancelMapper subjSvCancelMapper;
    @Autowired
    private AsmsSubjSvModifylogMapper subjSvModifylogMapper;

    @Override
    public int addSubjSupervise(AsmsSubjSupervise subjSupervise) {
        return subjSuperviseMapper.insert(subjSupervise);
    }

    @Override
    public AsmsSubjSupervise findSubjSuperviseById(String id) {
        return subjSuperviseMapper.selectByPrimaryKey(id);
    }

    @Override
    public PageInfo getSubjSuperviseList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        List<AsmsSubjSupervise> list = subjectSuperviseExpandMapper.getSubjSuperviseList(map);
        long count = subjectSuperviseExpandMapper.getSubjSuperviseCount(map);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    public int addSubjSvRevoke(AsmsSubjSvRevoke subjSvRevoke) {
        return subjSvRevokeMapper.insert(subjSvRevoke);
    }

    @Override
    public PageInfo getSubjSvChangeList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        pageInfo.setTotal(subjectSuperviseExpandMapper.getSubjSvChangeCount(map));
        pageInfo.setList(subjectSuperviseExpandMapper.getSubjSvChangeList(map));
        return pageInfo;
    }

    @Override
    public AsmsSubjSvChange findSubjSvChangeById(String id) {
        return subjSvChangeMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void auditSubjSvChange(AsmsSubjSupervise subjSupervise, AsmsSubjSvChange subjSvChange) {
        //第一步，先修改申请表的状态
        subjSvChangeMapper.updateByPrimaryKey(subjSvChange);
        //第二步，将修改记录插入修改记录表
        AsmsSubjSvModifylog subjSvModifylog = new AsmsSubjSvModifylog();
        subjSvModifylog.setId(UUID.randomUUID().toString().replace("-",""));
        subjSvModifylog.setUpdateTime(new Date());
        subjSvModifylogMapper.insert(subjSvModifylog);
        //第三步，修改监管机构主体信息
        subjSupervise.setSvName(subjSvChange.getSvName());
        subjSupervise.setSvAreaId(subjSvChange.getSvAreaId());
        subjSupervise.setSvAddress(subjSvChange.getSvAddress());
        subjSupervise.setSvCode(subjSvChange.getSvCode());
        subjSupervise.setSvLeader(subjSvChange.getSvLeader());
        subjSupervise.setSvLeaderPhone(subjSvChange.getSvLeaderPhone());
        subjSuperviseMapper.updateByPrimaryKey(subjSupervise);
    }

    @Override
    public PageInfo getSubjSvCancelList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        pageInfo.setTotal(subjectSuperviseExpandMapper.getSubjSvCancelCount(map));
        pageInfo.setList(subjectSuperviseExpandMapper.getSubjSvCancelList(map));
        return pageInfo;
    }

    @Override
    public AsmsSubjSvCancel findSubjSvCancelById(String id) {
        return subjSvCancelMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void auditSubjSvCancel(AsmsSubjSupervise subjSupervise, AsmsSubjSvCancel subjSvCancel) {
        //第一步，先修改申请表的状态
        subjSvCancelMapper.updateByPrimaryKey(subjSvCancel);
        //第二步，将修改记录插入修改记录表
        AsmsSubjSvModifylog subjSvModifylog = new AsmsSubjSvModifylog();
        subjSvModifylog.setId(UUID.randomUUID().toString().replace("-",""));
        subjSvModifylog.setUpdateTime(new Date());
        subjSvModifylogMapper.insert(subjSvModifylog);
        //第三步，修改监管机构主体信息
        if("0".equals(subjSvCancel.getAuditState())) {
            subjSupervise.setEnable(false);
            subjSuperviseMapper.updateByPrimaryKey(subjSupervise);
        }
    }

    @Override
    public PageInfo getSubjSvRevokeList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        pageInfo.setTotal(subjectSuperviseExpandMapper.getSubjSvRevokeCount(map));
        pageInfo.setList(subjectSuperviseExpandMapper.getSubjSvRevokeList(map));
        return pageInfo;
    }

    @Override
    public AsmsSubjSvRevoke findSubjSvRevokeById(String id) {
        return subjSvRevokeMapper.selectByPrimaryKey(id);
    }

    @Override
    @Transactional
    public void auditSubjSvRevoke(AsmsSubjSupervise subjSupervise, AsmsSubjSvRevoke subjSvRevoke) {
        //第一步，先修改申请表的状态
        subjSvRevokeMapper.updateByPrimaryKey(subjSvRevoke);
        //第二步，将修改记录插入修改记录表
        AsmsSubjSvModifylog subjSvModifylog = new AsmsSubjSvModifylog();
        subjSvModifylog.setId(UUID.randomUUID().toString().replace("-",""));
        subjSvModifylog.setUpdateTime(new Date());
        subjSvModifylogMapper.insert(subjSvModifylog);
        //第三步，修改监管机构主体信息
        if("0".equals(subjSvRevoke.getAuditState())) {
            subjSupervise.setEnable(false);
            subjSuperviseMapper.updateByPrimaryKey(subjSupervise);
        }
    }
}
