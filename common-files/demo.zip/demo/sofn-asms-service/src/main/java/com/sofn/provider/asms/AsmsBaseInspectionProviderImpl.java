package com.sofn.provider.asms;

import com.github.pagehelper.PageInfo;
import com.sofn.core.base.BaseProviderImpl;
import com.sofn.core.support.dubbo.spring.annotation.DubboService;
import com.sofn.dao.asms.AsmsBaseInspectionExpandMapper;
import com.sofn.dao.generator.AsmsBaseInspectionMapper;
import com.sofn.model.generator.AsmsBaseInspection;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Map;

/**
 * @author sofn
 * @version 2016年08月25日 下午 4:35
 */
@DubboService(interfaceClass = AsmsBaseInspectionProvider.class)
public class AsmsBaseInspectionProviderImpl extends BaseProviderImpl<AsmsBaseInspection> implements AsmsBaseInspectionProvider {

    @Autowired
    private AsmsBaseInspectionMapper asmsBaseInspectionMapper;
    @Autowired
    private AsmsBaseInspectionExpandMapper baseInspectionExpandMapper;

    public int addBaseInspection(AsmsBaseInspection asmsBaseInspection){
        return asmsBaseInspectionMapper.insert(asmsBaseInspection);
    }

    @Override
    public PageInfo<AsmsBaseInspection> getBaseInspectionList(Map<String,Object> map) {
        startPage(map);
        return getPage(baseInspectionExpandMapper.selectAllByCondition(map));
    }

    @Override
    public PageInfo getBaseInspectionAllList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        List<Map<String,Object>> list = baseInspectionExpandMapper.getBaseInspectionAllList(map);
        long count = baseInspectionExpandMapper.getBaseInspectionAllCount(map);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    //暂加
    public PageInfo getEnterpriseList(Map<String, Object> map) {
        PageInfo pageInfo = new PageInfo();
        List<Map<String,Object>> list = baseInspectionExpandMapper.getEnterpriseList(map);
        long count = baseInspectionExpandMapper.getEnterpriseCount(map);
        pageInfo.setList(list);
        pageInfo.setTotal(count);
        return pageInfo;
    }

    @Override
    //暂加
    public Map<String, Object> findEnterpriseById(String enterpriseId) {
        return baseInspectionExpandMapper.findEnterpriseById(enterpriseId);
    }

    @Override
    public AsmsBaseInspection findBaseInspectionById(String id) {
        return asmsBaseInspectionMapper.selectByPrimaryKey(id);
    }

    @Override
    public int updateBaseInspection(AsmsBaseInspection baseInspection) {
        return asmsBaseInspectionMapper.updateByPrimaryKey(baseInspection);
    }

    @Override
    public int deleteBaseInspection(String id) {
        return asmsBaseInspectionMapper.deleteByPrimaryKey(id);
    }
}
